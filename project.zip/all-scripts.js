
function printBriefing(){
  generate();
  setTimeout(() => window.print(), 100);
}

let selected=[];
let lastQuestions=[];

const preventionMesures={
'Déplacement / piste encombrée':["Identifier le cheminement à utiliser avant le démarrage.","Signaler les obstacles, matériaux, big bags, blindages ou zones encombrées.","Ne pas circuler hors des cheminements validés."],
'Bruit / port EPICB':["Port des EPICB obligatoire si l’activité génère du bruit.","Limiter l’exposition au bruit et rester vigilant aux informations sécurité."],
'Chimique / masque FFP3':["Port du masque FFP3 si présence de poussières ou risque chimique identifié.","Respecter les modes opératoires et les fiches sécurité produit."],
'Manutention de charge':["Rappeler les gestes et postures.","Se coordonner avant toute manutention à plusieurs.","Ne pas se placer sous une charge ou dans une zone de levage."],
'Outillage':["Utiliser uniquement du matériel conforme et adapté.","Respecter les consignes d’utilisation des outils.","Contrôler l’état de l’outillage avant usage."],
'Incendie':["Identifier les extincteurs disponibles.","Respecter le permis feu si concerné.","Maintenir les accès dégagés pour permettre l’intervention."],
'Environnement':["Éviter tout rejet dans le milieu naturel.","Stocker les déchets et consommables dans les zones prévues.","Refermer et sécuriser les accès en fin d’intervention."],
'Coactivité':["Identifier les autres équipes présentes sur zone.","Clarifier les limites d’intervention de chaque équipe.","Ne pas débuter une tâche en cas d’interférence non traitée."]
};

function val(id){return document.getElementById(id)?.value || 'À compléter'}
function only(list){return selected.filter(v=>list.includes(v))}
function toggle(btn,value){btn.classList.toggle('active'); selected=selected.includes(value)?selected.filter(v=>v!==value):[...selected,value]; generate()}

function voieDefaultName(i){return "V"+(i+1)}

function togglePkVoie(i){
 const checked=document.getElementById('pkDifferent'+i)?.checked;
 const bloc=document.getElementById('pkBloc'+i);
 if(bloc) bloc.style.display = checked ? 'grid' : 'none';
}

function renderVoies(){
 const nb=parseInt(document.getElementById('nbVoies').value);
 const c=document.getElementById('voiesContainer');
 c.innerHTML="";
 for(let i=0;i<nb;i++){
  c.innerHTML += `
  <div class="voie-row">
    <div class="voie-row-title">Voie ${i+1}</div>
    <label>Nom de la voie</label>
    <input id="voieNom${i}" value="${voieDefaultName(i)}" oninput="generate()">

    <div class="grid2">
      <div>
        <label>Protection SNCF circulation</label>
        <select id="voieS9${i}" onchange="generate()">
          <option>Interceptée</option>
          <option>Annonce</option>
          <option>Circulée</option>
          <option>Non concernée</option>
        </select>
      </div>
      <div>
        <label>État caténaire</label>
        <select id="voieS11${i}" onchange="generate()">
          <option>Caténaire alimentée</option>
          <option>Caténaire mise hors tension</option>
        </select>
      </div>
    </div>

    <label class="checkline">
      <input type="checkbox" id="pkDifferent${i}" onchange="togglePkVoie(${i});generate()"> PK différents de la zone chantier globale
    </label>

    <div class="grid2" id="pkBloc${i}" style="display:none;">
      <div>
        <label>PK début sur cette voie</label>
        <input id="voiePkDebut${i}" placeholder="Ex : 80,000" oninput="generate()">
      </div>
      <div>
        <label>PK fin sur cette voie</label>
        <input id="voiePkFin${i}" placeholder="Ex : 80,600" oninput="generate()">
      </div>
    </div>

    <label class="checkline"><input type="checkbox" id="voieTravail${i}" onchange="generate()"> Voie de travail</label>
    <label class="checkline"><input type="checkbox" id="voiePiste${i}" onchange="generate()"> Travail dans la piste de cette voie</label>
    <label class="checkline"><input type="checkbox" id="lamVoie${i}" onchange="generate()"> LAM (Lorry Automoteur) dans la voie</label>
  </div>`;
 }
 generate();
}

function getVoies(){
 const nb=parseInt(document.getElementById('nbVoies').value);
 let rows=[];
 for(let i=0;i<nb;i++){
  rows.push({
   nom:val('voieNom'+i),
   s9:val('voieS9'+i),
   s11:val('voieS11'+i),
   travail:document.getElementById('voieTravail'+i)?.checked || false,
   piste:document.getElementById('voiePiste'+i)?.checked || false,
   lamVoie:document.getElementById('lamVoie'+i)?.checked || false,
   pkDifferent:document.getElementById('pkDifferent'+i)?.checked || false,
   pkDebut:val('voiePkDebut'+i),
   pkFin:val('voiePkFin'+i)
  });
 }
 return rows;
}

function makeTable(rows,type){
 if(type==="s11"){
   let html="<table><tr><th>Voie</th><th>État caténaire</th></tr>";
   rows.forEach(r=>{ html+=`<tr><td><b>${r.nom}</b></td><td>${r.s11}</td></tr>`; });
   return html+"</table>";
 }
 let html="<table><tr><th>Voie</th><th>Protection SNCF circulation</th><th>PK voie / zone</th><th>Configuration travaux</th></tr>";
 rows.forEach(r=>{
   let config=[];
   if(r.travail) config.push("Voie de travail");
   if(r.piste) config.push("Travail dans la piste");
   if(r.lamVoie) config.push("LAM (Lorry Automoteur) dans la voie");
   const pk = r.pkDifferent ? `${r.pkDebut} au ${r.pkFin}` : `${val('pkDebut')} au ${val('pkFin')}`;
   html+=`<tr><td><b>${r.nom}</b></td><td>${r.s9}</td><td>${pk}</td><td>${config.join(" / ") || "-"}</td></tr>`;
 });
 return html+"</table>";
}

function getEngins(){
 const list=getEnginsList();
 const lamList=getVoies().filter(v=>v.lamVoie).map(v=>"LAM (Lorry Automoteur) dans la voie "+v.nom);
 const all=[...lamList, ...list];
 return all.length ? all.join(", ") : "À compléter";
}




function toggleTravauxType(){
 const sig = document.getElementById('travauxSignalisation')?.checked ?? true;
 const cat = document.getElementById('travauxCatenaire')?.checked ?? false;

 const sigBloc = document.getElementById('blocSignalisation') || document.getElementById('travauxSignalisationBloc');
 const catBloc = document.getElementById('blocCatenaire') || document.getElementById('travauxCatenaireBloc');

 if(sigBloc) sigBloc.style.display = sig ? 'block' : 'none';
 if(catBloc) catBloc.style.display = cat ? 'block' : 'none';

 // Anciens blocs éventuels selon les versions précédentes
 document.querySelectorAll('[data-travaux="signalisation"]').forEach(e=>e.style.display = sig ? 'block' : 'none');
 document.querySelectorAll('[data-travaux="catenaire"]').forEach(e=>e.style.display = cat ? 'block' : 'none');
}


function renderEngins(){
 const nb=parseInt(document.getElementById('nbEngins').value);
 const c=document.getElementById('enginsContainer');
 c.innerHTML="";
 if(nb===0){
   generate();
   return;
 }
 for(let i=0;i<nb;i++){
   c.innerHTML += `
   <div class="voie-row">
      <div class="voie-row-title">Engin ${i+1}</div>

      <label>Type d’engin</label>
      <select id="enginType${i}" onchange="generate()">
        <option>Aucun</option>
        <option>Pelle rail-route</option>
        <option>Pelle rail-route + remorque</option>
        <option>Nacelle</option>
        <option>4 axes</option>
        <option>C14</option>
        <option>Élan</option>
        <option>Camion grue</option>
        <option>Pelle mécanique supérieure à 2,5 tonnes</option>
        <option>Mini-pelle</option>
        <option>Autre</option>
      </select>

      <label>Voie de travail de l’engin</label>
      <input id="enginVoie${i}" placeholder="Ex : V1, V2M, V1 bis...">

      <label>Précisions / observations</label>
      <input id="enginObs${i}" placeholder="Ex : remorque, stabilisateurs, circulation limitée...">
   </div>`;
 }
 generate();
}

function getEnginsList(){
 const nb=parseInt(document.getElementById('nbEngins').value || '0');
 let engins=[];
 if(nb===0) return engins;
 for(let i=0;i<nb;i++){
   const type=val('enginType'+i);
   const voie=val('enginVoie'+i);
   const obs=val('enginObs'+i);

   if(type !== 'Aucun'){
      let txt = type;
      if(voie !== 'À compléter') txt += ' sur ' + voie;
      if(obs !== 'À compléter') txt += ' (' + obs + ')';
      engins.push(txt);
   }
 }
 return engins;
}


function generateAnalyseSecuriteVoies(){
 const voies=getVoies();
 const messages=[];
 const voiesTravail=voies.filter(v=>v.travail);
 const voiesPiste=voies.filter(v=>v.piste);

 function nextVoie(v){
   const idx=voies.indexOf(v);
   if(idx>=0 && idx<voies.length-1) return voies[idx+1];
   if(idx>0) return voies[idx-1];
   return null;
 }

 voiesPiste.forEach(v=>{
   if(!v.s9.includes("Interceptée")){
     messages.push({
       type:"danger",
       text:`Attention : travail dans la piste de ${v.nom}. La voie ${v.nom} doit être interceptée. Situation incompatible si la voie reste circulée.`
     });
   }

   const contigue=nextVoie(v);
   if(contigue){
     if(contigue.s9==="Circulée"){
       messages.push({
         type:"danger",
         text:`Attention : travail dans la piste de ${v.nom}. La voie contiguë ${contigue.nom} est circulée : situation à risque, protection à revoir avant démarrage.`
       });
     } else if(contigue.s9.includes("Interceptée") || contigue.s9.includes("Annonce")){
       messages.push({
         type:"ok",
         text:`Travail dans la piste de ${v.nom} : la voie contiguë ${contigue.nom} dispose d’une protection (${contigue.s9}).`
       });
     }
   }
 });

 voiesTravail.forEach(v=>{
   if(v.s9==="Circulée"){
     messages.push({
       type:"danger",
       text:`Attention : ${v.nom} est déclarée voie de travail mais elle est circulée. Situation incompatible sans protection adaptée.`
     });
   }

   if(v.s9==="Annonce" || v.s9==="Annonce"){
     messages.push({
       type:"warning",
       text:`Vigilance : travail sur ${v.nom} avec annonce. C’est une mesure possible, mais la situation reste sensible et doit être clairement comprise par tous les intervenants.`
     });
   }

   const contigue=nextVoie(v);
   if(contigue && contigue.s9==="Circulée"){
     messages.push({
       type:"warning",
       text:`Vigilance : ${v.nom} est voie de travail et la voie contiguë ${contigue.nom} est circulée. Vérifier qu’aucun engagement de la voie contiguë n’est possible et que la protection prévue est suffisante.`
     });
   }
 });

 if(!messages.length){
   messages.push({
     type:"ok",
     text:"Aucune incompatibilité détectée automatiquement avec les protections renseignées. Les protections doivent toutefois être confirmées sur le terrain avant démarrage."
   });
 }

 const container=document.getElementById('oAnalyseSecuriteVoies');
 if(container){
   container.innerHTML = messages.map(m=>{
     const cls = m.type==="danger" ? "alert-danger" : (m.type==="warning" ? "alert-warning" : "alert-ok");
     const prefix = m.type==="danger" ? "⚠ " : (m.type==="warning" ? "⚠ Vigilance : " : "✓ ");
     return `<div class="${cls}">${prefix}${m.text}</div>`;
   }).join("");
 }
}

function generateOtherRisks(){
 const risqueList=['Déplacement / piste encombrée','Bruit / port EPICB','Chimique / masque FFP3','Manutention de charge','Outillage','Incendie','Environnement','Coactivité'];
 const risques=only(risqueList);
 const block=document.getElementById('autresRisquesBlock');
 const consigne=val('consigne');
 const hasConsigne=consigne!=='À compléter';
 if(!risques.length && !hasConsigne){block.style.display='none';return}
 block.style.display='block';
 let html="";
 risques.forEach((risk,index)=>{
  html += `<div style="margin-bottom:10px;"><b><span class="red">${index+1}°)</span> ${risk}</b><ul style="margin-top:4px;">${(preventionMesures[risk]||[]).map(m=>`<li>${m}</li>`).join("")}</ul></div>`;
 });
 document.getElementById('oAutresRisques').innerHTML=html;
 document.getElementById('oConsigneBlock').style.display=hasConsigne?'block':'none';
 document.getElementById('oConsigne').textContent=hasConsigne?consigne:"";
}

function pickTwo(pool){
 const clean=[...new Set(pool)].filter(Boolean);
 let available=clean.filter(q=>!lastQuestions.includes(q));
 if(available.length<2) available=clean;
 const shuffled=available.sort(()=>0.5-Math.random());
 lastQuestions=[shuffled[0],shuffled[1]];
 document.getElementById('question1').textContent=lastQuestions[0] || "Quelle est la consigne principale à retenir avant le démarrage ?";
 document.getElementById('question2').textContent=lastQuestions[1] || "Quelles sont les limites de la zone de chantier ?";
 generateAnswers();
}


function buildAnswer(question){
 const voies = getVoies ? getVoies() : [];
 const voiesTravail = voies.filter(v=>v.travail).map(v=>v.nom).join(", ") || "à préciser";
 const voiesPiste = voies.filter(v=>v.piste).map(v=>v.nom).join(", ") || "à préciser";
 const lamVoies = voies.filter(v=>v.lamVoie).map(v=>v.nom).join(", ") || "non renseigné";
 const travaux = typeof selected !== "undefined" ? selected.join(", ") : "à préciser";
 const engins = typeof getEngins === "function" ? getEngins() : "à préciser";
 const pkGlobal = (val('pkDebut') || "à préciser") + " au " + (val('pkFin') || "à préciser");
 const prs = val('prs') || val('repere') || "à préciser";

 if(question.includes("limites PK")){
   return "Les limites à rappeler sont : " + pkGlobal + ". Si des PK spécifiques sont indiqués par voie, il faut retenir les PK du tableau par voie.";
 }
 if(question.includes("PRS") || question.includes("Point de Rassemblement")){
   return "La PRS à rejoindre ou indiquer aux secours est : " + prs + ".";
 }
 if(question.includes("voie de travail") || question.includes("Voie de travail")){
   return "La ou les voies de travail renseignées sont : " + voiesTravail + ".";
 }
 if(question.includes("piste")){
   return "Le travail dans la piste concerne : " + voiesPiste + ". Il ne faut pas engager la voie sans protection adaptée et confirmée.";
 }
 if(question.includes("LAM")){
   return "La LAM est renseignée sur : " + lamVoies + ". Elle doit rester dans sa zone prévue et ne pas être engagée sans protection confirmée.";
 }
 if(question.includes("protection circulation") || question.includes("Protection circulation")){
   const details = voies.map(v => v.nom + " : " + v.s9).join(" / ");
   return "Les protections circulation à retenir sont : " + (details || "à préciser") + ".";
 }
 if(question.includes("caténaire") || question.includes("électrique") || question.includes("tension")){
   const details = voies.map(v => v.nom + " : " + v.s11).join(" / ");
   return "L’état caténaire à retenir est : " + (details || "à préciser") + ". Toute installation est à considérer sous tension tant que la mise hors tension n’est pas confirmée.";
 }
 if(question.includes("SST")){
   return "Le nombre de SST renseigné est : " + val('sstNombre') + ". En cas d’accident, alerter immédiatement le responsable chantier et le ou les SST présents.";
 }
 if(question.includes("engins") || question.includes("mobiles travaux") || question.includes("charge")){
   return "Les engins / mobiles travaux à retenir sont : " + engins + ". Personne ne pénètre à moins de 3 m d’un engin ou d’une charge sans autorisation.";
 }
 if(question.includes("fouilles") || question.includes("blindages")){
   return "Rester hors des fouilles non sécurisées, respecter les blindages, les cheminements et signaler toute anomalie avant d’intervenir.";
 }
 if(question.includes("annonce")){
   return "En cas d’annonce, appliquer immédiatement la conduite prévue : se dégager de la zone dangereuse et attendre l’autorisation de reprise.";
 }
 if(question.includes("circulée")){
   return "Une voie circulée présente un risque de heurt par train. Aucun engagement n’est autorisé sans protection adaptée et confirmée.";
 }
 if(question.includes("coactivité")){
   return "Identifier les équipes présentes, leurs zones d’intervention et ne pas démarrer si une interférence n’est pas traitée.";
 }
 if(question.includes("consignes spécifiques")){
   return val('consigne') || "Les consignes spécifiques doivent être rappelées par le responsable briefing avant démarrage.";
 }
 if(question.includes("travaux")){
   return "Les travaux prévus sont : " + (travaux || "à préciser") + ".";
 }

 return "Réponse attendue : reformuler la règle ou la consigne correspondante indiquée dans le briefing, avec les limites et protections associées.";
}

function generateAnswers(){
 const q1 = document.getElementById('question1')?.textContent || "";
 const q2 = document.getElementById('question2')?.textContent || "";
 const a1 = document.getElementById('answer1');
 const a2 = document.getElementById('answer2');
 if(a1) a1.textContent = buildAnswer(q1);
 if(a2) a2.textContent = buildAnswer(q2);
}

function generateQuestions(){
 const voies=getVoies();
 const travaux=only(['Création artères','Pose de CI','Approvisionnement','TSV','Évacuation matière signalisation','Fouilles avec blindage','FBM','Carottage','Matage de support','Mise en place armature','Support platine','Pose consoles','Pose poutres','Approvisionnement matière caténaire','Évacuation matière caténaire']);
 const risques=only(['Déplacement / piste encombrée','Bruit / port EPICB','Chimique / masque FFP3','Manutention de charge','Outillage','Incendie','Environnement','Coactivité']);
 const voiesTravail=voies.filter(v=>v.travail);
 const voiesPiste=voies.filter(v=>v.piste);
 let pool=[
  "Quelles sont les limites PK du chantier ?",
  "Où se situe la PRS, c’est-à-dire le Point de Rassemblement des Secours ?",
  "Quelles sont les consignes spécifiques du jour ?"
 ];
 voiesTravail.forEach(v=>{
   pool.push(`Quelle est la protection circulation prévue sur la voie de travail ${v.nom} ?`);
   pool.push(`Quel est l’état caténaire sur la voie de travail ${v.nom} ?`);
   if(v.pkDifferent) pool.push(`Quelles sont les limites PK spécifiques de l’intervention sur ${v.nom} ?`);
 });
 voies.filter(v=>v.lamVoie).forEach(v=>{
   pool.push(`Quelle protection est obligatoire avant d’engager la LAM (Lorry Automoteur) dans la voie ${v.nom} ?`);
   pool.push(`Quelle est la voie concernée par la LAM ?`);
 });
 voiesPiste.forEach(v=>{
   pool.push(`Quelles limites respecter pour le travail dans la piste de ${v.nom} ?`);
   pool.push(`Quelle protection doit être vérifiée pour travailler dans la piste de ${v.nom} ?`);
 });
 voies.forEach(v=>{
  if(v.s9.includes("Annonce")) pool.push(`Quelle conduite doit être tenue en cas d’annonce sur ${v.nom} ?`);
  if(v.s9.includes("Interceptée")) pool.push(`Quelles limites ne doivent pas être dépassées sur ${v.nom} interceptée ?`);
  if(v.s9==="Circulée") pool.push(`Quel risque faut-il rappeler pour ${v.nom} circulée ?`);
  if(v.piste && v.s9==="Circulée") pool.push(`Pourquoi est-il incompatible de travailler dans la piste de ${v.nom} si cette voie est circulée ?`);
  if(v.s11.includes("alimentée")) pool.push(`Quelle vigilance électrique faut-il appliquer sur ${v.nom} avec caténaire alimentée ?`);
  if(v.s11.includes("mise hors tension")) pool.push(`Qui confirme la mise hors tension caténaire sur ${v.nom} avant travaux ?`);
 });
 const enginsList=getEnginsList();
 if(enginsList.length){
   pool.push("Quels engins ou mobiles travaux sont présents aujourd’hui ?");
   pool.push("Sur quelles voies interviennent les engins du chantier ?");
   pool.push("À quelle distance minimale ne doit-on pas pénétrer autour d’un engin ou d’une charge sans autorisation ?");
 }
 
 
 
 if(travaux.includes('Fouilles avec blindage')) pool.push("Quelle vigilance particulière faut-il avoir autour des fouilles blindées ?");
 
if(enginsList.some(e=>e.includes('remorque'))) pool.push("Quelle vigilance particulière faut-il avoir avec la remorque de la pelle rail-route ?");
if(enginsList.some(e=>e.includes('Mini-pelle'))) pool.push("Quelle zone d’évolution doit être respectée autour de la mini-pelle ?");
pool.push("Que faut-il éviter avec les sangles, outils ou bras d’engin à proximité de la caténaire ?");

 if(risques.includes('Déplacement / piste encombrée')) pool.push("Quels obstacles ou zones encombrées doivent être signalés pendant le briefing ?");
 if(risques.includes('Coactivité')) pool.push("Quelles équipes ou activités peuvent interférer avec notre zone de travail aujourd’hui ?");
 if(val('sstNombre')!=='0' && val('sstNombre')!=='À confirmer') pool.push("Combien de SST sont présents sur le chantier aujourd’hui ?");
 else pool.push("Que doit-on faire avant de démarrer si aucun SST n’est confirmé ?");
 pickTwo(pool);
}

function generate(){
 toggleTravauxType();
 const voies=getVoies();
 let travauxListSelected=only(['Création artères','Pose de CI','Approvisionnement','TSV','Évacuation matière signalisation','Fouilles avec blindage','FBM','Carottage','Matage de support','Mise en place armature','Support platine','Pose consoles','Pose poutres','Approvisionnement matière caténaire','Évacuation matière caténaire']);
 if(val('autresSignalisation') !== 'À compléter') travauxListSelected.push('Autres signalisation : '+val('autresSignalisation'));
 if(val('autresCatenaire') !== 'À compléter') travauxListSelected.push('Autres caténaire : '+val('autresCatenaire'));
 const travaux=travauxListSelected.join(', ') || 'À compléter';
 const voiesTravail=voies.filter(v=>v.travail).map(v=>v.nom);
 const voiesPiste=voies.filter(v=>v.piste).map(v=>v.nom);
 const lamVoies=voies.filter(v=>v.lamVoie).map(v=>v.nom);

 document.getElementById('oChantier').textContent=val('chantier');
 document.getElementById('oDate').textContent=val('date')+' / '+val('horaire');
 document.getElementById('oResp').textContent=val('responsable');
 document.getElementById('oSSTNombre').textContent=val('sstNombre');
 document.getElementById('oPRS').textContent=val('prs');
 document.getElementById('sstAlert').style.display=(val('sstNombre')==='0'||val('sstNombre')==='À confirmer')?'block':'none';
 document.getElementById('oDebriefRetour').textContent=val('debriefRetour');
 document.getElementById('oDebriefPoint').textContent=val('debriefPoint');

 document.getElementById('oVisual').innerHTML=
  'Lieu : <u>'+val('secteur')+'</u><br>'+
  'Voie(s) de travail : <u>'+(voiesTravail.join(", ") || "À compléter")+'</u><br>'+
  'Travail dans la piste : <u>'+(voiesPiste.join(", ") || "À compléter")+'</u><br>'+
  'LAM (Lorry Automoteur) dans la voie : <u>'+(lamVoies.join(", ") || "Non renseigné")+'</u><br>'+
  'PK : <u>'+val('pkDebut')+'</u> au <u>'+val('pkFin')+'</u><br>'+
  'PRS — Point de Rassemblement des Secours : <u>'+val('prs')+'</u><br>'+
  'Travaux prévus : <u>'+travaux+'</u><br>'+
  '<span class="small">'+val('travauxLibre')+'</span>';

 document.getElementById('oS9Table').innerHTML=makeTable(voies,'s9');
 document.getElementById('oS11Table').innerHTML=makeTable(voies,'s11');
 document.getElementById('oEngins').textContent=getEngins();

 generateAnalyseSecuriteVoies();

 generateOtherRisks();
 generateQuestions();
}

renderVoies();
renderEngins();
toggleTravauxType();

;

(function(){
  const OPTIONS = `<option value="">À préciser</option><option>Pelle rail-route</option><option>Nacelle rail-route</option><option>Camion grue rail-route</option><option>Unimog rail-route</option><option>Plateforme caténaire rail-route</option><option>Véhicule caténaire rail-route</option><option>Dérouleuse caténaire rail-route</option><option>Véhicule déroulage câble rail-route</option><option>Grue rail-route</option><option>Porte-outils rail-route</option><option>Camion nacelle rail-route</option><option>Véhicule de maintenance rail-route</option><option>Draisine rail-route</option><option>Chargeuse rail-route</option><option>Dumper rail-route</option><option>Tombereau rail-route</option><option>Tracteur rail-route</option><option>Engin de levage rail-route</option><option>Engin de manutention rail-route</option><option>Véhicule léger rail-route</option><option>Pick-up rail-route</option><option>4x4 rail-route</option><option>Véhicule d’inspection rail-route</option><option>Véhicule secours rail-route</option><option>Camion atelier rail-route</option><option>Hydrocureur rail-route</option><option>Aspiratrice rail-route</option><option>Véhicule nettoyage rail-route</option><option>Véhicule tunnel rail-route</option><option>Locotracteur rail-route</option><option>Bourreuse légère rail-route</option><option>Soudeuse rail-route</option><option>Perceuse traverses rail-route</option><option>Tronçonneuse rail-route</option><option>Engin ballast rail-route</option><option>Engin terrassement rail-route</option><option>Engin mixte route/rail</option><option>Multi Wizard</option><option>Rescue Wizard</option><option>Hydro Wizard</option><option>Skyrailer</option><option>Colmar rail-route</option><option>Geismar rail-route</option><option>ZAGRO rail-route</option><option>Trackmobile rail-route</option>`;

  window.toggleLamDetails = function(i){
    const cb = document.getElementById("lamVoie"+i);
    const box = document.getElementById("lamDetails"+i);
    if(!cb || !box) return;
    box.style.display = cb.checked ? "block" : "none";
    if(cb.checked) renderLamTypes(i);
  };

  window.renderLamTypes = function(i){
    const nb = parseInt(document.getElementById("lamNb"+i)?.value || "1");
    const c = document.getElementById("lamTypesContainer"+i);
    if(!c) return;
    const old = [];
    for(let j=0;j<nb;j++){
      old.push({
        type: document.getElementById("lamType_"+i+"_"+j)?.value || "",
        nom: document.getElementById("lamName_"+i+"_"+j)?.value || ""
      });
    }
    c.innerHTML = "";
    for(let j=0;j<nb;j++){
      const div = document.createElement("div");
      div.className = "lam-type-card";
      div.innerHTML =
        '<label>LAM (Lorry Automoteur) / engin rail-route ' + (j+1) + ' — type</label>' +
        '<select id="lamType_' + i + '_' + j + '" onchange="generate()">' + OPTIONS + '</select>' +
        '<label>Nom / identification</label>' +
        '<input type="text" id="lamName_' + i + '_' + j + '" placeholder="Ex : LAM 01, Pelle RR ETF..." oninput="generate()">';
      c.appendChild(div);
      if(old[j]){
        document.getElementById("lamType_"+i+"_"+j).value = old[j].type;
        document.getElementById("lamName_"+i+"_"+j).value = old[j].nom;
      }
    }
  };

  window.getLamDetailsByVoie = function(){
    const details = [];
    document.querySelectorAll('[id^="lamVoie"]').forEach(cb=>{
      if(!cb.checked) return;
      const i = cb.id.replace("lamVoie","");
      const voie = document.getElementById("voieNom"+i)?.value || ("Voie "+(parseInt(i)+1));
      const nb = parseInt(document.getElementById("lamNb"+i)?.value || "1");
      const engins = [];
      for(let j=0;j<nb;j++){
        engins.push({
          type: document.getElementById("lamType_"+i+"_"+j)?.value || "À préciser",
          nom: document.getElementById("lamName_"+i+"_"+j)?.value || "À préciser"
        });
      }
      details.push({voie, nb, engins});
    });
    return details;
  };

  function hasLam(){ return document.querySelectorAll('[id^="lamVoie"]:checked').length > 0; }
  function hasOtherEngin(){
    const nb = parseInt(document.getElementById("nbEngins")?.value || "0");
    if(nb === 0) return false;
    return Array.from(document.querySelectorAll('[id^="enginType"]')).some(s=>s.value && s.value !== "Aucun" && s.value !== "À compléter");
  }
  function findEnginRiskBlock(){
    const title = Array.from(document.querySelectorAll(".block-title")).find(t=>t.textContent.includes("Risque de heurt par un engin"));
    return title ? title.closest(".block") : null;
  }
  function updateLamRule(){
    const type = document.getElementById("typeMiseVoie")?.value || "plateforme";
    const alert = document.getElementById("lamAlertInfo");
    if(!alert) return;
    if(type === "plateforme"){
      alert.className = "lam-alert-info";
      alert.innerHTML = "Mise en voie sur plateforme aménagée : possibilité de mettre en voie l’engin sans mise hors tension caténaire.";
    }else{
      alert.className = "lam-alert-info lam-alert-danger";
      alert.innerHTML = "⚠ Point sans plateforme aménagée : mise hors tension de la caténaire obligatoire pour engager la LAM / l’engin rail-route.";
    }
  }
  function updateLamDisplay(){
    document.querySelectorAll('[id^="lamVoie"]').forEach(cb=>toggleLamDetails(cb.id.replace("lamVoie","")));
    const lam = hasLam();
    const box = document.getElementById("lamMiseVoieBox");
    if(box) box.style.display = lam ? "block" : "none";
    const risk = findEnginRiskBlock();
    if(risk) risk.style.display = (lam || hasOtherEngin()) ? "block" : "none";
    updateLamRule();

    const recap = document.getElementById("oMiseVoieLamBriefing");
    if(recap){
      if(!lam){
        recap.style.display = "none";
        recap.innerHTML = "";
      }else{
        const point = document.getElementById("pointMiseVoie")?.value || "À préciser";
        const voie = document.getElementById("voieMiseVoie")?.value || "À préciser";
        const type = document.getElementById("typeMiseVoie")?.value || "plateforme";
        const typeTxt = type === "plateforme" ? "plateforme aménagée" : "point sans plateforme aménagée";
        const rule = type === "plateforme" ? "Possibilité de mise en voie sans mise hors tension caténaire." : "Mise hors tension de la caténaire obligatoire avant engagement de la LAM (Lorry Automoteur) / engin rail-route.";
        const details = getLamDetailsByVoie();
        const detailHtml = details.map(d=>"<b>"+d.voie+"</b> : "+d.nb+" LAM (Lorry Automoteur) / engin(s)<br>"+d.engins.map((e,k)=>"LAM "+(k+1)+" : "+e.nom+" — "+e.type).join("<br>")).join("<br><br>");
        recap.style.display = "block";
        recap.className = type === "plateforme" ? "lam-briefing-box" : "lam-briefing-box lam-briefing-danger";
        recap.innerHTML = "<b>Mise en voie LAM (Lorry Automoteur) / engin rail-route :</b><br>Point / lieu : <u>"+point+"</u><br>Voie / secteur de mise en voie : <u>"+voie+"</u><br>Détail LAM par voie :<br>"+(detailHtml || "À préciser")+"<br>Type de mise en voie : <u>"+typeTxt+"</u><br><b>"+rule+"</b>";
      }
    }
  }

  const oldGenerate = window.generate;
  window.generate = function(){
    if(typeof oldGenerate === "function") oldGenerate();
    setTimeout(updateLamDisplay, 20);
  };
  document.addEventListener("change", e=>{
    if(e.target.id === "nbEngins" || e.target.id === "typeMiseVoie" || e.target.id?.startsWith("enginType") || e.target.id?.startsWith("lamVoie") || e.target.id?.startsWith("lamNb") || e.target.id?.startsWith("lamType")) setTimeout(updateLamDisplay,50);
  });
  document.addEventListener("input", e=>{
    if(e.target.id === "pointMiseVoie" || e.target.id === "voieMiseVoie" || e.target.id?.startsWith("lamName")) setTimeout(updateLamDisplay,50);
  });
  document.addEventListener("DOMContentLoaded", ()=>setTimeout(updateLamDisplay,400));
})();

(function(){
  const KEY = "briefing_presence_clean_v9";
  let participants = [];
  let editIndex = null;
  let drawing = false;
  let timer = null;
  function id(x){ return document.getElementById(x); }
  function canvas(){ return id("presenceCanvas"); }
  function updateTrace(){
    const set = (k,v)=>{ const el=id(k); if(el) el.textContent=v; };
    const voies = [];
    document.querySelectorAll('[id^="voieNom"]').forEach(v=>{ if(v.value.trim()) voies.push(v.value.trim()); });
    set("traceChantier", id("chantier")?.value || "À compléter");
    set("traceHoraire", (id("date")?.value || "À compléter")+" / "+(id("horaire")?.value || "À compléter"));
    set("traceResponsable", id("responsable")?.value || "À compléter");
    set("traceEntreprise", id("entrepriseChantier")?.value || "À compléter");
    set("traceLieu", id("secteur")?.value || "À compléter");
    set("tracePk", (id("pkDebut")?.value || "À compléter")+" au "+(id("pkFin")?.value || "À compléter"));
    set("traceVoies", voies.join(", ") || "À compléter");
  }
  function render(){
    const body = id("presenceRows");
    if(!body) return;
    body.innerHTML = "";
    participants.forEach((p,i)=>{
      const sig = p.signature ? '<img src="' + p.signature + '">' : "";
      const tr = document.createElement("tr");
      tr.innerHTML =
        '<td style="text-align:center;font-weight:bold;">'+(i+1)+'</td><td>'+(p.nom||"")+'</td><td>'+(p.prenom||"")+'</td><td>'+(p.entreprise||"")+'</td><td class="presence-fonction-cell">'+(p.fonction||"")+'</td><td><div class="presence-signature">'+sig+'</div></td><td class="presence-action-col no-print"><div class="presence-row-actions"><button class="btn-blue" type="button" onclick="presenceEdit('+i+')">Modifier</button><button class="btn-red" type="button" onclick="presenceRemove('+i+')">Retirer</button></div></td>';
      body.appendChild(tr);
    });
  }
  function collectFields(){
    const fields = {};
    document.querySelectorAll("input, textarea, select").forEach(el=>{
      if(!el.id || el.closest("#presencePopup")) return;
      fields[el.id] = el.type === "checkbox" ? el.checked : el.value;
    });
    return fields;
  }
  function applyFields(fields){
    if(!fields) return;
    Object.keys(fields).forEach(k=>{
      const el=id(k); if(!el) return;
      if(el.type === "checkbox") el.checked = !!fields[k]; else el.value = fields[k];
    });
  }
  function save(){
    try{
      localStorage.setItem(KEY, JSON.stringify({participants:participants, fields:collectFields()}));
      const st=id("presenceStatus"); if(st) st.textContent="Sauvegardé : "+new Date().toLocaleTimeString();
      return true;
    }catch(e){ alert("Erreur pendant la sauvegarde : "+e.message); return false; }
  }
  function restore(){
    try{
      const raw=localStorage.getItem(KEY);
      if(raw){
        const state=JSON.parse(raw);
        participants=Array.isArray(state.participants)?state.participants:[];
        applyFields(state.fields);
      }
    }catch(e){}
    render(); updateTrace();
  }
  function scheduleSave(){ clearTimeout(timer); timer=setTimeout(save,300); }
  window.presenceOpen = function(){
    editIndex=null;
    id("presencePopupTitle").textContent="Ajouter un participant";
    id("presenceNom").value=""; id("presencePrenom").value=""; id("presenceEntreprise").value=""; if(id("presenceFonction")) id("presenceFonction").value="";
    presenceClearSignature();
    id("presencePopup").style.display="flex";
    setTimeout(()=>id("presenceNom").focus(),100);
  };
  window.presenceEdit = function(i){
    editIndex=i;
    const p=participants[i]||{};
    id("presencePopupTitle").textContent="Modifier un participant";
    id("presenceNom").value=p.nom||""; id("presencePrenom").value=p.prenom||""; id("presenceEntreprise").value=p.entreprise||""; if(id("presenceFonction")) id("presenceFonction").value=p.fonction||"";
    presenceClearSignature();
    if(p.signature){ const img=new Image(); img.onload=()=>canvas().getContext("2d").drawImage(img,0,0,canvas().width,canvas().height); img.src=p.signature; }
    id("presencePopup").style.display="flex";
  };
  window.presenceClose = function(){ id("presencePopup").style.display="none"; editIndex=null; };
  window.presenceClearSignature = function(){ const c=canvas(); if(c) c.getContext("2d").clearRect(0,0,c.width,c.height); };
  window.presenceValidate = function(){
    const data={nom:id("presenceNom").value||"", prenom:id("presencePrenom").value||"", entreprise:id("presenceEntreprise").value||"", fonction:(id("presenceFonction")?.value||""), signature:canvas().toDataURL("image/png")};
    if(editIndex===null) participants.push(data); else participants[editIndex]=data;
    render(); save(); presenceClose();
  };
  window.presenceRemove = function(i){ participants.splice(i,1); render(); save(); };
  window.presenceSave = function(){ updateTrace(); return save(); };
  window.presencePrint = function(){ updateTrace(); render(); save(); setTimeout(()=>window.print(),250); };
  window.presenceReset = function(){ if(confirm("Réinitialiser toute la saisie et les signatures enregistrées sur ce téléphone ?")){ localStorage.removeItem(KEY); location.reload(); } };

  // V52 : purge fiable des signatures uniquement, en conservant les participants.
  window.__nativeClearOnlySignaturesV52 = function(){
    participants = participants.map(p => Object.assign({}, p, {
      signature:"",
      signatureData:"",
      signatureDataUrl:"",
      signatureUrl:"",
      signatureImage:"",
      signatureBase64:"",
      signatureSrc:"",
      signaturePNG:"",
      sign:"",
      img:"",
      dataUrl:"",
      signed:false,
      hasSigned:false,
      isSigned:false,
      signatureDate:"",
      dateSignature:""
    }));

    render();
    save();
    presenceClearSignature();

    const st=id("presenceStatus");
    if(st) st.textContent="Signatures réinitialisées après PDF : "+new Date().toLocaleTimeString();

    return true;
  };


  // V49 : purge fiable des signatures uniquement, en conservant les participants.
  window.__nativeClearOnlySignaturesV49 = function(){
    participants = participants.map(p => Object.assign({}, p, {
      signature:"",
      signatureData:"",
      signatureDataUrl:"",
      signatureUrl:"",
      signatureImage:"",
      signatureBase64:"",
      signatureSrc:"",
      signaturePNG:"",
      sign:"",
      img:"",
      dataUrl:"",
      signed:false,
      hasSigned:false,
      isSigned:false,
      signatureDate:"",
      dateSignature:""
    }));

    render();
    save();
    presenceClearSignature();

    const st=id("presenceStatus");
    if(st) st.textContent="Signatures réinitialisées après PDF : "+new Date().toLocaleTimeString();

    return true;
  };


  // V48 : purge fiable des signatures uniquement, en conservant les participants.
  window.__nativeClearOnlySignaturesV48 = function(){
    participants = participants.map(p => Object.assign({}, p, {
      signature:"",
      signatureData:"",
      signatureDataUrl:"",
      signatureUrl:"",
      signatureImage:"",
      signatureBase64:"",
      signatureSrc:"",
      signaturePNG:"",
      sign:"",
      img:"",
      dataUrl:"",
      signed:false,
      hasSigned:false,
      isSigned:false,
      signatureDate:"",
      dateSignature:""
    }));

    render();
    save();
    presenceClearSignature();

    const st=id("presenceStatus");
    if(st) st.textContent="Signatures réinitialisées après PDF : "+new Date().toLocaleTimeString();

    return true;
  };


  // V47 : purge complète fiable de la feuille de traçabilité depuis le tableau interne natif.
  window.__nativeClearPresenceParticipantsV47 = function(){
    participants = [];
    editIndex = null;
    render();
    save();
    presenceClearSignature();
    const st=id("presenceStatus");
    if(st) st.textContent="Feuille de traçabilité réinitialisée : "+new Date().toLocaleTimeString();
    return true;
  };


  // Réinitialisation fiable des signatures : agit directement sur le tableau interne "participants".
  window.__nativeResetSignaturesOnly = function(){
    participants = participants.map(p => Object.assign({}, p, {
      signature:"",
      signatureData:"",
      signatureDataUrl:"",
      signatureUrl:"",
      signatureImage:"",
      signatureBase64:"",
      signatureSrc:"",
      signaturePNG:"",
      sign:"",
      img:"",
      dataUrl:"",
      signed:false,
      hasSigned:false,
      isSigned:false,
      signatureDate:"",
      dateSignature:""
    }));

    // Nettoyer les sauvegardes connues avant de resauvegarder le tableau propre.
    try{
      Object.keys(localStorage).forEach(k=>{
        const kl = k.toLowerCase();
        if(
          kl.includes("signature") ||
          kl.includes("signed") ||
          kl.includes("resign")
        ){
          localStorage.removeItem(k);
        }
      });
    }catch(e){}

    render();
    save();
    presenceClearSignature();

    const st=id("presenceStatus");
    if(st) st.textContent="Signatures réinitialisées : "+new Date().toLocaleTimeString();

    return true;
  };

  window.presenceResetSignaturesOnly = window.__nativeResetSignaturesOnly;

  window.presenceExport = function(){
    updateTrace(); render(); save();
    const htmlCopy = document.documentElement.outerHTML;
    const blob = new Blob([htmlCopy], {type:"text/html;charset=utf-8"});
    const a = document.createElement("a");
    const chantier = (id("chantier")?.value || "briefing").replace(/[^a-zA-Z0-9_-]+/g,"_");
    a.href = URL.createObjectURL(blob);
    a.download = new Date().toISOString().slice(0,10)+"_"+chantier+"_briefing_signe.html";
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(a.href);
  };
  function setupCanvas(){
    const c=canvas(); if(!c) return;
    const ctx=c.getContext("2d"); ctx.lineWidth=5; ctx.lineCap="round"; ctx.strokeStyle="#111";
    function pos(e){ const r=c.getBoundingClientRect(); const t=e.touches?e.touches[0]:e; return {x:(t.clientX-r.left)*(c.width/r.width), y:(t.clientY-r.top)*(c.height/r.height)}; }
    function start(e){ e.preventDefault(); drawing=true; const p=pos(e); ctx.beginPath(); ctx.moveTo(p.x,p.y); }
    function move(e){ if(!drawing) return; e.preventDefault(); const p=pos(e); ctx.lineTo(p.x,p.y); ctx.stroke(); }
    function end(){ drawing=false; }
    c.addEventListener("mousedown",start); c.addEventListener("mousemove",move); window.addEventListener("mouseup",end);
    c.addEventListener("touchstart",start,{passive:false}); c.addEventListener("touchmove",move,{passive:false}); c.addEventListener("touchend",end);
  }
  function closeKeyboardWhenReady(){
    const n=id("presenceNom"), p=id("presencePrenom"), e=id("presenceEntreprise"), c=canvas();
    if(n?.value.trim() && p?.value.trim() && e?.value.trim()){ if(document.activeElement?.blur) document.activeElement.blur(); setTimeout(()=>c.scrollIntoView({behavior:"smooth", block:"center"}),180); }
  }
  document.addEventListener("input", e=>{ if(["presenceNom","presencePrenom","presenceEntreprise"].includes(e.target.id)){ clearTimeout(timer); timer=setTimeout(closeKeyboardWhenReady,1000); } scheduleSave(); });
  document.addEventListener("change", scheduleSave);
  window.addEventListener("beforeunload", save);
  setInterval(()=>{updateTrace(); save();},5000);
  document.addEventListener("DOMContentLoaded", ()=>{ setupCanvas(); restore(); });
})();

;

(function(){

const LAM_TYPES = [
"Pelle rail-route","Nacelle rail-route","Camion grue rail-route","Unimog rail-route",
"Plateforme caténaire rail-route","Véhicule caténaire rail-route","Dérouleuse caténaire rail-route",
"Véhicule déroulage câble rail-route","Grue rail-route","Porte-outils rail-route",
"Camion nacelle rail-route","Véhicule de maintenance rail-route","Draisine rail-route",
"Chargeuse rail-route","Dumper rail-route","Tombereau rail-route","Tracteur rail-route",
"Engin de levage rail-route","Engin de manutention rail-route","Véhicule léger rail-route",
"Pick-up rail-route","4x4 rail-route","Véhicule d’inspection rail-route",
"Véhicule secours rail-route","Camion atelier rail-route","Hydrocureur rail-route",
"Aspiratrice rail-route","Véhicule nettoyage rail-route","Véhicule tunnel rail-route",
"Locotracteur rail-route","Bourreuse légère rail-route","Soudeuse rail-route",
"Perceuse traverses rail-route","Tronçonneuse rail-route","Engin ballast rail-route",
"Engin terrassement rail-route","Engin mixte route/rail","Multi Wizard","Rescue Wizard",
"Hydro Wizard","Skyrailer","Colmar rail-route","Geismar rail-route","ZAGRO rail-route","Trackmobile rail-route"
];

window.lamData = window.lamData || {};

function qs(id){ return document.getElementById(id); }

window.openLamPopup = function(voieIndex){
  const overlay = qs("lamPopupOverlay");
  const content = qs("lamPopupContent");

  const voieName = qs("voieNom"+voieIndex)?.value || ("Voie "+(parseInt(voieIndex)+1));

  if(!window.lamData[voieIndex]){
    window.lamData[voieIndex] = {
      count:1,
      engins:[{
        nom:"",
        type:"",
        pk:"",
        secteur:voieName,
        miseVoie:"plateforme"
      }]
    };
  }

  const cfg = window.lamData[voieIndex];

  let html = `
    <div class="lam-card">
      <h3 style="margin-top:0;color:#b30000;">${voieName}</h3>

      <label><b>Nombre de LAM (Lorry Automoteur) / engins rail-route dans cette voie</b></label>
      <select id="lamCount_${voieIndex}" onchange="renderLamPopup(${voieIndex})"
        style="width:100%;padding:12px;border-radius:10px;margin-top:6px;">
        <option ${cfg.count==1?'selected':''}>1</option>
        <option ${cfg.count==2?'selected':''}>2</option>
        <option ${cfg.count==3?'selected':''}>3</option>
        <option ${cfg.count==4?'selected':''}>4</option>
        <option ${cfg.count==5?'selected':''}>5</option>
      </select>
    </div>
  `;

  for(let i=0;i<cfg.count;i++){

    if(!cfg.engins[i]){
      cfg.engins[i]={
        nom:"",
        type:"",
        pk:"",
        secteur:voieName,
        miseVoie:"plateforme"
      };
    }

    const e = cfg.engins[i];

    html += `
      <div class="lam-card">
        <h3 style="margin-top:0;">LAM (Lorry Automoteur) / engin ${i+1}</h3>

        <label><b>Nom / identification</b></label>
        <input id="lamNom_${voieIndex}_${i}" value="${e.nom||''}"
          style="width:100%;padding:12px;border-radius:10px;">

        <label style="display:block;margin-top:10px;"><b>Type d'engin rail-route</b></label>
        <select id="lamType_${voieIndex}_${i}"
          style="width:100%;padding:12px;border-radius:10px;">
          ${LAM_TYPES.map(t=>`<option ${e.type===t?'selected':''}>${t}</option>`).join('')}
        </select>

        <label style="display:block;margin-top:10px;"><b>Point / lieu de mise en voie</b></label>
        <input id="lamPk_${voieIndex}_${i}" value="${e.pk||''}"
          placeholder="Ex : PK 58,400"
          style="width:100%;padding:12px;border-radius:10px;">

        <label style="display:block;margin-top:10px;"><b>Voie / secteur de mise en voie</b></label>
        <input id="lamSecteur_${voieIndex}_${i}" value="${e.secteur||voieName}"
          style="width:100%;padding:12px;border-radius:10px;">

        <label style="display:block;margin-top:10px;"><b>Type de mise en voie</b></label>
        <select id="lamMiseVoie_${voieIndex}_${i}"
          onchange="checkLamDanger(${voieIndex},${i})"
          style="width:100%;padding:12px;border-radius:10px;">
          <option value="plateforme" ${e.miseVoie==='plateforme'?'selected':''}>Plateforme aménagée</option>
          <option value="sansPlateforme" ${e.miseVoie==='sansPlateforme'?'selected':''}>Sans plateforme aménagée</option>
        </select>

        <div id="lamDanger_${voieIndex}_${i}"></div>
      </div>
    `;
  }

  content.innerHTML = html;

  overlay.style.display = "flex";

  setTimeout(()=>{
    for(let i=0;i<cfg.count;i++){
      checkLamDanger(voieIndex,i);
    }
  },50);
};

window.renderLamPopup = function(voieIndex){
  const count = parseInt(qs("lamCount_"+voieIndex).value || "1");

  if(!window.lamData[voieIndex]) return;

  window.lamData[voieIndex].count = count;

  while(window.lamData[voieIndex].engins.length < count){
    window.lamData[voieIndex].engins.push({
      nom:"",
      type:"",
      pk:"",
      secteur:"",
      miseVoie:"plateforme"
    });
  }

  openLamPopup(voieIndex);
};

window.checkLamDanger = function(voieIndex, enginIndex){

  const danger = qs("lamDanger_"+voieIndex+"_"+enginIndex);
  if(!danger) return;

  const voieCat = qs("catenaire"+voieIndex)?.value || "";
  const typeMv = qs("lamMiseVoie_"+voieIndex+"_"+enginIndex)?.value || "";

  let html = "";

  if(typeMv === "sansPlateforme" && voieCat.includes("alimentée")){
    html += `
      <div class="lam-danger">
        ⚠ Incompatibilité détectée :
        la mise en voie sans plateforme aménagée impose une mise hors tension caténaire.
        Or la caténaire de cette voie est actuellement déclarée alimentée dans le briefing.
      </div>
    `;
  }

  const voieProt = qs("protection"+voieIndex)?.value || "";
  if(voieProt.includes("Circulée") || voieProt.includes("Annoncée")){
    html += `
      <div class="lam-danger">
        ⚠ Voie contiguë circulée / annoncée :
        limiteur de rotation obligatoire pour l'engin rail-route.
      </div>
    `;
  }

  danger.innerHTML = html;
};

window.saveLamPopup = function(){

  Object.keys(window.lamData).forEach(voieIndex=>{

    const count = parseInt(qs("lamCount_"+voieIndex)?.value || "1");

    window.lamData[voieIndex].count = count;

    for(let i=0;i<count;i++){

      window.lamData[voieIndex].engins[i] = {
        nom: qs("lamNom_"+voieIndex+"_"+i)?.value || "",
        type: qs("lamType_"+voieIndex+"_"+i)?.value || "",
        pk: qs("lamPk_"+voieIndex+"_"+i)?.value || "",
        secteur: qs("lamSecteur_"+voieIndex+"_"+i)?.value || "",
        miseVoie: qs("lamMiseVoie_"+voieIndex+"_"+i)?.value || "plateforme"
      };
    }
  });

  closeLamPopup();

  if(typeof generate === "function"){
    generate();
  }

  updateLamBriefing();
};

window.closeLamPopup = function(){
  qs("lamPopupOverlay").style.display = "none";
};

window.updateLamBriefing = function(){

  const target = document.getElementById("oMiseVoieLamBriefing");
  if(!target) return;

  let out = "";

  Object.keys(window.lamData).forEach(voieIndex=>{

    const voieName = qs("voieNom"+voieIndex)?.value || ("Voie "+(parseInt(voieIndex)+1));

    const cfg = window.lamData[voieIndex];

    if(!cfg || !cfg.engins || !cfg.engins.length) return;

    out += `<div style="margin-bottom:14px;">`;
    out += `<b>${voieName}</b> : ${cfg.count} LAM (Lorry Automoteur) / engin(s)<br>`;

    cfg.engins.forEach((e,idx)=>{

      out += `
        • LAM ${idx+1} :
        <b>${e.nom || 'Sans nom'}</b>
        — ${e.type || 'Type à préciser'}
      `;

      if(idx===0 && e.pk){
        out += `<br>Point / lieu de mise en voie : <u>${e.pk}</u>`;
      }

      if(idx===0 && e.secteur){
        out += `<br>Voie / secteur de mise en voie : <u>${e.secteur}</u>`;
      }

      out += `<br>`;

      if(e.miseVoie === "plateforme"){
        out += `• Mise en voie sur plateforme aménagée : possibilité de mise en voie sans mise hors tension caténaire.<br>`;
      }else{
        out += `
          <div class="lam-danger">
            ⚠ Mise en voie sans plateforme aménagée :
            mise hors tension caténaire obligatoire avant engagement de l'engin.
          </div>
        `;
      }

    });

    out += `</div>`;
  });

  target.innerHTML = out || "Aucune LAM configurée.";
};

document.addEventListener("DOMContentLoaded", ()=>{

  document.querySelectorAll('[id^="lamVoie"]').forEach(cb=>{

    cb.addEventListener("change", function(){

      const voieIndex = this.id.replace("lamVoie","");

      if(this.checked){
        setTimeout(()=>openLamPopup(voieIndex),150);
      }
    });
  });

  setInterval(()=>{
    if(typeof updateLamBriefing === "function"){
      updateLamBriefing();
    }
  },1500);

});

})();

;

(function(){

  function byId(id){ return document.getElementById(id); }

  function setLamButtonsVisibility(){
    document.querySelectorAll('[id^="lamVoie"]').forEach(cb=>{
      const i = cb.id.replace("lamVoie","");
      const btn = byId("lamConfigBtn"+i);
      if(btn) btn.style.display = cb.checked ? "block" : "none";
    });
  }

  function markLamAsWorkedTrack(){
    // Une LAM (Lorry Automoteur) dans la voie doit être considérée comme voie travaillée.
    document.querySelectorAll('[id^="lamVoie"]').forEach(cb=>{
      if(!cb.checked) return;
      const i = cb.id.replace("lamVoie","");
      const voieTravail = byId("voieTravail"+i);
      if(voieTravail && !voieTravail.checked){
        voieTravail.checked = true;
      }
    });
  }

  function updateLamWorkedTextInBriefing(){
    const tableRows = document.querySelectorAll("#oTableCirculation tbody tr, #oCirculationTable tbody tr, table tr");
    // On ne force pas le HTML du tableau s’il n’a pas d’ID stable.
    // Le generate() existant relit les cases voieTravail cochées.
  }

  const oldGenerate = window.generate;
  window.generate = function(){
    markLamAsWorkedTrack();
    if(typeof oldGenerate === "function") oldGenerate();
    setLamButtonsVisibility();
    updateLamWorkedTextInBriefing();
  };

  document.addEventListener("change", function(e){
    if(e.target.id && e.target.id.startsWith("lamVoie")){
      const i = e.target.id.replace("lamVoie","");
      setLamButtonsVisibility();

      if(e.target.checked){
        const voieTravail = byId("voieTravail"+i);
        if(voieTravail) voieTravail.checked = true;
      }

      if(typeof generate === "function") generate();
    }
  });

  // Fermeture du clavier dans la pop-up participant :
  // uniquement quand les 3 champs sont remplis et qu’il n’y a pas eu de saisie depuis 1 seconde.
  let keyboardTimer = null;

  function closeKeyboardIfParticipantReady(){
    const nom = byId("presenceNom");
    const prenom = byId("presencePrenom");
    const entreprise = byId("presenceEntreprise");
    const canvas = byId("presenceCanvas");

    if(!nom || !prenom || !entreprise || !canvas) return;

    if(nom.value.trim() && prenom.value.trim() && entreprise.value.trim()){
      if(document.activeElement && typeof document.activeElement.blur === "function"){
        document.activeElement.blur();
      }
      setTimeout(()=>{
        canvas.scrollIntoView({behavior:"smooth", block:"center"});
      },180);
    }
  }

  document.addEventListener("input", function(e){
    if(["presenceNom","presencePrenom","presenceEntreprise"].includes(e.target.id)){
      clearTimeout(keyboardTimer);
      keyboardTimer = setTimeout(closeKeyboardIfParticipantReady, 1000);
    }
  });

  document.addEventListener("DOMContentLoaded", function(){
    setTimeout(()=>{
      markLamAsWorkedTrack();
      setLamButtonsVisibility();
      if(typeof generate === "function") generate();
    },500);
  });

})();

;

(function(){

  function byId(id){ return document.getElementById(id); }

  function getVoieName(i){
    return byId("voieNom"+i)?.value || ("Voie "+(parseInt(i)+1));
  }

  function getS9(i){
    return byId("voieS9"+i)?.value || byId("protection"+i)?.value || "";
  }

  function hasLamOnVoie(i){
    return !!byId("lamVoie"+i)?.checked;
  }

  function hasEnginOnVoieName(voieName){
    // Recherche dans les engins complémentaires déclarés plus bas.
    const nb = parseInt(byId("nbEngins")?.value || "0");
    for(let k=0;k<nb;k++){
      const type = byId("enginType"+k)?.value || "";
      const voie = byId("enginVoie"+k)?.value || "";
      if(type && type !== "Aucun" && voie && voie.includes(voieName)){
        return true;
      }
    }
    return false;
  }

  function ensureIncompatibilityBox(){
    let box = byId("enginAnnonceIncompatBox");

    // Le meilleur emplacement est sous l'analyse sécurité circulation.
    const anchor =
      byId("oAnalyseSecuriteVoies") ||
      Array.from(document.querySelectorAll(".alert-warning,.alert-danger,.alert-ok")).find(e => e.textContent.includes("Vigilance"))?.parentElement;

    if(!box && anchor){
      box = document.createElement("div");
      box.id = "enginAnnonceIncompatBox";
      anchor.appendChild(box);
    }

    return box;
  }

  function ensureEnginRiskBox(){
    let box = byId("enginAnnonceIncompatRiskBox");
    const anchor = byId("oMiseVoieLamBriefing") || byId("oEngins");

    if(!box && anchor){
      box = document.createElement("div");
      box.id = "enginAnnonceIncompatRiskBox";
      box.className = "lam-briefing-box lam-briefing-danger";
      box.style.marginTop = "8px";
      anchor.parentNode.insertBefore(box, anchor.nextSibling);
    }

    return box;
  }

  function updateEnginAnnonceIncompatibility(){
    const messages = [];
    const riskMessages = [];

    document.querySelectorAll('[id^="voieNom"]').forEach((el)=>{
      const i = el.id.replace("voieNom","");
      const voie = getVoieName(i);
      const s9 = getS9(i);
      const lam = hasLamOnVoie(i);
      const engin = hasEnginOnVoieName(voie);

      if((lam || engin) && (s9 === "Annonce" || s9 === "Circulée")){
        messages.push(
          "⛔ Incompatibilité : " + voie +
          " est utilisée par une LAM / un engin alors que la protection circulation est « " + s9 + " ». " +
          "Un engin ne doit pas travailler dans une voie circulée ou sous annonce. " +
          "La voie doit être interceptée avant engagement de l’engin."
        );

        riskMessages.push(
          voie + " : LAM (Lorry Automoteur) / engin engagé avec protection « " + s9 +
          " » — situation incompatible. Interception obligatoire avant engagement de l’engin. " +
          "L’annonce est réservée au personnel, pas aux engins."
        );
      }
    });

    // Supprimer les anciens messages "vigilance possible" liés à l'annonce si un engin/LAM est concerné.
    document.querySelectorAll(".alert-warning,.lam-briefing-box").forEach(el=>{
      const t = el.textContent || "";
      if(
        t.includes("travail sur") &&
        t.includes("annonce") &&
        t.includes("mesure possible")
      ){
        el.style.display = "none";
      }
    });

    const box = ensureIncompatibilityBox();
    if(box){
      if(messages.length){
        box.innerHTML = messages.map(m => '<div class="alert-danger" style="margin-top:10px;">' + m + '</div>').join("");
        box.style.display = "block";
      }else{
        box.innerHTML = "";
        box.style.display = "none";
      }
    }

    const riskBox = ensureEnginRiskBox();
    if(riskBox){
      if(riskMessages.length){
        riskBox.style.display = "block";
        riskBox.innerHTML =
          "<b>Rappel engins / annonce :</b><br>" +
          riskMessages.map(m => "• " + m).join("<br>");
      }else{
        riskBox.style.display = "none";
        riskBox.innerHTML = "";
      }
    }
  }

  const oldGenerate = window.generate;
  window.generate = function(){
    if(typeof oldGenerate === "function") oldGenerate();
    setTimeout(updateEnginAnnonceIncompatibility, 80);
  };

  document.addEventListener("change", function(e){
    if(
      e.target.id?.startsWith("voieS9") ||
      e.target.id?.startsWith("protection") ||
      e.target.id?.startsWith("lamVoie") ||
      e.target.id?.startsWith("enginType") ||
      e.target.id?.startsWith("enginVoie")
    ){
      setTimeout(updateEnginAnnonceIncompatibility, 80);
    }
  });

  document.addEventListener("input", function(e){
    if(e.target.id?.startsWith("enginVoie")){
      setTimeout(updateEnginAnnonceIncompatibility, 80);
    }
  });

  document.addEventListener("DOMContentLoaded", function(){
    setTimeout(updateEnginAnnonceIncompatibility, 600);
  });

})();

;

(function(){

  function getCheckedLamIndexes(){
    return Array.from(document.querySelectorAll('input[id^="lamVoie"]'))
      .filter(cb => cb.checked)
      .map(cb => cb.id.replace("lamVoie",""));
  }

  function refreshGlobalLamButton(){
    // Sécurité : supprimer/masquer tout bouton individuel qui aurait été recréé par renderVoies().
    document.querySelectorAll("button").forEach(btn=>{
      const txt = (btn.textContent || "").trim();
      if(txt === "Configurer les LAM" && btn.id !== "singleLamConfigBtn"){
        btn.remove();
      }
      if(btn.id && btn.id.startsWith("lamConfigBtn")){
        btn.remove();
      }
    });

    const btn = document.getElementById("singleLamConfigBtn");
    if(!btn) return;

    if(getCheckedLamIndexes().length > 0){
      btn.classList.add("show");
    }else{
      btn.classList.remove("show");
    }
  }

  window.openGlobalLamConfig = function(){
    const indexes = getCheckedLamIndexes();

    if(!indexes.length){
      alert("Aucune LAM cochée dans les voies.");
      refreshGlobalLamButton();
      return;
    }

    if(typeof openLamPopup === "function"){
      openLamPopup(indexes[0]);
    }else{
      alert("La fenêtre de configuration LAM n’est pas disponible dans cette version.");
    }
  };

  const previousGenerate = window.generate;
  window.generate = function(){
    if(typeof previousGenerate === "function"){
      previousGenerate();
    }
    setTimeout(refreshGlobalLamButton, 60);
  };

  document.addEventListener("change", function(e){
    if(e.target && e.target.id && e.target.id.startsWith("lamVoie")){
      setTimeout(refreshGlobalLamButton, 30);
    }
  });

  document.addEventListener("DOMContentLoaded", function(){
    setTimeout(refreshGlobalLamButton, 150);
    setTimeout(refreshGlobalLamButton, 700);
  });

})();

;

(function(){
  function applyTravauxFromOldSelect(){
    const old = document.getElementById("typeTravaux");
    const sig = document.getElementById("travauxSignalisation");
    const cat = document.getElementById("travauxCatenaire");
    if(old && sig && cat){
      const v = old.value || "";
      sig.checked = v.includes("Signalisation");
      cat.checked = v.includes("Caténaire");
      old.remove();
    }
  }

  function removeInterceptionAnnonceOptions(){
    document.querySelectorAll("select").forEach(sel=>{
      Array.from(sel.options).forEach(opt=>{
        if((opt.textContent || "").trim() === "Interceptée + annonce"){
          opt.remove();
        }
      });
      if(sel.value === "Interceptée + annonce"){
        sel.value = "Annonce";
      }
    });
  }

  const oldGenerate = window.generate;
  window.generate = function(){
    applyTravauxFromOldSelect();
    removeInterceptionAnnonceOptions();
    if(typeof toggleTravauxType === "function") toggleTravauxType();
    if(typeof oldGenerate === "function") oldGenerate();
    setTimeout(()=>{
      removeInterceptionAnnonceOptions();
      if(typeof toggleTravauxType === "function") toggleTravauxType();
    },40);
  };

  document.addEventListener("DOMContentLoaded", function(){
    applyTravauxFromOldSelect();
    removeInterceptionAnnonceOptions();
    if(typeof toggleTravauxType === "function") toggleTravauxType();
  });
})();

;

(function(){
  const AUTO_KEY = "briefing_autosave_enabled_v1";

  function isAutoSaveEnabled(){
    return localStorage.getItem(AUTO_KEY) !== "0";
  }

  function setAutoSaveEnabled(enabled){
    localStorage.setItem(AUTO_KEY, enabled ? "1" : "0");
    refreshAutoSaveButton();
    const status = document.getElementById("presenceStatus");
    if(status){
      status.textContent = enabled ? "Sauvegarde automatique active" : "Sauvegarde automatique désactivée";
    }
  }

  function refreshAutoSaveButton(){
    const btn = document.getElementById("autoSaveToggleBtn");
    if(!btn) return;
    btn.textContent = isAutoSaveEnabled() ? "Désactiver sauvegarde auto" : "Réactiver sauvegarde auto";
    btn.style.background = isAutoSaveEnabled() ? "#555" : "#28709b";
  }

  window.toggleAutoSave = function(){
    setAutoSaveEnabled(!isAutoSaveEnabled());
  };

  // Sauvegarde automatique uniquement si activée.
  const oldPresenceSave = window.presenceSave;
  window.presenceSave = function(){
    if(!isAutoSaveEnabled()) return false;
    if(typeof oldPresenceSave === "function") return oldPresenceSave();
    return true;
  };

  // Corriger la réinitialisation complète : nettoyage des champs visibles + localStorage + reload.
  window.presenceReset = function(){
    if(!confirm("Réinitialiser toute la saisie, les participants et les signatures enregistrées sur ce téléphone ?")) return;

    try{
      Object.keys(localStorage).forEach(k=>{
        if(
          k.toLowerCase().includes("briefing") ||
          k.toLowerCase().includes("presence") ||
          k.toLowerCase().includes("signature") ||
          k.toLowerCase().includes("lam")
        ){
          localStorage.removeItem(k);
        }
      });
    }catch(e){}

    // Nettoyage immédiat avant rechargement
    document.querySelectorAll("input, textarea, select").forEach(el=>{
      if(el.type === "checkbox") el.checked = false;
      else if(el.tagName === "SELECT") el.selectedIndex = 0;
      else el.value = "";
    });

    const rows = document.getElementById("presenceRows");
    if(rows) rows.innerHTML = "";

    setTimeout(()=>location.reload(), 150);
  };

  // Réinitialiser uniquement les signatures, en conservant nom/prénom/entreprise.
  window.presenceResetSignaturesOnly = function(){
    if(!confirm("Effacer uniquement les signatures en conservant les noms, prénoms et entreprises ?")) return;

    // 1) Dans le tableau affiché : supprimer les images de signature
    document.querySelectorAll("#presenceRows tr").forEach(row=>{
      const cells = row.querySelectorAll("td");
      const sigCell = cells[4];
      if(sigCell){
        sigCell.innerHTML = '<div class="presence-signature"></div>';
      }
    });

    // 2) Dans localStorage : retirer les images signatures des différents formats connus
    try{
      Object.keys(localStorage).forEach(k=>{
        const raw = localStorage.getItem(k);
        if(!raw || !(k.toLowerCase().includes("briefing") || k.toLowerCase().includes("presence"))) return;

        try{
          const data = JSON.parse(raw);

          if(Array.isArray(data.participants)){
            data.participants = data.participants.map(p=>Object.assign({}, p, {signature:""}));
          }

          if(Array.isArray(data.participantsTable)){
            data.participantsTable = data.participantsTable.map(p=>Object.assign({}, p, {signature:""}));
          }

          localStorage.setItem(k, JSON.stringify(data));
        }catch(e){}
      });
    }catch(e){}

    const status = document.getElementById("presenceStatus");
    if(status) status.textContent = "Signatures réinitialisées : " + new Date().toLocaleTimeString();

    // Si une fonction render existe, elle relira parfois l'ancien tableau.
    // On force un export visuel propre en gardant les lignes déjà affichées.
  };

  // Intercepter l'autosave répétée si désactivée.
  const originalSetItem = localStorage.setItem.bind(localStorage);
  localStorage.setItem = function(key, value){
    if(!isAutoSaveEnabled()){
      const k = String(key).toLowerCase();
      if(k.includes("briefing") || k.includes("presence") || k.includes("signature")){
        return;
      }
    }
    return originalSetItem(key, value);
  };

  document.addEventListener("DOMContentLoaded", function(){
    refreshAutoSaveButton();

    // Rebrancher les boutons, même si un autre script a repris la main.
    const autoBtn = document.getElementById("autoSaveToggleBtn");
    if(autoBtn) autoBtn.onclick = function(e){ e.preventDefault(); toggleAutoSave(); };

    const resetSig = document.getElementById("resetSignaturesBtn");
    if(resetSig) resetSig.onclick = function(e){ e.preventDefault(); presenceResetSignaturesOnly(); };

    document.querySelectorAll("button").forEach(btn=>{
      const txt = (btn.textContent || "").trim().toLowerCase();

      if(txt.includes("réinitialiser toute la saisie")){
        btn.onclick = function(e){ e.preventDefault(); presenceReset(); };
      }

      if(txt.includes("réinitialiser signatures")){
        btn.onclick = function(e){ e.preventDefault(); presenceResetSignaturesOnly(); };
      }
    });
  });
})();

;

(function(){

  function bindDirectPrint(){
    window.presencePrint = function(){
      try{
        if(typeof generate === "function") generate();
      }catch(e){}
      setTimeout(function(){
        window.print();
      }, 250);
    };

    window.printBriefing = window.presencePrint;

    document.querySelectorAll("button").forEach(function(btn){
      var txt = (btn.textContent || "").toLowerCase();
      if(txt.includes("imprimer") && txt.includes("pdf")){
        btn.onclick = function(e){
          e.preventDefault();
          e.stopPropagation();
          window.presencePrint();
        };
      }
    });
  }

  document.addEventListener("DOMContentLoaded", function(){
    bindDirectPrint();
    setTimeout(bindDirectPrint, 500);
    setTimeout(bindDirectPrint, 1500);
  });

})();

;

(function(){

  function normalize(s){
    return (s || "").replace(/\s+/g," ").trim().toLowerCase();
  }

  function markFormPartsNoPrint(){
    const all = Array.from(document.querySelectorAll("*"));

    all.forEach(el=>{
      const txt = normalize(el.textContent);

      // Masquer le titre "5 — Autres risques"
      if(txt === "5 — autres risques" || txt.startsWith("5 — autres risques")){
        const block = el.closest("section") || el.closest(".card") || el.closest(".panel") || el.parentElement;
        if(block) block.classList.add("force-no-print");
        else el.classList.add("force-no-print");
      }

      // Masquer la zone "Consigne spécifique chantier" dans le formulaire
      if(txt === "consigne spécifique chantier" || txt === "consigne specifique chantier"){
        const parent = el.parentElement;
        if(parent) parent.classList.add("force-no-print");
        el.classList.add("force-no-print");

        // Masquer aussi le champ juste après
        let next = el.nextElementSibling;
        let count = 0;
        while(next && count < 3){
          next.classList.add("force-no-print");
          next = next.nextElementSibling;
          count++;
        }
      }

      // Masquer les boutons formulaire qui se glissent parfois dans l'impression
      if(txt === "mettre à jour la trame" || txt === "imprimer / pdf"){
        el.classList.add("force-no-print");
        const p = el.parentElement;
        if(p) p.classList.add("force-no-print");
      }
    });
  }

  const oldPrint = window.presencePrint;
  window.presencePrint = function(){
    markFormPartsNoPrint();
    if(typeof generate === "function"){
      try{ generate(); }catch(e){}
    }
    setTimeout(()=>{
      markFormPartsNoPrint();
      window.print();
    },250);
  };

  window.addEventListener("beforeprint", markFormPartsNoPrint);

  document.addEventListener("DOMContentLoaded", function(){
    markFormPartsNoPrint();

    document.querySelectorAll("button").forEach(btn=>{
      const txt = normalize(btn.textContent);
      if(txt.includes("imprimer") && txt.includes("pdf")){
        btn.onclick = function(e){
          e.preventDefault();
          e.stopPropagation();
          window.presencePrint();
        };
      }
    });

    setTimeout(markFormPartsNoPrint,500);
    setTimeout(markFormPartsNoPrint,1500);
  });

})();

;

(function(){
  const reglesQuestions = [
    'Règle qui sauve : Je ne m’engage jamais et n’engage jamais du matériel dans la zone dangereuse sans mesures de protection. — Peux-tu expliquer ce que cela implique sur le chantier ?',
    'Règle qui sauve : Je considère toute installation électrique et tout câble électrique comme étant sous tension. — Peux-tu expliquer ce que cela implique sur le chantier ?',
    'Règle qui sauve : Je ne pénètre jamais, sans autorisation, à moins de 3 mètres d’un engin, d’une machine ou d’une charge. — Peux-tu expliquer ce que cela implique sur le chantier ?',
    'Règle qui sauve : Je ne réalise que les missions pour lesquelles je suis autorisé. — Peux-tu expliquer ce que cela implique sur le chantier ?',
    'Règle qui sauve : J’utilise systématiquement et correctement tous les EPI et agrès adaptés à ma mission. — Peux-tu expliquer ce que cela implique sur le chantier ?',
    'Règle qui sauve : Je ne travaille jamais en ayant consommé de l’alcool ou un produit stupéfiant. — Peux-tu expliquer ce que cela implique sur le chantier ?',
    'Règle qui sauve : Je n’utilise jamais de téléphone en conduisant. — Peux-tu expliquer ce que cela implique sur le chantier ?',
    'Règle qui sauve : Je participe au briefing et je m’assure l’avoir compris. — Peux-tu expliquer ce que cela implique sur le chantier ?',
    'Règle qui sauve : J’utilise un téléphone ou une tablette numérique uniquement dans une situation ne présentant pas de danger. — Peux-tu expliquer ce que cela implique sur le chantier ?',
    'Règle qui sauve : Je respecte les consignes d’utilisation des engins et des outils. — Peux-tu expliquer ce que cela implique sur le chantier ?'
  ];
  const reglesReponses = [
    'Réponse attendue : Je ne m’engage jamais et n’engage jamais du matériel dans la zone dangereuse sans mesures de protection.',
    'Réponse attendue : Je considère toute installation électrique et tout câble électrique comme étant sous tension.',
    'Réponse attendue : Je ne pénètre jamais, sans autorisation, à moins de 3 mètres d’un engin, d’une machine ou d’une charge.',
    'Réponse attendue : Je ne réalise que les missions pour lesquelles je suis autorisé.',
    'Réponse attendue : J’utilise systématiquement et correctement tous les EPI et agrès adaptés à ma mission.',
    'Réponse attendue : Je ne travaille jamais en ayant consommé de l’alcool ou un produit stupéfiant.',
    'Réponse attendue : Je n’utilise jamais de téléphone en conduisant.',
    'Réponse attendue : Je participe au briefing et je m’assure l’avoir compris.',
    'Réponse attendue : J’utilise un téléphone ou une tablette numérique uniquement dans une situation ne présentant pas de danger.',
    'Réponse attendue : Je respecte les consignes d’utilisation des engins et des outils.'
  ];

  function addRulesToGlobalArrays(){
    const names = ["questionsPool","questionPool","questions","briefingQuestions","autoQuestions"];
    names.forEach(name=>{
      try{
        if(Array.isArray(window[name])){
          reglesQuestions.forEach(q=>{ if(!window[name].includes(q)) window[name].push(q); });
        }
      }catch(e){}
    });

    const answerNames = ["answersPool","answerPool","reponsesPool","briefingAnswers","autoAnswers"];
    answerNames.forEach(name=>{
      try{
        if(Array.isArray(window[name])){
          reglesReponses.forEach(r=>{ if(!window[name].includes(r)) window[name].push(r); });
        }
      }catch(e){}
    });
  }

  function injectRulesIntoQuestionBox(){
    const boxes = Array.from(document.querySelectorAll("textarea, input[type='text']"));
    const target = boxes.find(el=>{
      const label = (el.previousElementSibling?.textContent || "").toLowerCase();
      const ph = (el.getAttribute("placeholder") || "").toLowerCase();
      return label.includes("question") || ph.includes("question");
    });

    // Si le formulaire possède une zone de questions modifiables en texte libre, on ajoute la liste sans écraser.
    if(target && !target.value.includes("Règle qui sauve")){
      const current = target.value.trim();
      target.value = (current ? current + "\\n" : "") + reglesQuestions.map((q,i)=>`${i+1}. ${q}`).join("\\n");
      target.dispatchEvent(new Event("input", {bubbles:true}));
      target.dispatchEvent(new Event("change", {bubbles:true}));
    }
  }

  function patchGeneratedQuestions(){
    // Ajouter les règles dans le bloc "Questions générées" s'il existe déjà.
    const candidates = Array.from(document.querySelectorAll("div, section")).filter(el=>{
      const t = (el.textContent || "").toLowerCase();
      return t.includes("questions générées") || t.includes("questions generees");
    });

    const box = candidates[0];
    if(box && !box.textContent.includes("Je ne m’engage jamais")){
      const add = document.createElement("div");
      add.className = "regles-questions-addition";
      add.style.marginTop = "10px";
      add.innerHTML = "<strong>Questions possibles sur les 10 règles qui sauvent :</strong><br>" +
        reglesQuestions.map((q,i)=>`<label style="display:block;margin-top:6px;"><input class="briefing-check" type="checkbox"> ${i+1}. ${q}</label><div style="color:#216b25;margin-left:24px;"><strong>${reglesReponses[i]}</strong></div>`).join("");
      box.appendChild(add);
    }
  }

  const oldGenerate = window.generate;
  if(typeof oldGenerate === "function"){
    window.generate = function(){
      addRulesToGlobalArrays();
      const r = oldGenerate.apply(this, arguments);
      setTimeout(patchGeneratedQuestions,80);
      return r;
    };
  }

  document.addEventListener("DOMContentLoaded", function(){
    addRulesToGlobalArrays();
    setTimeout(injectRulesIntoQuestionBox,300);
    setTimeout(patchGeneratedQuestions,600);
  });

  window.reglesQuiSauventQuestions = reglesQuestions;
  window.reglesQuiSauventReponses = reglesReponses;
})();

;

(function(){
  function updateTitle(){
    document.querySelectorAll("*").forEach(el=>{
      const txt = (el.textContent || "").replace(/\s+/g," ").trim();
      if(txt === "Briefing au pied de l’opération" || txt === "Briefing au pied de l'opération"){
        el.textContent = txt + " — Nos vies, notre priorité";
      }
      if(txt === "Débriefing" || txt === "(retour collectif avant démarrage de l’opération)"){
        el.remove();
      }
    });
  }

  const oldGenerate = window.generate;
  if(typeof oldGenerate === "function"){
    window.generate = function(){
      const r = oldGenerate.apply(this, arguments);
      setTimeout(updateTitle,60);
      setTimeout(updateTitle,200);
      return r;
    };
  }

  document.addEventListener("DOMContentLoaded", function(){
    updateTitle();
    setTimeout(updateTitle,500);
  });
})();

;


function openActionsPopup(){
 document.getElementById('actionsOverlay').style.display='flex';
}

function hidePopup(id){
 document.getElementById(id).style.display='none';
}

function overlayClose(e,id){
 if(e.target.id===id){
   hidePopup(id);
 }
}

function openSignatureConfirm(){
 document.getElementById('confirmOverlay').style.display='flex';
}

function openFullResetConfirm(){
 document.getElementById('resetOverlay').style.display='flex';
}

function showToast(text){

 const toast=document.getElementById('toastMessage');

 toast.textContent=text;
 toast.style.display='block';

 clearTimeout(window.toastTimer);

 window.toastTimer=setTimeout(()=>{
   toast.style.display='none';
 },2200);

}

function reactivateAutoSave(){

 try{

   localStorage.setItem('autoSaveDisabled','false');

   if(typeof autoSaveEnabled!=='undefined'){
      autoSaveEnabled=true;
   }

   showToast('Sauvegarde automatique réactivée');

 }catch(e){
   console.log(e);
 }

}

function confirmResetSignatures(){

 hidePopup('confirmOverlay');

 try{

   if(typeof presenceResetSignaturesOnly==='function'){
      presenceResetSignaturesOnly();
   }

   showToast('Signatures supprimées');

 }catch(e){
   console.log(e);
 }

}

function fullResetApplication(){

 try{

   localStorage.clear();
   sessionStorage.clear();

   if(typeof participants!=='undefined'){
      participants=[];
   }

   if(typeof selected!=='undefined'){
      selected=[];
   }

   document.querySelectorAll('input').forEach(el=>{

      if(el.type==='checkbox' || el.type==='radio'){
         el.checked=false;
      }else{
         el.value='';
      }

   });

   document.querySelectorAll('textarea').forEach(el=>{
      el.value='';
   });

   document.querySelectorAll('select').forEach(el=>{
      el.selectedIndex=0;
   });

   document.querySelectorAll('.btn.active').forEach(btn=>{
      btn.classList.remove('active');
   });

   document.querySelectorAll('.briefing-check').forEach(c=>{
      c.checked=false;
   });

   const presenceRows=document.getElementById('presenceRows');
   if(presenceRows){
      presenceRows.innerHTML='';
   }

   [
    'question1','question2',
    'answer1','answer2',
    'oConsigne','oAutresRisques',
    'oVisual','oDebriefPoint',
    'oEngins'
   ].forEach(id=>{
      const el=document.getElementById(id);
      if(el){
         el.innerHTML='';
         el.textContent='';
      }
   });

   document.querySelectorAll('canvas').forEach(c=>{
      const ctx=c.getContext('2d');
      ctx.clearRect(0,0,c.width,c.height);
   });

   hidePopup('resetOverlay');

   showToast('Briefing entièrement réinitialisé');

   setTimeout(()=>{
      location.reload();
   },450);

 }catch(e){

   alert('Erreur pendant la réinitialisation : '+e);

 }

}


;

(function(){

  function byId(id){ return document.getElementById(id); }

  window.safePrintWithSignatures = function(){

    try{
      ['actionsOverlay','confirmOverlay','resetOverlay'].forEach(id=>{
        const el = byId(id);
        if(el) el.style.display = 'none';
      });

      const btn = byId('floatingActionsBtn');
      if(btn) btn.style.display = 'none';

      if(typeof generate === 'function'){
        generate();
      }

      setTimeout(function(){
        window.print();

        setTimeout(function(){
          const b = byId('floatingActionsBtn');
          if(b) b.style.display = '';
        },800);

      },250);

    }catch(e){
      console.log(e);
      window.print();
    }

  };

  function openActionsSafely(){
    const overlay = byId('actionsOverlay');
    if(overlay){
      overlay.style.display = 'flex';
    }else if(typeof openActionsPopup === 'function'){
      openActionsPopup();
    }
  }

  function initActionButton(){

    const btn = byId('floatingActionsBtn');
    if(!btn || btn.dataset.dragReady === 'v4') return;

    btn.dataset.dragReady = 'v4';
    btn.removeAttribute('onclick');

    const saved = localStorage.getItem('floatingActionsPosition');
    if(saved){
      try{
        const pos = JSON.parse(saved);
        if(typeof pos.left === 'number' && typeof pos.top === 'number'){
          btn.style.left = pos.left + 'px';
          btn.style.top = pos.top + 'px';
          btn.style.right = 'auto';
          btn.style.bottom = 'auto';
        }
      }catch(e){}
    }

    let startX = 0;
    let startY = 0;
    let startLeft = 0;
    let startTop = 0;
    let dragging = false;
    let moved = false;
    let pointerId = null;

    function getPoint(e){
      if(e.touches && e.touches.length) return e.touches[0];
      if(e.changedTouches && e.changedTouches.length) return e.changedTouches[0];
      return e;
    }

    function start(e){
      const p = getPoint(e);
      const r = btn.getBoundingClientRect();

      startX = p.clientX;
      startY = p.clientY;
      startLeft = r.left;
      startTop = r.top;
      dragging = true;
      moved = false;

      btn.style.left = startLeft + 'px';
      btn.style.top = startTop + 'px';
      btn.style.right = 'auto';
      btn.style.bottom = 'auto';

      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', end);
      document.addEventListener('touchmove', move, {passive:false});
      document.addEventListener('touchend', end);

      if(e.cancelable) e.preventDefault();
    }

    function move(e){
      if(!dragging) return;

      const p = getPoint(e);
      const dx = p.clientX - startX;
      const dy = p.clientY - startY;

      if(Math.abs(dx) > 10 || Math.abs(dy) > 10){
        moved = true;
      }

      const margin = 8;
      const maxLeft = window.innerWidth - btn.offsetWidth - margin;
      const maxTop = window.innerHeight - btn.offsetHeight - margin;

      const left = Math.min(Math.max(margin, startLeft + dx), maxLeft);
      const top = Math.min(Math.max(margin, startTop + dy), maxTop);

      btn.style.left = left + 'px';
      btn.style.top = top + 'px';

      if(e.cancelable) e.preventDefault();
    }

    function end(e){
      if(!dragging) return;

      dragging = false;

      document.removeEventListener('mousemove', move);
      document.removeEventListener('mouseup', end);
      document.removeEventListener('touchmove', move);
      document.removeEventListener('touchend', end);

      const r = btn.getBoundingClientRect();

      localStorage.setItem('floatingActionsPosition', JSON.stringify({
        left: Math.round(r.left),
        top: Math.round(r.top)
      }));

      if(!moved){
        openActionsSafely();
      }

      setTimeout(()=>{ moved = false; },150);

      if(e && e.cancelable) e.preventDefault();
    }

    btn.addEventListener('mousedown', start);
    btn.addEventListener('touchstart', start, {passive:false});

  }

  document.addEventListener('DOMContentLoaded', initActionButton);
  setTimeout(initActionButton, 300);
  setTimeout(initActionButton, 1000);

})();

;

(function(){

  const reglesQuestions = [
    {
      q: "Avant de débuter une mission, quelle règle impose le port adapté des protections individuelles et des agrès nécessaires ?",
      a: "J’utilise systématiquement et correctement tous les EPI et agrès adaptés à ma mission."
    },
    {
      q: "Quelle règle interdit l’engagement d’un agent ou d’un matériel dans une zone dangereuse sans protection préalable ?",
      a: "Je ne m’engage jamais et n’engage jamais du matériel dans la zone dangereuse sans mesures de protection."
    },
    {
      q: "Lorsqu’un câble électrique est présent et que son état n’est pas identifié, quelle règle doit être appliquée ?",
      a: "Je considère toute installation électrique et tout câble électrique comme étant sous tension."
    },
    {
      q: "Quelle règle concerne l’interdiction de pénétrer à proximité d’un engin, d’une charge ou d’une machine sans autorisation ?",
      a: "Je ne pénètre jamais, sans autorisation, à moins de 3 mètres d’un engin, d’une machine ou d’une charge."
    },
    {
      q: "Quelle règle rappelle qu’un agent ne doit réaliser uniquement les tâches pour lesquelles il est autorisé ?",
      a: "Je ne réalise que les missions pour lesquelles je suis autorisé."
    },
    {
      q: "Quelle règle interdit toute activité professionnelle après consommation d’alcool ou de produits stupéfiants ?",
      a: "Je ne travaille jamais en ayant consommé de l’alcool ou un produit stupéfiant."
    },
    {
      q: "Quelle règle s’applique concernant l’utilisation du téléphone pendant la conduite d’un véhicule ou d’un engin ?",
      a: "Je n’utilise jamais de téléphone en conduisant."
    },
    {
      q: "Lors d’un briefing chantier, quelle règle impose de participer activement et de s’assurer de la bonne compréhension des consignes ?",
      a: "Je participe au briefing et je m’assure de l’avoir compris."
    },
    {
      q: "Quelle règle encadre l’utilisation d’un téléphone ou d’une tablette numérique sur chantier uniquement en absence de danger ?",
      a: "J’utilise un téléphone ou une tablette numérique uniquement dans une situation ne présentant pas de danger."
    },
    {
      q: "Quelle règle impose le respect des consignes d’utilisation des engins, matériels et outils ?",
      a: "Je respecte les consignes d’utilisation des engins et des outils."
    }
  ];

  let currentAnswers = ["", ""];
  let answersVisible = false;

  function setText(id, value){
    const el = document.getElementById(id);
    if(el) el.textContent = value || "";
  }

  function getText(id){
    return document.getElementById(id)?.textContent || "";
  }

  function shuffle(list){
    return [...list].sort(()=>Math.random() - 0.5);
  }

  function getExistingDynamicQuestions(){
    const pool = [];

    try{
      const voies = typeof getVoies === "function" ? getVoies() : [];
      const pkDebut = document.getElementById('pkDebut')?.value || "à préciser";
      const pkFin = document.getElementById('pkFin')?.value || "à préciser";
      const prs = document.getElementById('prs')?.value || "à préciser";

      pool.push({
        q: "Quelles sont les limites PK du chantier ?",
        a: "Les limites à rappeler sont : " + pkDebut + " au " + pkFin + "."
      });

      pool.push({
        q: "Où se situe la PRS, c’est-à-dire le Point de Rassemblement des Secours ?",
        a: "La PRS à rejoindre ou indiquer aux secours est : " + prs + "."
      });

      voies.forEach(v=>{
        pool.push({
          q: "Quelle est la protection circulation prévue sur " + v.nom + " ?",
          a: v.nom + " : " + v.s9 + "."
        });

        pool.push({
          q: "Quel est l’état caténaire sur " + v.nom + " ?",
          a: v.nom + " : " + v.s11 + ". Toute installation est à considérer sous tension tant que la mise hors tension n’est pas confirmée."
        });
      });

    }catch(e){}

    return pool;
  }

  function hideAnswers(){
    answersVisible = false;
    setText('answer1', '');
    setText('answer2', '');
  }

  function showAnswers(){
    answersVisible = true;

    if(!currentAnswers[0] || !currentAnswers[1]){
      const q1 = getText('question1');
      const q2 = getText('question2');

      const pool = [...reglesQuestions, ...getExistingDynamicQuestions()];
      const found1 = pool.find(x=>x.q === q1);
      const found2 = pool.find(x=>x.q === q2);

      currentAnswers[0] = found1?.a || "";
      currentAnswers[1] = found2?.a || "";
    }

    setText('answer1', currentAnswers[0]);
    setText('answer2', currentAnswers[1]);
  }

  function generateQuestionsWithRules(){
    const fullPool = [
      ...reglesQuestions,
      ...getExistingDynamicQuestions()
    ];

    const selected = shuffle(fullPool).slice(0, 2);

    setText('question1', selected[0]?.q || "");
    setText('question2', selected[1]?.q || "");

    currentAnswers = [
      selected[0]?.a || "",
      selected[1]?.a || ""
    ];

    // Comportement demandé :
    // Quand on génère / régénère les questions, les réponses restent masquées.
    hideAnswers();
  }

  window.generateQuestions = generateQuestionsWithRules;

  window.generateAnswers = function(){
    // Le bouton "Générer les réponses" sert maintenant à afficher les réponses.
    showAnswers();
  };

  function ensureButtons(){
    document.querySelectorAll('button').forEach(btn=>{
      const txt = (btn.textContent || '').trim();

      if(txt === 'Changer les questions' || txt === 'Générer automatiquement les questions'){
        btn.textContent = 'Générer automatiquement les questions';
        btn.onclick = generateQuestionsWithRules;
      }

      if(txt === 'Générer les réponses'){
        btn.onclick = showAnswers;
      }
    });
  }

  // Au chargement, si des réponses sont déjà affichées par l'ancien script, on les efface.
  function init(){
    ensureButtons();

    const q1 = getText('question1');
    const q2 = getText('question2');

    const pool = [...reglesQuestions, ...getExistingDynamicQuestions()];
    const found1 = pool.find(x=>x.q === q1);
    const found2 = pool.find(x=>x.q === q2);

    currentAnswers = [
      found1?.a || "",
      found2?.a || ""
    ];

    hideAnswers();
  }

  document.addEventListener('DOMContentLoaded', function(){
    setTimeout(init, 50);
    setTimeout(ensureButtons, 500);
  });

  setTimeout(init, 500);

})();

;

(function(){

  let seconds = 5;
  let timer = null;

  window.closeStartupPopup = function(){
    if(timer) clearInterval(timer);

    const popup = document.getElementById("startupPopup");
    if(!popup) return;

    popup.style.transition = "opacity .5s ease";
    popup.style.opacity = "0";

    setTimeout(()=>{
      popup.style.display = "none";
    },500);
  };

  function startStartupCountdown(){
    const countdown = document.getElementById("startupCountdown");
    const popup = document.getElementById("startupPopup");

    if(!countdown || !popup) return;

    countdown.textContent = seconds;

    timer = setInterval(()=>{
      seconds--;
      countdown.textContent = seconds;

      if(seconds <= 0){
        window.closeStartupPopup();
      }
    },1000);
  }

  document.addEventListener("DOMContentLoaded", startStartupCountdown);

})();

;

(function(){

  window.enginsAutresRR = window.enginsAutresRR || {};

  function byId(id){ return document.getElementById(id); }

  function voieName(i){
    return byId('voieNom'+i)?.value || ('Voie '+(i+1));
  }

  function configText(cfg){
    if(!cfg || !cfg.enabled || !cfg.type || cfg.type === 'Aucun') return '';

    const pos = [];
    if(cfg.piste) pos.push('dans la piste de '+cfg.voie);
    if(cfg.voieDirecte) pos.push('dans la voie '+cfg.voie);

    let txt = cfg.type + ' — ' + (pos.length ? pos.join(' / ') : 'position à préciser');
    if(cfg.obs) txt += ' (' + cfg.obs + ')';
    return txt;
  }

  function addEnginsAutresRRControls(){
    const rows = document.querySelectorAll('#voiesContainer .voie-row');

    rows.forEach((row, i)=>{
      if(row.querySelector('.engin-autre-rr-line')) return;

      const box = document.createElement('div');
      box.className = 'engin-autre-rr-line';
      box.innerHTML = `
        <label>
          <input type="checkbox" id="enginAutreRRCheck${i}" onchange="toggleEnginAutreRR(${i})">
          Engins autre que Rail-route
        </label>
        <button type="button" id="enginAutreRRBtn${i}" class="engin-autre-rr-config-btn" style="display:none;" onclick="openEnginAutreRRPopup(${i})">
          Configurer l’engin autre que RR
        </button>
        <div id="enginAutreRRResume${i}" style="margin-top:8px;font-size:13px;color:#28709b;font-weight:bold;"></div>
      `;
      row.appendChild(box);

      const cfg = window.enginsAutresRR[i];
      if(cfg && cfg.enabled){
        byId('enginAutreRRCheck'+i).checked = true;
        byId('enginAutreRRBtn'+i).style.display = 'block';
        updateEnginAutreRRResume(i);
      }
    });
  }

  window.toggleEnginAutreRR = function(i){
    const checked = byId('enginAutreRRCheck'+i)?.checked;

    if(!window.enginsAutresRR[i]){
      window.enginsAutresRR[i] = {
        enabled:false,
        voie:voieName(i),
        type:'Aucun',
        piste:false,
        voieDirecte:false,
        obs:''
      };
    }

    window.enginsAutresRR[i].enabled = !!checked;
    window.enginsAutresRR[i].voie = voieName(i);

    const btn = byId('enginAutreRRBtn'+i);
    if(btn) btn.style.display = checked ? 'block' : 'none';

    if(checked){
      openEnginAutreRRPopup(i);
    }else{
      updateEnginAutreRRResume(i);
      if(typeof generate === 'function') generate();
    }
  };

  window.openEnginAutreRRPopup = function(i){
    const cfg = window.enginsAutresRR[i] || {
      enabled:true,
      voie:voieName(i),
      type:'Aucun',
      piste:false,
      voieDirecte:false,
      obs:''
    };

    cfg.enabled = true;
    cfg.voie = voieName(i);
    window.enginsAutresRR[i] = cfg;

    byId('enginAutreRRIndex').value = i;
    byId('enginAutreRRVoie').value = cfg.voie;
    byId('enginAutreRRType').value = cfg.type || 'Aucun';
    byId('enginAutreRRPiste').checked = !!cfg.piste;
    byId('enginAutreRRVoieDirecte').checked = !!cfg.voieDirecte;
    byId('enginAutreRRObs').value = cfg.obs || '';

    const overlay = byId('enginAutreRROverlay');
    if(overlay) overlay.style.display = 'flex';
  };

  window.forceCloseEnginAutreRRPopup = function(){
    const overlay = byId('enginAutreRROverlay');
    if(overlay) overlay.style.display = 'none';
  };

  window.closeEnginAutreRRPopup = function(e){
    if(e && e.target && e.target.id === 'enginAutreRROverlay'){
      window.forceCloseEnginAutreRRPopup();
    }
  };

  window.saveEnginAutreRRConfig = function(){
    const i = parseInt(byId('enginAutreRRIndex').value || '0', 10);

    window.enginsAutresRR[i] = {
      enabled:true,
      voie:voieName(i),
      type:byId('enginAutreRRType').value || 'Aucun',
      piste:byId('enginAutreRRPiste').checked,
      voieDirecte:byId('enginAutreRRVoieDirecte').checked,
      obs:byId('enginAutreRRObs').value || ''
    };

    const check = byId('enginAutreRRCheck'+i);
    if(check) check.checked = true;

    const btn = byId('enginAutreRRBtn'+i);
    if(btn) btn.style.display = 'block';

    updateEnginAutreRRResume(i);
    window.forceCloseEnginAutreRRPopup();

    if(typeof generate === 'function') generate();
  };

  function updateEnginAutreRRResume(i){
    const el = byId('enginAutreRRResume'+i);
    if(!el) return;

    const txt = configText(window.enginsAutresRR[i]);
    el.textContent = txt ? ('Configuré : '+txt) : '';
  }

  function getEnginsAutresRRList(){
    return Object.keys(window.enginsAutresRR)
      .sort((a,b)=>parseInt(a)-parseInt(b))
      .map(k=>configText(window.enginsAutresRR[k]))
      .filter(Boolean);
  }

  const oldGetEnginsList = window.getEnginsList;
  window.getEnginsList = function(){
    const legacy = typeof oldGetEnginsList === 'function' ? oldGetEnginsList() : [];
    return legacy.concat(getEnginsAutresRRList());
  };

  window.getEngins = function(){
    let all = [];

    try{
      const lamList = typeof getVoies === "function"
        ? getVoies().filter(v=>v.lamVoie).map(v=>"LAM (Lorry Automoteur) dans la voie "+v.nom)
        : [];
      all = all.concat(lamList);
    }catch(e){}

    all = all.concat(getEnginsAutresRRList());

    return all.length ? all.join(", ") : "À compléter";
  };

  const oldRenderVoies = window.renderVoies;
  window.renderVoies = function(){
    if(typeof oldRenderVoies === 'function') oldRenderVoies();
    setTimeout(addEnginsAutresRRControls, 50);
  };

  const oldGenerate = window.generate;
  window.generate = function(){
    if(typeof oldGenerate === 'function') oldGenerate();

    addEnginsAutresRRControls();

    Object.keys(window.enginsAutresRR).forEach(k=>{
      if(window.enginsAutresRR[k]) window.enginsAutresRR[k].voie = voieName(parseInt(k));
      updateEnginAutreRRResume(parseInt(k));
    });

    const oEngins = byId('oEngins');
    if(oEngins) oEngins.textContent = window.getEngins();

    try{
      const title = Array.from(document.querySelectorAll(".block-title"))
        .find(t=>t.textContent.includes("Risque de heurt par un engin"));
      const block = title ? title.closest(".block") : null;
      if(block && getEnginsAutresRRList().length) block.style.display = "block";
    }catch(e){}
  };

  function hideOldEnginsNumberSection(){
    // On garde le complément général travaux, mais on masque l'ancien sélecteur global d'engins
    const nb = byId('nbEngins');
    if(!nb) return;

    let current = nb.parentElement;
    for(let i=0;i<5 && current;i++){
      if(current.classList && current.classList.contains('card')) break;
      current = current.parentElement;
    }

    const label = Array.from(document.querySelectorAll('label')).find(l=>l.getAttribute('for') === 'nbEngins' || (l.textContent||'').includes('Nombre d’engins'));
    if(label) label.style.display = 'none';
    nb.style.display = 'none';

    const cont = byId('enginsContainer');
    if(cont) cont.style.display = 'none';
  }

  function init(){
    addEnginsAutresRRControls();
    hideOldEnginsNumberSection();
    if(typeof generate === 'function') generate();
  }

  document.addEventListener('DOMContentLoaded', init);
  setTimeout(init, 500);
  setTimeout(init, 1200);

})();

;

(function(){

  function byId(id){ return document.getElementById(id); }

  function voieName(i){
    return byId('voieNom'+i)?.value || ('Voie '+(i+1));
  }

  function getEnginAutreConfigByIndex(i){
    if(!window.enginsAutresRR) window.enginsAutresRR = {};
    const cfg = window.enginsAutresRR[i];

    if(!cfg || !cfg.enabled || !cfg.type || cfg.type === 'Aucun') return null;

    cfg.voie = voieName(i);
    return cfg;
  }

  function formatEnginAutreRR(i){
    const cfg = getEnginAutreConfigByIndex(i);
    if(!cfg) return '';

    const positions = [];
    if(cfg.piste) positions.push('dans la piste de '+cfg.voie);
    if(cfg.voieDirecte) positions.push('dans la voie '+cfg.voie);

    let txt = cfg.type + ' — ' + (positions.length ? positions.join(' / ') : 'position à préciser');

    if(cfg.obs){
      txt += ' (' + cfg.obs + ')';
    }

    return txt;
  }

  window.getEnginsAutresRRListV20 = function(){
    if(!window.enginsAutresRR) return [];

    return Object.keys(window.enginsAutresRR)
      .sort((a,b)=>parseInt(a)-parseInt(b))
      .map(k=>formatEnginAutreRR(parseInt(k)))
      .filter(Boolean);
  };

  function getLamList(){
    try{
      return typeof getVoies === 'function'
        ? getVoies().filter(v=>v.lamVoie).map(v=>'LAM (Lorry Automoteur) dans la voie '+v.nom)
        : [];
    }catch(e){
      return [];
    }
  }

  window.getEngins = function(){
    const all = [
      ...getLamList(),
      ...window.getEnginsAutresRRListV20()
    ];

    return all.length ? all.join(', ') : 'À compléter';
  };

  const oldMakeTable = window.makeTable;

  window.makeTable = function(rows, type){

    if(type === 's11'){
      if(typeof oldMakeTable === 'function'){
        return oldMakeTable(rows, type);
      }

      let html = "<table><tr><th>Voie</th><th>État caténaire</th></tr>";
      rows.forEach(r=>{
        html += `<tr><td><b>${r.nom}</b></td><td>${r.s11}</td></tr>`;
      });
      return html + "</table>";
    }

    let html = "<table><tr><th>Voie</th><th>Protection SNCF circulation</th><th>PK voie / zone</th><th>Configuration travaux</th></tr>";

    rows.forEach((r, i)=>{
      const config = [];

      if(r.travail) config.push("Voie de travail");
      if(r.piste) config.push("Travail dans la piste");
      if(r.lamVoie) config.push("LAM (Lorry Automoteur) dans la voie");

      const enginAutre = formatEnginAutreRR(i);
      if(enginAutre){
        config.push("Engin autre que rail-route : " + enginAutre);
      }

      const pk = r.pkDifferent ? `${r.pkDebut} au ${r.pkFin}` : `${(byId('pkDebut')?.value || 'À compléter')} au ${(byId('pkFin')?.value || 'À compléter')}`;

      html += `<tr>
        <td><b>${r.nom}</b></td>
        <td>${r.s9}</td>
        <td>${pk}</td>
        <td>${config.join(" / ") || "-"}</td>
      </tr>`;
    });

    return html + "</table>";
  };

  const oldAnalyse = window.generateAnalyseSecuriteVoies;

  window.generateAnalyseSecuriteVoies = function(){

    if(typeof oldAnalyse === 'function'){
      oldAnalyse();
    }

    const container = byId('oAnalyseSecuriteVoies');
    if(!container || typeof getVoies !== 'function') return;

    const voies = getVoies();
    const alerts = [];

    voies.forEach((v, i)=>{
      const cfg = getEnginAutreConfigByIndex(i);
      if(!cfg) return;

      if((cfg.piste || cfg.voieDirecte) && v.s9 === 'Circulée'){
        alerts.push(
          `Attention : ${v.nom} — engin autre que rail-route engagé avec protection « Circulée ». Situation incompatible : interception ou protection adaptée obligatoire avant engagement de l’engin.`
        );
      }
    });

    if(alerts.length){
      container.innerHTML += alerts.map(txt=>`
        <div class="alert-danger">⚠ ${txt}</div>
      `).join('');
    }
  };

  function forceEnginRiskBlockVisible(){
    const hasEngin = window.getEnginsAutresRRListV20().length > 0 || getLamList().length > 0;

    const title = Array.from(document.querySelectorAll(".block-title"))
      .find(t=>t.textContent.includes("Risque de heurt par un engin"));

    const block = title ? title.closest(".block") : null;

    if(block && hasEngin){
      block.style.display = "block";
    }
  }

  const oldGenerate = window.generate;

  window.generate = function(){
    if(typeof oldGenerate === 'function') oldGenerate();

    const oEngins = byId('oEngins');
    if(oEngins){
      oEngins.textContent = window.getEngins();
    }

    const s9Table = byId('oS9Table');
    if(s9Table && typeof getVoies === 'function'){
      s9Table.innerHTML = window.makeTable(getVoies(), 's9');
    }

    forceEnginRiskBlockVisible();
  };

  const oldToggleEnginAutreRR = window.toggleEnginAutreRR;

  window.toggleEnginAutreRR = function(i){
    if(typeof oldToggleEnginAutreRR === 'function'){
      oldToggleEnginAutreRR(i);
    }

    setTimeout(()=>{
      forceEnginRiskBlockVisible();
      if(typeof generate === 'function') generate();
    },150);
  };

  const oldSaveEnginAutreRRConfig = window.saveEnginAutreRRConfig;

  window.saveEnginAutreRRConfig = function(){
    if(typeof oldSaveEnginAutreRRConfig === 'function'){
      oldSaveEnginAutreRRConfig();
    }

    setTimeout(()=>{
      forceEnginRiskBlockVisible();
      if(typeof generate === 'function') generate();
    },120);
  };

  function init(){
    if(typeof generate === 'function') generate();
  }

  document.addEventListener('DOMContentLoaded', init);
  setTimeout(init, 500);
  setTimeout(init, 1200);

})();

;

(function(){

function showRiskBlock(){
  const blocks = Array.from(document.querySelectorAll('*'));
  const target = blocks.find(el =>
    el.textContent &&
    el.textContent.includes('Risque de heurt par un engin')
  );

  if(target){
    let parent = target;
    for(let i=0;i<6;i++){
      if(parent.parentElement) parent = parent.parentElement;
    }
    parent.style.display='block';
  }
}

document.addEventListener('change', (e)=>{
  const txt = (e.target.parentElement?.textContent || '');

  if(txt.includes('Engins autre que Rail-route')){
    setTimeout(showRiskBlock,100);

    if(typeof generate === 'function'){
      setTimeout(()=>generate(),120);
    }
  }
});

setTimeout(showRiskBlock,800);

})();

;

(function(){

  function byId(id){ return document.getElementById(id); }

  function getEnginsAutresRRConfigs(){
    if(!window.enginsAutresRR) return [];

    return Object.keys(window.enginsAutresRR)
      .sort((a,b)=>parseInt(a)-parseInt(b))
      .map(k=>{
        const i = parseInt(k);
        const cfg = window.enginsAutresRR[k];
        if(!cfg || !cfg.enabled || !cfg.type || cfg.type === 'Aucun') return null;

        const voie = byId('voieNom'+i)?.value || cfg.voie || ('Voie '+(i+1));

        const positions = [];
        if(cfg.piste) positions.push('dans la piste de '+voie);
        if(cfg.voieDirecte) positions.push('dans la voie '+voie);

        return {
          voie,
          type: cfg.type,
          positions,
          obs: cfg.obs || ''
        };
      })
      .filter(Boolean);
  }

  function formatShort(cfg){
    let txt = cfg.type;
    if(cfg.positions.length){
      txt += ' — ' + cfg.positions.join(' / ');
    }else{
      txt += ' — position à préciser';
    }
    if(cfg.obs) txt += ' (' + cfg.obs + ')';
    return txt;
  }

  function showRiskBlock(){
    const title = Array.from(document.querySelectorAll('.block-title'))
      .find(t => t.textContent.includes('Risque de heurt par un engin'));

    const block = title ? title.closest('.block') : null;

    if(block){
      block.style.display = 'block';
    }

    return block;
  }

  function updateRiskBlock(){

    const configs = getEnginsAutresRRConfigs();
    const hasAutreRR = configs.length > 0;

    if(!hasAutreRR) return;

    const block = showRiskBlock();
    if(!block) return;

    const oEngins = byId('oEngins');
    if(oEngins){
      const existing = oEngins.textContent || '';
      const items = configs.map(formatShort);
      const all = existing && existing !== 'À compléter'
        ? existing.split(', ').concat(items)
        : items;

      oEngins.textContent = [...new Set(all)].join(', ');
    }

    let detail = byId('oEnginsAutresRRBriefing');
    if(!detail){
      detail = document.createElement('div');
      detail.id = 'oEnginsAutresRRBriefing';
      detail.className = 'lam-briefing-box';
      detail.style.display = 'block';

      const content = block.querySelector('.block-content');
      const rep = Array.from(content.children).find(el => el.textContent && el.textContent.includes('Repérage de l’activité'));

      if(rep){
        content.insertBefore(detail, rep);
      }else{
        content.appendChild(detail);
      }
    }

    detail.style.display = 'block';
    detail.innerHTML = `
      <b>Engins autre que Rail-route configurés :</b><br>
      ${configs.map((cfg, idx)=>`
        <div style="margin-top:8px;">
          <b>${cfg.voie}</b> : ${cfg.type}<br>
          • Position : ${cfg.positions.length ? cfg.positions.join(' / ') : 'à préciser'}<br>
          ${cfg.obs ? '• Précisions / observations : '+cfg.obs+'<br>' : ''}
        </div>
      `).join('')}
    `;

    const s9Table = byId('oS9Table');
    if(s9Table && typeof getVoies === 'function' && typeof makeTable === 'function'){
      s9Table.innerHTML = makeTable(getVoies(), 's9');
    }
  }

  const oldGenerate = window.generate;
  window.generate = function(){
    if(typeof oldGenerate === 'function') oldGenerate();
    setTimeout(updateRiskBlock, 80);
  };

  const oldToggle = window.toggleEnginAutreRR;
  window.toggleEnginAutreRR = function(i){
    if(typeof oldToggle === 'function') oldToggle(i);

    const check = byId('enginAutreRRCheck'+i);
    if(check && check.checked){
      showRiskBlock();
    }

    setTimeout(updateRiskBlock, 120);
  };

  const oldSave = window.saveEnginAutreRRConfig;
  window.saveEnginAutreRRConfig = function(){
    if(typeof oldSave === 'function') oldSave();
    setTimeout(updateRiskBlock, 120);
  };

  document.addEventListener('change', function(e){
    if(e.target && e.target.id && e.target.id.startsWith('enginAutreRRCheck')){
      setTimeout(updateRiskBlock, 120);
    }
  });

  document.addEventListener('DOMContentLoaded', function(){
    setTimeout(updateRiskBlock, 600);
  });

  setTimeout(updateRiskBlock, 1000);

})();

;

(function(){

function byId(id){ return document.getElementById(id); }

function hideOnlyOldGlobalEnginsSection(){
  // Ne masque plus les cartes .card ni les parties 1 à 5.
  // On masque uniquement l'ancien bloc global "Engins de chantier autre que rail-route"
  // visible sous "Complément général travaux".
  const titles = Array.from(document.querySelectorAll('h2,h3'))
    .filter(el => (el.textContent || '').trim() === 'Engins de chantier autre que rail-route');

  titles.forEach(title=>{
    title.classList.add('v24-hidden-old-engins');

    let n = title.nextElementSibling;
    let guard = 0;

    while(n && guard < 4){
      const txt = (n.textContent || '').trim();

      if(txt.startsWith('5 — Autres risques')) break;

      // On ne masque que l'encart d'aide / le vieux sélecteur global,
      // pas les sections principales.
      if(
        txt.includes('Renseigner ici les engins de chantier autres que rail-route') ||
        txt.includes('Nombre d’engins de chantier à renseigner') ||
        n.id === 'nbEngins' ||
        n.id === 'enginsContainer'
      ){
        n.classList.add('v24-hidden-old-engins');
      }

      n = n.nextElementSibling;
      guard++;
    }
  });

  const nb = byId('nbEngins');
  if(nb){
    nb.classList.add('v24-hidden-old-engins');
    const lab = Array.from(document.querySelectorAll('label'))
      .find(l => (l.textContent || '').includes('Nombre d’engins de chantier à renseigner'));
    if(lab) lab.classList.add('v24-hidden-old-engins');
  }

  const cont = byId('enginsContainer');
  if(cont) cont.classList.add('v24-hidden-old-engins');

  Array.from(document.querySelectorAll('div')).forEach(el=>{
    const txt = (el.textContent || '').trim();
    if(txt === 'Renseigner ici les engins de chantier autres que rail-route. Ils sont repris dans le risque de heurt par engin / charge.'){
      el.classList.add('v24-hidden-old-engins');
    }
  });
}

function addInfoToEnginAutrePopup(){
  const popup = byId('enginAutreRRPopup');
  if(!popup || byId('v24InfoEnginAutreRR')) return;

  const h2 = popup.querySelector('h2');
  if(!h2) return;

  const info = document.createElement('div');
  info.id = 'v24InfoEnginAutreRR';
  info.className = 'v24-popup-info';
  info.innerHTML = 'Renseigner ici les engins de chantier autres que rail-route.<br>Ils sont repris dans le risque de heurt par engin / charge.';

  h2.insertAdjacentElement('afterend', info);
}

function getVoiesSafe(){
  try{
    return typeof getVoies === 'function' ? getVoies() : [];
  }catch(e){
    return [];
  }
}

function hasLamInVoie(){
  return getVoiesSafe().some(v => !!v.lamVoie);
}

function lamVoies(){
  return getVoiesSafe().filter(v => !!v.lamVoie);
}

function hasLamOnEnergizedCatenary(){
  return lamVoies().some(v => (v.s11 || '').toLowerCase().includes('alimentée'));
}

function isPlateformeNonAmenagee(){
  const type = (byId('typeMiseVoie')?.value || '').toLowerCase();
  return type.includes('sans') || type.includes('non') || type.includes('hors');
}

function updateRisqueElectriqueLamRules(){
  const title = Array.from(document.querySelectorAll('.block-title'))
    .find(t => (t.textContent || '').includes('Risque électrique'));

  const block = title ? title.closest('.block') : null;
  if(!block) return;

  const content = block.querySelector('.block-content') || block;

  let box = byId('v24LamRisqueElectriqueRules');
  if(!box){
    box = document.createElement('div');
    box.id = 'v24LamRisqueElectriqueRules';
    content.appendChild(box);
  }

  if(!hasLamInVoie()){
    box.style.display = 'none';
    box.innerHTML = '';
    return;
  }

  box.style.display = 'block';
  box.className = hasLamOnEnergizedCatenary() ? 'v24-lam-danger' : 'v24-lam-warning';
  box.innerHTML =
    '<b>Rappel spécifique LAM :</b><br>' +
    '• Lorsqu’un LAM est engagé en voie, la mise hors tension caténaire indiquée dans le risque électrique est obligatoire.<br>' +
    '• À défaut de mise hors tension confirmée, le limiteur de hauteur doit être activé et respecté avant tout engagement.';
}

function updateLamPlatformRule(){
  const title = Array.from(document.querySelectorAll('.block-title'))
    .find(t => (t.textContent || '').includes('Risque de heurt par un engin'));

  const block = title ? title.closest('.block') : null;
  if(!block) return;

  const content = block.querySelector('.block-content') || block;

  let box = byId('v24LamPlateformeRule');
  if(!box){
    box = document.createElement('div');
    box.id = 'v24LamPlateformeRule';
    content.appendChild(box);
  }

  if(!hasLamInVoie()){
    box.style.display = 'none';
    box.innerHTML = '';
    return;
  }

  box.style.display = 'block';

  if(hasLamOnEnergizedCatenary() && isPlateformeNonAmenagee()){
    box.className = 'v24-lam-danger';
    box.innerHTML =
      '⚠ <b>Interdiction LAM :</b><br>' +
      'Un LAM mis en voie sur une plateforme non aménagée avec caténaire alimentée est interdit. ' +
      'La mise hors tension caténaire doit être obtenue avant engagement de l’engin.';
  }else{
    box.className = 'v24-lam-warning';
    box.innerHTML =
      '<b>Rappel mise en voie LAM :</b><br>' +
      'Vérifier le type de plateforme de mise en voie, la protection caténaire et l’activation du limiteur de hauteur si la mise hors tension n’est pas confirmée.';
  }
}

function updateV24(){
  hideOnlyOldGlobalEnginsSection();
  addInfoToEnginAutrePopup();
  updateRisqueElectriqueLamRules();
  updateLamPlatformRule();
}

const oldGenerate = window.generate;
window.generate = function(){
  if(typeof oldGenerate === 'function') oldGenerate();
  setTimeout(updateV24, 80);
};

document.addEventListener('DOMContentLoaded', function(){
  updateV24();
  setTimeout(updateV24, 500);
  setTimeout(updateV24, 1200);
});

document.addEventListener('change', function(e){
  if(!e.target || !e.target.id) return;
  if(
    e.target.id === 'typeMiseVoie' ||
    e.target.id.startsWith('lamVoie') ||
    e.target.id.startsWith('voieS11') ||
    e.target.id.startsWith('enginAutreRRCheck')
  ){
    setTimeout(updateV24, 100);
  }
});

setTimeout(updateV24, 1000);

})();

;

(function(){

  function byId(id){ return document.getElementById(id); }

  window.__lamPopupManualOpening = false;

  function isLamPopupOpen(){
    const overlay = byId('lamPopupOverlay');
    return !!(overlay && getComputedStyle(overlay).display !== 'none');
  }

  function openLamConfigOnce(i){
    if(window.__lamPopupManualOpening) return;
    if(isLamPopupOpen()) return;

    window.__lamPopupManualOpening = true;

    setTimeout(function(){
      try{
        if(typeof openLamConfig === 'function'){
          openLamConfig(i);
        }else if(typeof openGlobalLamConfig === 'function'){
          openGlobalLamConfig();
        }else{
          const overlay = byId('lamPopupOverlay');
          if(overlay) overlay.style.display = 'flex';
        }
      }catch(e){
        console.log(e);
      }

      setTimeout(function(){
        window.__lamPopupManualOpening = false;
      },600);
    },80);
  }

  function bindLamCheckboxes(){
    document.querySelectorAll('[id^="lamVoie"]').forEach(cb=>{
      if(cb.dataset.v27LamBound === '1') return;
      cb.dataset.v27LamBound = '1';

      cb.addEventListener('change', function(){
        const i = parseInt(this.id.replace('lamVoie',''), 10);

        if(this.checked){
          openLamConfigOnce(i);
        }

        if(typeof generate === 'function'){
          setTimeout(()=>generate(),100);
        }
      });
    });
  }

  const oldToggleLamDetails = window.toggleLamDetails;
  if(typeof oldToggleLamDetails === 'function' && !oldToggleLamDetails._v27Wrapped){
    window.toggleLamDetails = function(i){
      oldToggleLamDetails.apply(this, arguments);
    };
    window.toggleLamDetails._v27Wrapped = true;
  }

  const oldRenderVoies = window.renderVoies;
  if(typeof oldRenderVoies === 'function' && !oldRenderVoies._v27Wrapped){
    window.renderVoies = function(){
      oldRenderVoies.apply(this, arguments);
      setTimeout(bindLamCheckboxes,80);
    };
    window.renderVoies._v27Wrapped = true;
  }

  const oldGenerate = window.generate;
  if(typeof oldGenerate === 'function' && !oldGenerate._v27Wrapped){
    window.generate = function(){
      oldGenerate.apply(this, arguments);
      setTimeout(bindLamCheckboxes,80);
    };
    window.generate._v27Wrapped = true;
  }

  document.addEventListener('DOMContentLoaded', function(){
    bindLamCheckboxes();
    setTimeout(bindLamCheckboxes,500);
    setTimeout(bindLamCheckboxes,1200);
  });

  setTimeout(bindLamCheckboxes,1000);

})();

;

(function(){

function byId(id){return document.getElementById(id);}
window.briefingPhotos=window.briefingPhotos||[];

function savePhotos(){
  try{localStorage.setItem('briefingPhotos',JSON.stringify(window.briefingPhotos));}catch(e){}
}

function loadPhotos(){
  try{
    const raw=localStorage.getItem('briefingPhotos');
    if(raw) window.briefingPhotos=JSON.parse(raw)||[];
  }catch(e){window.briefingPhotos=[];}
}

function renderPhotos(){
  const grid=byId('photoGrid');
  if(!grid) return;

  grid.innerHTML='';

  if(!window.briefingPhotos.length){
    grid.innerHTML='<div class="photo-help">Aucune photo ajoutée au briefing.</div>';
    return;
  }

  window.briefingPhotos.forEach((p,index)=>{
    const card=document.createElement('div');
    card.className='photo-card';

    card.innerHTML=`
      <img src="${p.src}">
      <textarea placeholder="Ajouter une légende / observation..." onchange="updatePhotoComment(${index}, this.value)">${p.comment||''}</textarea>
      <button type="button" onclick="removePhoto(${index})">Supprimer la photo</button>
    `;

    grid.appendChild(card);
  });
}

window.updatePhotoComment=function(index,value){
  if(!window.briefingPhotos[index]) return;
  window.briefingPhotos[index].comment=value||'';
  savePhotos();
};

window.removePhoto=function(index){
  if(!confirm('Supprimer cette photo du briefing ?')) return;
  window.briefingPhotos.splice(index,1);
  savePhotos();
  renderPhotos();
  if(typeof generate==='function') generate();
};

function handleFiles(files){
  Array.from(files).forEach(file=>{
    if(!file.type.startsWith('image/')) return;

    const reader=new FileReader();

    reader.onload=function(e){
      window.briefingPhotos.push({
        src:e.target.result,
        comment:''
      });

      savePhotos();
      renderPhotos();

      if(typeof generate==='function') generate();
    };

    reader.readAsDataURL(file);
  });
}

function injectPhotoSection(){

  if(byId('photoBriefingSection')) return;

  const target=document.querySelector('.panel')||document.body;

  const section=document.createElement('div');
  section.id='photoBriefingSection';
  section.className='card';

  section.innerHTML=`
    <h2>Photos briefing / chantier</h2>

    <div class="photo-upload-box">

      <div>
        Ajouter des photos directement dans le briefing :
      </div>

      <div class="photo-help">
        Exemples : balisage, LAM, accès chantier, coactivité, état initial, anomalie, protections, engins, consignation, zone travaux.
      </div>

      <div class="photo-upload-actions">

        <label for="photoCameraInput">
          📷 Prendre une photo
        </label>

        <label for="photoGalleryInput">
          🖼 Ajouter depuis le téléphone
        </label>

      </div>

      <input id="photoCameraInput" type="file" accept="image/*" capture="environment" style="display:none;">
      <input id="photoGalleryInput" type="file" accept="image/*" multiple style="display:none;">

      <div id="photoGrid" class="photo-grid"></div>

    </div>
  `;

  target.appendChild(section);

  byId('photoCameraInput').addEventListener('change',function(){
    handleFiles(this.files||[]);
    this.value='';
  });

  byId('photoGalleryInput').addEventListener('change',function(){
    handleFiles(this.files||[]);
    this.value='';
  });

  renderPhotos();
}

function injectPhotosIntoPreview(){

  let container=byId('oPhotosBriefing');

  if(!container){
    container=document.createElement('div');
    container.id='oPhotosBriefing';

    const preview=document.querySelector('.preview');
    if(preview){
      preview.appendChild(container);
    }
  }

  if(!window.briefingPhotos.length){
    container.innerHTML='';
    return;
  }

  container.innerHTML=`
    <div class="block">
      <div class="block-title">Photos chantier / briefing</div>
      <div class="block-content">
        <div class="photo-grid">
          ${window.briefingPhotos.map(p=>`
            <div class="photo-card">
              <img src="${p.src}">
              ${p.comment ? `<div style="padding:10px;font-size:13px;">${p.comment}</div>` : ''}
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  `;
}

const oldGenerate=window.generate;

if(typeof oldGenerate==='function' && !oldGenerate._v28Wrapped){
  window.generate=function(){
    oldGenerate.apply(this,arguments);
    setTimeout(function(){injectPhotosIntoPreview();},80);
  };
  window.generate._v28Wrapped=true;
}

document.addEventListener('DOMContentLoaded',function(){
  loadPhotos();
  setTimeout(function(){
    injectPhotoSection();
    injectPhotosIntoPreview();
  },400);
});

setTimeout(function(){
  injectPhotoSection();
  injectPhotosIntoPreview();
},1200);

})();

;

(function(){

  function hide(id){
    const el = document.getElementById(id);
    if(el) el.style.display = 'none';
  }

  function toast(msg){
    if(typeof showToast === 'function') showToast(msg);
    else console.log(msg);
  }

  function closePopups(){
    hide('actionsOverlay');
    hide('confirmOverlay');
    hide('resetOverlay');
    hide('resignListOverlay');
  }

  function purgeSignatureStorage(){
    try{
      Object.keys(localStorage).forEach(k=>{
        const kl = k.toLowerCase();

        if(kl.includes('signature') || kl.includes('signed') || kl.includes('resign')){
          localStorage.removeItem(k);
          return;
        }

        const raw = localStorage.getItem(k);
        if(!raw || (raw[0] !== '{' && raw[0] !== '[')) return;

        try{
          const data = JSON.parse(raw);
          let touched = false;

          function clean(p){
            if(!p || typeof p !== 'object') return p;

            Object.keys(p).forEach(key=>{
              const kk = key.toLowerCase();
              if(
                kk.includes('signature') ||
                kk.includes('signed') ||
                kk === 'sign' ||
                kk === 'img' ||
                kk === 'dataurl'
              ){
                p[key] = typeof p[key] === 'boolean' ? false : '';
              }
            });

            return Object.assign(p, {
              signature:'',
              signatureData:'',
              signatureDataUrl:'',
              signatureUrl:'',
              signatureImage:'',
              signatureBase64:'',
              signatureSrc:'',
              signaturePNG:'',
              sign:'',
              img:'',
              dataUrl:'',
              signed:false,
              hasSigned:false,
              isSigned:false,
              signatureDate:'',
              dateSignature:''
            });
          }

          if(Array.isArray(data)){
            data.forEach(clean);
            touched = true;
          }

          if(data && typeof data === 'object'){
            ['participants','presenceParticipants','participantsTable'].forEach(prop=>{
              if(Array.isArray(data[prop])){
                data[prop] = data[prop].map(clean);
                touched = true;
              }
            });
          }

          if(touched) localStorage.setItem(k, JSON.stringify(data));
        }catch(e){}
      });
    }catch(e){}
  }

  function clearVisibleSignatures(){
    document.querySelectorAll('#presenceRows tr').forEach(row=>{
      const cells = row.querySelectorAll('td');
      if(cells[4]){
        cells[4].innerHTML = '<div class="presence-signature"></div>';
      }
    });

    document.querySelectorAll('canvas').forEach(c=>{
      try{
        c.getContext('2d').clearRect(0,0,c.width,c.height);
      }catch(e){}
    });
  }

  function resetSignaturesImmediate(){
    closePopups();

    const ok = confirm(
      'Effacer toutes les signatures numériques ?\n\n' +
      'Les noms, prénoms et entreprises seront conservés.'
    );

    if(!ok) return;

    purgeSignatureStorage();

    if(typeof window.__nativeResetSignaturesOnly === 'function'){
      window.__nativeResetSignaturesOnly();
    }else if(typeof window.presenceResetSignaturesOnly === 'function' && window.presenceResetSignaturesOnly !== resetSignaturesImmediate){
      window.presenceResetSignaturesOnly();
    }

    purgeSignatureStorage();
    clearVisibleSignatures();

    setTimeout(()=>{
      purgeSignatureStorage();
      clearVisibleSignatures();
      makeSignatureCellsClickable();
    },250);

    toast('Signatures réinitialisées.');
  }

  function openSignatureByRow(index){
    if(typeof presenceEdit === 'function'){
      presenceEdit(index);
      return;
    }
    if(typeof presenceOpenEdit === 'function'){
      presenceOpenEdit(index);
      return;
    }
    if(typeof presenceOpen === 'function'){
      presenceOpen(index);
      return;
    }
  }

  function makeSignatureCellsClickable(){
    const rows = document.querySelectorAll('#presenceRows tr');

    rows.forEach((tr,index)=>{
      const cells = tr.querySelectorAll('td');

      // Signature seule + nom/prénom/entreprise au besoin
      [1,2,3,4].forEach(i=>{
        if(!cells[i]) return;

        cells[i].style.cursor = 'pointer';
        cells[i].title = 'Cliquer pour signer / modifier la signature';

        cells[i].onclick = function(e){
          e.preventDefault();
          e.stopPropagation();
          openSignatureByRow(index);
        };
      });
    });
  }

  function bindButtons(){
    document.querySelectorAll('button').forEach(btn=>{
      const txt = (btn.textContent || '').toLowerCase();

      if(txt.includes('réinitialiser signatures') || txt.includes('signatures réinitialisées')){
        btn.disabled = false;
        btn.style.opacity = '';
        btn.style.cursor = '';
        btn.textContent = 'Réinitialiser signatures';
        btn.onclick = resetSignaturesImmediate;
      }
    });
  }

  // On remplace toutes les fonctions publiques pour éviter que l’ancien comportement revienne.
  window.openSignatureConfirm = resetSignaturesImmediate;
  window.presenceResetSignaturesOnly = resetSignaturesImmediate;
  window.confirmResetSignatures = resetSignaturesImmediate;

  ['presenceRender','renderPresence','renderPresenceRows'].forEach(fnName=>{
    if(typeof window[fnName] === 'function' && !window[fnName]._v38Wrapped){
      const original = window[fnName];

      window[fnName] = function(){
        const result = original.apply(this, arguments);
        setTimeout(makeSignatureCellsClickable, 80);
        return result;
      };

      window[fnName]._v38Wrapped = true;
    }
  });

  const oldValidate = window.presenceValidate;
  if(typeof oldValidate === 'function' && !oldValidate._v38Wrapped){
    window.presenceValidate = function(){
      const result = oldValidate.apply(this, arguments);
      setTimeout(makeSignatureCellsClickable, 150);
      return result;
    };
    window.presenceValidate._v38Wrapped = true;
  }

  document.addEventListener('DOMContentLoaded', ()=>{
    bindButtons();
    setTimeout(makeSignatureCellsClickable, 300);
    setTimeout(bindButtons, 700);
    setTimeout(makeSignatureCellsClickable, 1000);
  });

  setTimeout(()=>{
    bindButtons();
    makeSignatureCellsClickable();
  },1200);

})();

;

(function(){

  const AUTO_KEY = "briefing_auto_save_enabled_v40";
  const PRESENCE_KEY = "briefing_presence_clean_v9";

  const nativeSetItem = Storage.prototype.setItem;
  const nativeRemoveItem = Storage.prototype.removeItem;
  const nativeClear = Storage.prototype.clear;

  function byId(id){ return document.getElementById(id); }

  function hide(id){
    const el = byId(id);
    if(el) el.style.display = "none";
  }

  function toast(msg){
    if(typeof showToast === "function") showToast(msg);
    else console.log(msg);
  }

  /* =========================
     SAUVEGARDE AUTO
  ========================= */

  function isAutoSaveEnabled(){
    const v = localStorage.getItem(AUTO_KEY);

    if(v === null){
      nativeSetItem.call(localStorage, AUTO_KEY, "true");
      nativeSetItem.call(localStorage, "autoSaveDisabled", "false");
      return true;
    }

    return v === "true";
  }

  function updateAutoSaveButton(){
    const enabled = isAutoSaveEnabled();

    document.querySelectorAll(".btn-auto, #autoSaveToggleBtn").forEach(btn=>{
      if(btn){
        btn.textContent = enabled ? "Désactiver sauvegarde auto" : "Réactiver sauvegarde auto";
        btn.onclick = window.toggleAutoSaveV40;
      }
    });

    window.autoSaveEnabled = enabled;
    window.autoSaveDisabled = !enabled;

    const status = byId("presenceStatus");
    if(status){
      status.textContent = enabled ? "Sauvegarde automatique active" : "Sauvegarde automatique désactivée";
    }
  }

  window.toggleAutoSaveV40 = function(){
    const next = !isAutoSaveEnabled();

    nativeSetItem.call(localStorage, AUTO_KEY, next ? "true" : "false");
    nativeSetItem.call(localStorage, "autoSaveDisabled", next ? "false" : "true");

    window.autoSaveEnabled = next;
    window.autoSaveDisabled = !next;

    updateAutoSaveButton();

    toast(next ? "Sauvegarde automatique réactivée" : "Sauvegarde automatique désactivée");

    if(next){
      try{ if(typeof presenceSave === "function") presenceSave(); }catch(e){}
      try{ if(typeof save === "function") save(); }catch(e){}
    }
  };

  if(!Storage.prototype.setItem._v40Wrapped){
    Storage.prototype.setItem = function(key, value){
      try{
        if(this === localStorage && !isAutoSaveEnabled()){
          const allowed = [AUTO_KEY, "autoSaveDisabled", "floatingActionsPosition"];
          if(!allowed.includes(String(key))) return;
        }
      }catch(e){}

      return nativeSetItem.call(this, key, value);
    };

    Storage.prototype.setItem._v40Wrapped = true;
  }

  /* =========================
     RESET TOTAL SANS REBOOT
  ========================= */

  function clearParticipantObject(p){
    if(!p || typeof p !== "object") return p;

    Object.keys(p).forEach(k=>{
      const kk = k.toLowerCase();

      if(
        kk.includes("signature") ||
        kk.includes("signed") ||
        kk === "sign" ||
        kk === "img" ||
        kk === "dataurl" ||
        kk.includes("canvas")
      ){
        p[k] = typeof p[k] === "boolean" ? false : "";
      }
    });

    return Object.assign(p, {
      nom:"",
      prenom:"",
      entreprise:"",
      signature:"",
      signatureData:"",
      signatureDataUrl:"",
      signatureUrl:"",
      signatureImage:"",
      signatureBase64:"",
      signatureSrc:"",
      signaturePNG:"",
      sign:"",
      img:"",
      dataUrl:"",
      signed:false,
      hasSigned:false,
      isSigned:false,
      signatureDate:"",
      dateSignature:""
    });
  }

  function purgeAllAppStorage(){
    try{
      const autoState = localStorage.getItem(AUTO_KEY);
      const autoDisabled = localStorage.getItem("autoSaveDisabled");
      const floatingPosition = localStorage.getItem("floatingActionsPosition");

      nativeClear.call(localStorage);
      sessionStorage.clear();

      nativeSetItem.call(localStorage, AUTO_KEY, autoState === "false" ? "false" : "true");
      nativeSetItem.call(localStorage, "autoSaveDisabled", autoDisabled === "true" ? "true" : "false");

      if(floatingPosition){
        nativeSetItem.call(localStorage, "floatingActionsPosition", floatingPosition);
      }

      // Sauvegarde propre vide pour empêcher la restauration des anciennes signatures
      nativeSetItem.call(localStorage, PRESENCE_KEY, JSON.stringify({participants:[], fields:{}}));
      nativeSetItem.call(localStorage, "participants", JSON.stringify([]));
      nativeSetItem.call(localStorage, "presenceParticipants", JSON.stringify([]));
      nativeSetItem.call(localStorage, "briefingParticipants", JSON.stringify([]));

    }catch(e){
      console.log(e);
    }
  }

  function clearAllFields(){
    document.querySelectorAll("input").forEach(el=>{
      if(el.type === "checkbox" || el.type === "radio"){
        el.checked = false;
      }else{
        el.value = "";
      }
    });

    document.querySelectorAll("textarea").forEach(el=>el.value = "");

    document.querySelectorAll("select").forEach(el=>{
      el.selectedIndex = 0;
    });

    document.querySelectorAll(".btn.active").forEach(btn=>btn.classList.remove("active"));
    document.querySelectorAll(".briefing-check").forEach(c=>c.checked = false);
  }

  function clearCanvasAndImages(){
    document.querySelectorAll("canvas").forEach(c=>{
      try{
        const ctx = c.getContext("2d");
        ctx.clearRect(0,0,c.width,c.height);
      }catch(e){}
    });

    document.querySelectorAll(".presence-signature").forEach(cell=>{
      cell.innerHTML = "";
      cell.textContent = "";
    });
  }

  function clearTraceability(){
    const rows = byId("presenceRows");
    if(rows) rows.innerHTML = "";

    [
      "traceChantier",
      "traceHoraire",
      "traceResponsable",
      "traceLieu",
      "tracePk",
      "traceVoies"
    ].forEach(id=>{
      const el = byId(id);
      if(el) el.textContent = "À compléter";
    });
  }

  function clearGeneratedBriefing(){
    [
      "question1","question2","answer1","answer2",
      "oConsigne","oAutresRisques","oVisual","oDebriefPoint","oEngins",
      "oChantier","oDate","oResp","oSSTNombre","oPRS",
      "oS9Table","oS11Table","oAnalyseSecuriteVoies",
      "oMiseVoieLamBriefing","oPhotosBriefing"
    ].forEach(id=>{
      const el = byId(id);
      if(el){
        el.innerHTML = "";
        el.textContent = "";
      }
    });
  }

  function clearRuntimeArrays(){
    try{
      if(Array.isArray(window.participants)){
        window.participants.length = 0;
      }
    }catch(e){}

    try{
      if(Array.isArray(window.selected)){
        window.selected.length = 0;
      }
    }catch(e){}

    try{
      if(Array.isArray(window.briefingPhotos)){
        window.briefingPhotos.length = 0;
      }
    }catch(e){}

    try{
      if(window.enginsAutresRR && typeof window.enginsAutresRR === "object"){
        Object.keys(window.enginsAutresRR).forEach(k=>delete window.enginsAutresRR[k]);
      }
    }catch(e){}
  }

  function closeAllPopups(){
    hide("actionsOverlay");
    hide("confirmOverlay");
    hide("resetOverlay");
    hide("resignListOverlay");
    hide("presencePopup");
    hide("startupPopup");

    document.querySelectorAll('[id*="Overlay"], [id*="Popup"]').forEach(el=>{
      if(el.id !== "floatingActionsBtn"){
        if(el.style && getComputedStyle(el).position === "fixed"){
          el.style.display = "none";
        }
      }
    });
  }

  function doFullResetWithoutReload(){
    closeAllPopups();

    // 1. Effacer l’état mémoire avant tout
    clearRuntimeArrays();

    // 2. Effacer tous les champs et signatures visibles
    clearAllFields();
    clearCanvasAndImages();
    clearTraceability();
    clearGeneratedBriefing();

    // 3. Purger toutes les sauvegardes et écrire un état vide propre
    purgeAllAppStorage();

    // 4. Relancer un rendu propre si les fonctions existent, sans recharger l'application
    try{ if(typeof presenceRender === "function") presenceRender(); }catch(e){}
    try{ if(typeof renderPresence === "function") renderPresence(); }catch(e){}
    try{ if(typeof renderPresenceRows === "function") renderPresenceRows(); }catch(e){}

    clearTraceability();
    clearCanvasAndImages();

    // 5. Empêcher une sauvegarde différée de réinjecter les anciennes données
    setTimeout(()=>{
      clearRuntimeArrays();
      purgeAllAppStorage();
      clearTraceability();
      clearCanvasAndImages();
    },250);

    setTimeout(()=>{
      clearRuntimeArrays();
      purgeAllAppStorage();
      clearTraceability();
      clearCanvasAndImages();
      updateAutoSaveButton();
    },800);

    toast("Toute la saisie, les participants et les signatures ont été réinitialisés.");
  }

  window.fullResetApplication = doFullResetWithoutReload;

  window.openFullResetConfirm = function(){
    hide("actionsOverlay");

    const ok = confirm(
      "⚠️ Attention :\n\n" +
      "Cette action va supprimer l’ensemble du briefing :\n" +
      "- toutes les saisies ;\n" +
      "- les cases cochées ;\n" +
      "- les réponses générées ;\n" +
      "- les participants ;\n" +
      "- les entreprises ;\n" +
      "- la feuille de traçabilité ;\n" +
      "- toutes les signatures ;\n" +
      "- les données sauvegardées localement.\n\n" +
      "Souhaitez-vous vraiment continuer ?"
    );

    if(ok) doFullResetWithoutReload();
  };

  function patchButtons(){
    document.querySelectorAll("button").forEach(btn=>{
      const txt = (btn.textContent || "").toLowerCase();

      if(txt.includes("réinitialiser toute la saisie")){
        btn.onclick = window.openFullResetConfirm;
      }

      if(txt.includes("sauvegarde auto")){
        btn.onclick = window.toggleAutoSaveV40;
      }
    });

    updateAutoSaveButton();
  }

  const saveFns = ["save","presenceSave","autoSave","saveState","saveForm"];
  saveFns.forEach(fnName=>{
    if(typeof window[fnName] === "function" && !window[fnName]._v40Wrapped){
      const original = window[fnName];

      window[fnName] = function(){
        if(!isAutoSaveEnabled()) return false;
        return original.apply(this, arguments);
      };

      window[fnName]._v40Wrapped = true;
    }
  });

  document.addEventListener("DOMContentLoaded", ()=>{
    patchButtons();
    setTimeout(patchButtons,500);
    setTimeout(patchButtons,1200);
  });

  setTimeout(patchButtons,1000);

})();

;

(function(){

  function forceUppercase(el){
    if(!el) return;

    el.style.textTransform = "uppercase";

    function convert(){
      const start = el.selectionStart;
      const end = el.selectionEnd;

      el.value = (el.value || "").toUpperCase();

      try{
        el.setSelectionRange(start, end);
      }catch(e){}
    }

    el.addEventListener("input", convert);
    el.addEventListener("change", convert);
    el.addEventListener("blur", convert);

    convert();
  }

  function patchParticipantFields(){

    document.querySelectorAll("input").forEach(input=>{

      const placeholder = (input.placeholder || "").toLowerCase();
      const name = (input.name || "").toLowerCase();
      const id = (input.id || "").toLowerCase();

      const isPrenom =
        placeholder.includes("prénom") ||
        placeholder.includes("prenom") ||
        name.includes("prenom") ||
        id.includes("prenom");

      const isNom =
        !isPrenom &&
        (
          placeholder.includes("nom") ||
          name.includes("nom") ||
          id.includes("nom")
        );

      const isEntreprise =
        placeholder.includes("entreprise") ||
        name.includes("entreprise") ||
        id.includes("entreprise") ||
        placeholder.includes("société");

      // Le prénom reste libre (pas de majuscule forcée)
      if(isPrenom){
        input.style.textTransform = "";
        return;
      }

      // Nom + entreprise en majuscules automatiques
      if(isNom || isEntreprise){

        if(input.dataset.v43Uppercase === "1") return;

        input.dataset.v43Uppercase = "1";

        forceUppercase(input);
      }
    });
  }

  const observer = new MutationObserver(()=>{
    patchParticipantFields();
  });

  observer.observe(document.body,{
    childList:true,
    subtree:true
  });

  document.addEventListener("DOMContentLoaded", ()=>{
    patchParticipantFields();

    setTimeout(patchParticipantFields,500);
    setTimeout(patchParticipantFields,1200);
  });

  setTimeout(patchParticipantFields,1000);

})();

;

(function(){

  function clearAllPhotos(){

    // Tableaux mémoire connus
    try{
      if(Array.isArray(window.briefingPhotos)){
        window.briefingPhotos.length = 0;
      }
    }catch(e){}

    try{
      if(Array.isArray(window.photos)){
        window.photos.length = 0;
      }
    }catch(e){}

    // Supprime les aperçus visuels
    document.querySelectorAll(
      '#oPhotosBriefing, .photos-container, .photo-preview, .photo-item'
    ).forEach(el=>{
      el.innerHTML = '';
    });

    // Supprime les images restantes
    document.querySelectorAll('img').forEach(img=>{
      const src = img.getAttribute('src') || '';

      if(
        src.startsWith('data:image') ||
        img.classList.contains('briefing-photo') ||
        img.classList.contains('photo-preview')
      ){
        img.remove();
      }
    });

    // Réinitialise les inputs file
    document.querySelectorAll('input[type="file"]').forEach(input=>{
      input.value = '';
    });

    // Purge stockage local lié aux photos
    try{
      Object.keys(localStorage).forEach(k=>{
        const kk = k.toLowerCase();

        if(
          kk.includes('photo') ||
          kk.includes('image') ||
          kk.includes('camera')
        ){
          localStorage.removeItem(k);
        }
      });
    }catch(e){}

    try{
      Object.keys(sessionStorage).forEach(k=>{
        const kk = k.toLowerCase();

        if(
          kk.includes('photo') ||
          kk.includes('image') ||
          kk.includes('camera')
        ){
          sessionStorage.removeItem(k);
        }
      });
    }catch(e){}
  }

  // Injection dans le reset complet existant
  const originalReset = window.fullResetApplication;

  if(typeof originalReset === 'function' && !originalReset._v45Wrapped){

    window.fullResetApplication = function(){

      clearAllPhotos();

      return originalReset.apply(this, arguments);
    };

    window.fullResetApplication._v45Wrapped = true;
  }

  // Sécurité supplémentaire
  const originalConfirm = window.openFullResetConfirm;

  if(typeof originalConfirm === 'function' && !originalConfirm._v45Wrapped){

    window.openFullResetConfirm = function(){

      clearAllPhotos();

      return originalConfirm.apply(this, arguments);
    };

    window.openFullResetConfirm._v45Wrapped = true;
  }

})();

;

(function(){

  const PRESENCE_KEY = "briefing_presence_clean_v9";

  function byId(id){ return document.getElementById(id); }
  function hide(id){ const el = byId(id); if(el) el.style.display = "none"; }
  function toast(msg){ if(typeof showToast === "function") showToast(msg); else console.log(msg); }

  function clearPhotosCompletely(){
    try{
      if(Array.isArray(window.briefingPhotos)) window.briefingPhotos.length = 0;
      if(Array.isArray(window.photos)) window.photos.length = 0;
    }catch(e){}

    document.querySelectorAll(".photo-card, .photo-item, .photo-preview, .briefing-photo-card").forEach(el=>el.remove());

    ["photoGrid","oPhotosBriefing"].forEach(id=>{
      const el = byId(id);
      if(el) el.innerHTML = "";
    });

    document.querySelectorAll(".photos-container, .photo-grid, #oPhotosBriefing").forEach(el=>el.innerHTML = "");

    document.querySelectorAll('input[type="file"]').forEach(input=>input.value = "");

    const grid = byId("photoGrid");
    if(grid) grid.innerHTML = '<div class="photo-help">Aucune photo ajoutée au briefing.</div>';

    try{
      Object.keys(localStorage).forEach(k=>{
        const kk = k.toLowerCase();
        if(kk.includes("photo") || kk.includes("image") || kk.includes("camera")) localStorage.removeItem(k);
      });
      Object.keys(sessionStorage).forEach(k=>{
        const kk = k.toLowerCase();
        if(kk.includes("photo") || kk.includes("image") || kk.includes("camera")) sessionStorage.removeItem(k);
      });
    }catch(e){}
  }

  function clearTraceabilityCompletely(){
    const rows = byId("presenceRows");
    if(rows) rows.innerHTML = "";

    try{
      if(typeof window.__nativeClearPresenceParticipantsV47 === "function"){
        window.__nativeClearPresenceParticipantsV47();
      }
    }catch(e){}

    try{
      if(Array.isArray(window.participants)) window.participants.length = 0;
      if(Array.isArray(window.presenceParticipants)) window.presenceParticipants.length = 0;
      if(Array.isArray(window.participantsTable)) window.participantsTable.length = 0;
    }catch(e){}

    try{
      Object.keys(localStorage).forEach(k=>{
        const kk = k.toLowerCase();
        if(kk.includes("presence") || kk.includes("participant") || kk.includes("signature") || kk.includes("signed") || kk.includes("resign")){
          localStorage.removeItem(k);
        }
      });
      localStorage.setItem(PRESENCE_KEY, JSON.stringify({participants:[], fields:{}}));
      localStorage.setItem("participants", JSON.stringify([]));
      localStorage.setItem("presenceParticipants", JSON.stringify([]));
      localStorage.setItem("briefingParticipants", JSON.stringify([]));
    }catch(e){}

    ["traceChantier","traceHoraire","traceResponsable","traceLieu","tracePk","traceVoies"].forEach(id=>{
      const el = byId(id);
      if(el) el.textContent = "À compléter";
    });

    document.querySelectorAll(".presence-signature").forEach(cell=>{
      cell.innerHTML = "";
      cell.textContent = "";
    });

    document.querySelectorAll("canvas").forEach(c=>{
      try{ c.getContext("2d").clearRect(0,0,c.width,c.height); }catch(e){}
    });
  }

  function clearAllFormFields(){
    document.querySelectorAll("input").forEach(el=>{
      if(el.type === "file") el.value = "";
      else if(el.type === "checkbox" || el.type === "radio") el.checked = false;
      else el.value = "";
    });
    document.querySelectorAll("textarea").forEach(el=>el.value = "");
    document.querySelectorAll("select").forEach(el=>el.selectedIndex = 0);
    document.querySelectorAll(".btn.active").forEach(btn=>btn.classList.remove("active"));
    document.querySelectorAll(".briefing-check").forEach(c=>c.checked = false);
  }

  function clearGeneratedAreas(){
    ["question1","question2","answer1","answer2","oConsigne","oAutresRisques","oVisual","oDebriefPoint","oEngins","oChantier","oDate","oResp","oSSTNombre","oPRS","oS9Table","oS11Table","oAnalyseSecuriteVoies","oMiseVoieLamBriefing"].forEach(id=>{
      const el = byId(id);
      if(el){ el.innerHTML = ""; el.textContent = ""; }
    });
  }

  function closeAllPopups(){
    ["actionsOverlay","confirmOverlay","resetOverlay","resignListOverlay","presencePopup"].forEach(hide);
  }

  function doResetAllV47(){
    closeAllPopups();
    clearAllFormFields();
    clearGeneratedAreas();
    clearPhotosCompletely();
    clearTraceabilityCompletely();

    setTimeout(()=>{ clearPhotosCompletely(); clearTraceabilityCompletely(); },250);
    setTimeout(()=>{ clearPhotosCompletely(); clearTraceabilityCompletely(); },900);

    toast("Toute la saisie, les photos, les participants et les signatures ont été réinitialisés.");
  }

  window.fullResetApplication = doResetAllV47;

  window.openFullResetConfirm = function(){
    hide("actionsOverlay");
    const ok = confirm("⚠️ Attention :\n\nCette action va supprimer l’ensemble du briefing :\n- toutes les saisies ;\n- les participants ;\n- les entreprises ;\n- toutes les signatures ;\n- toutes les photos et leurs légendes ;\n- les données sauvegardées localement.\n\nSouhaitez-vous vraiment continuer ?");
    if(ok) doResetAllV47();
  };

  function patchResetButtons(){
    document.querySelectorAll("button").forEach(btn=>{
      const txt = (btn.textContent || "").toLowerCase();
      if(txt.includes("réinitialiser toute la saisie")) btn.onclick = window.openFullResetConfirm;

      if(txt.includes("réinitialiser signatures") && btn.dataset.v47SigPatch !== "1"){
        btn.dataset.v47SigPatch = "1";
        const old = btn.onclick;
        btn.onclick = function(e){
          clearTraceabilityCompletely();
          if(typeof old === "function"){
            try{ old.call(this,e); }catch(_){}
          }
          setTimeout(clearTraceabilityCompletely,200);
          setTimeout(clearTraceabilityCompletely,700);
        };
      }
    });
  }

  document.addEventListener("DOMContentLoaded", ()=>{
    patchResetButtons();
    setTimeout(patchResetButtons,500);
    setTimeout(patchResetButtons,1200);
  });

  setTimeout(patchResetButtons,1000);

})();

;

(function(){

  function byId(id){ return document.getElementById(id); }

  function hide(id){
    const el = byId(id);
    if(el) el.style.display = "none";
  }

  function toast(msg){
    if(typeof showToast === "function") showToast(msg);
    else console.log(msg);
  }

  function closeResignPopup(){
    hide("resignListOverlay");

    Array.from(document.querySelectorAll("div")).forEach(el=>{
      if((el.textContent || "").includes("Participants à faire signer") && getComputedStyle(el).position === "fixed"){
        el.style.display = "none";
      }
    });
  }

  // Empêche le retour de la fenêtre intempestive
  window.presenceOpenResignList = function(){ closeResignPopup(); return false; };
  window.openResignList = function(){ closeResignPopup(); return false; };
  window.refreshParticipantsToSign = function(){ closeResignPopup(); return false; };

  function clearCanvasBeforeOpen(){
    const c = byId("presenceCanvas");
    if(!c) return;

    try{
      const ctx = c.getContext("2d");
      ctx.clearRect(0,0,c.width,c.height);
    }catch(e){}
  }

  function openSignatureFromRow(index){
    closeResignPopup();

    // Important : définir tous les index possibles avant l'ouverture
    window.presenceEditIndex = index;
    window.editPresenceIndex = index;
    window.currentPresenceIndex = index;
    window.currentParticipantIndex = index;
    window.selectedPresenceIndex = index;
    window.signatureParticipantIndex = index;

    try{
      if(typeof presenceEdit === "function"){
        presenceEdit(index);
      }else if(typeof presenceOpenEdit === "function"){
        presenceOpenEdit(index);
      }else if(typeof presenceOpen === "function"){
        presenceOpen(index);
      }
    }catch(e){
      console.log(e);
    }

    // Après purge PDF, la case est vide : le pad doit aussi être vide
    setTimeout(clearCanvasBeforeOpen, 80);
    setTimeout(clearCanvasBeforeOpen, 220);
  }

  function makeSignatureCellsClickable(){
    const rows = document.querySelectorAll("#presenceRows tr");

    rows.forEach((tr,index)=>{
      const cells = tr.querySelectorAll("td");

      // Nom / prénom / entreprise / signature ouvrent la signature
      [1,2,3,4].forEach(i=>{
        const cell = cells[i];
        if(!cell) return;

        cell.style.cursor = "pointer";
        cell.title = "Cliquer pour signer / re-signer";
        cell.dataset.v50Clickable = "1";

        cell.onclick = function(e){
          e.preventDefault();
          e.stopPropagation();
          openSignatureFromRow(index);
        };
      });
    });
  }

  /*
    Après validation, on ne purge rien.
    On laisse la fonction native enregistrer normalement la nouvelle signature.
    On se contente de réactiver les clics sur les cellules.
  */
  if(typeof window.presenceValidate === "function" && !window.presenceValidate._v50Wrapped){
    const originalValidate = window.presenceValidate;

    window.presenceValidate = function(){
      const result = originalValidate.apply(this, arguments);

      setTimeout(()=>{
        closeResignPopup();
        makeSignatureCellsClickable();
        toast("Signature enregistrée.");
      },200);

      return result;
    };

    window.presenceValidate._v50Wrapped = true;
  }

  /*
    Après chaque rendu du tableau, remettre les cellules cliquables.
  */
  ["presenceRender","renderPresence","renderPresenceRows"].forEach(fnName=>{
    if(typeof window[fnName] === "function" && !window[fnName]._v50Wrapped){
      const original = window[fnName];

      window[fnName] = function(){
        const result = original.apply(this, arguments);

        setTimeout(()=>{
          closeResignPopup();
          makeSignatureCellsClickable();
        },80);

        return result;
      };

      window[fnName]._v50Wrapped = true;
    }
  });

  /*
    Après impression PDF, l'ancien script purge les signatures.
    Ici on restaure immédiatement la possibilité de re-signer.
  */
  function refreshAfterPdfPurge(){
    closeResignPopup();
    makeSignatureCellsClickable();
  }

  window.addEventListener("afterprint", ()=>{
    setTimeout(refreshAfterPdfPurge, 600);
    setTimeout(refreshAfterPdfPurge, 1500);
  });

  window.addEventListener("focus", ()=>{
    setTimeout(refreshAfterPdfPurge, 600);
  });

  document.addEventListener("visibilitychange", ()=>{
    if(document.visibilityState === "visible"){
      setTimeout(refreshAfterPdfPurge, 600);
    }
  });

  document.addEventListener("DOMContentLoaded", ()=>{
    setTimeout(refreshAfterPdfPurge, 300);
    setTimeout(refreshAfterPdfPurge, 1000);
  });

  setTimeout(refreshAfterPdfPurge, 1200);

})();

;

(function(){

  const PRESENCE_KEY = "briefing_presence_clean_v9";
  let printStarted = false;
  let purgeDone = false;
  let iframeRef = null;
  let minPrintDelayReached = false;

  function byId(id){ return document.getElementById(id); }
  function hide(id){ const el = byId(id); if(el) el.style.display = "none"; }
  function toast(msg){ if(typeof showToast === "function") showToast(msg); else console.log(msg); }

  function cleanSignatureObject(p){
    if(!p || typeof p !== "object") return p;

    Object.keys(p).forEach(k=>{
      const kk = k.toLowerCase();
      if(
        kk.includes("signature") ||
        kk.includes("signed") ||
        kk === "sign" ||
        kk === "img" ||
        kk === "dataurl" ||
        kk.includes("canvas")
      ){
        p[k] = typeof p[k] === "boolean" ? false : "";
      }
    });

    return Object.assign(p,{
      signature:"",
      signatureData:"",
      signatureDataUrl:"",
      signatureUrl:"",
      signatureImage:"",
      signatureBase64:"",
      signatureSrc:"",
      signaturePNG:"",
      sign:"",
      img:"",
      dataUrl:"",
      signed:false,
      hasSigned:false,
      isSigned:false,
      signatureDate:"",
      dateSignature:""
    });
  }

  function purgeSignatureStorageOnly(){
    try{
      Object.keys(localStorage).forEach(k=>{
        const kk = k.toLowerCase();

        if(kk.includes("signature") || kk.includes("signed") || kk.includes("resign")){
          localStorage.removeItem(k);
          return;
        }

        const raw = localStorage.getItem(k);
        if(!raw || (raw[0] !== "{" && raw[0] !== "[")) return;

        try{
          const data = JSON.parse(raw);
          let touched = false;

          if(Array.isArray(data)){
            data.forEach(item=>{
              if(item && typeof item === "object"){
                const hasSig = Object.keys(item).some(key=>{
                  const lower = key.toLowerCase();
                  return lower.includes("signature") || lower.includes("signed") || lower === "sign" || lower === "img" || lower === "dataurl";
                });
                if(hasSig){
                  cleanSignatureObject(item);
                  touched = true;
                }
              }
            });
            if(touched) localStorage.setItem(k, JSON.stringify(data));
          }

          if(data && typeof data === "object"){
            ["participants","presenceParticipants","participantsTable"].forEach(prop=>{
              if(Array.isArray(data[prop])){
                data[prop] = data[prop].map(cleanSignatureObject);
                touched = true;
              }
            });
            if(touched) localStorage.setItem(k, JSON.stringify(data));
          }
        }catch(e){}
      });

      const raw = localStorage.getItem(PRESENCE_KEY);
      if(raw){
        const state = JSON.parse(raw);
        if(state && Array.isArray(state.participants)){
          state.participants = state.participants.map(cleanSignatureObject);
          localStorage.setItem(PRESENCE_KEY, JSON.stringify(state));
        }
      }
    }catch(e){}
  }

  function clearVisibleSignatureCells(){
    document.querySelectorAll(".presence-signature").forEach(cell=>{
      cell.innerHTML = "";
      cell.textContent = "";
    });

    document.querySelectorAll("#presenceRows tr").forEach(tr=>{
      const cells = tr.querySelectorAll("td");
      if(cells[4]){
        cells[4].innerHTML = '<div class="presence-signature"></div>';
      }
    });

    document.querySelectorAll("canvas").forEach(c=>{
      try{ c.getContext("2d").clearRect(0,0,c.width,c.height); }catch(e){}
    });
  }

  function purgeSignaturesNow(){
    if(purgeDone) return;
    purgeDone = true;
    printStarted = false;

    try{
      if(typeof window.__nativeClearOnlySignaturesV52 === "function"){
        window.__nativeClearOnlySignaturesV52();
      }else if(typeof window.__nativeClearOnlySignaturesV49 === "function"){
        window.__nativeClearOnlySignaturesV49();
      }else if(typeof window.__nativeClearOnlySignaturesV48 === "function"){
        window.__nativeClearOnlySignaturesV48();
      }
    }catch(e){}

    purgeSignatureStorageOnly();
    clearVisibleSignatureCells();

    setTimeout(()=>{
      purgeSignatureStorageOnly();
      clearVisibleSignatureCells();
      toast("Retour PDF détecté : signatures purgées dans l’application.");
    },500);

    setTimeout(()=>{
      try{ if(iframeRef) iframeRef.remove(); }catch(e){}
      iframeRef = null;
    },8000);
  }

  function schedulePurgeAfterReturn(){
    if(!printStarted || purgeDone || !minPrintDelayReached) return;

    /*
      Sécurité confidentialité :
      le navigateur Android ne permet pas à une page HTML de savoir si l'utilisateur
      a réellement appuyé sur le bouton OK/enregistrer du système.
      La purge est donc déclenchée automatiquement au retour dans l'application
      après ouverture du flux PDF, sans message manuel.
    */
    setTimeout(purgeSignaturesNow, 300);
  }

  function removeUiFromSnapshot(doc){
    try{
      doc.querySelectorAll(
        '#startupPopup,#startupPopupV46,#actionsOverlay,#confirmOverlay,#resetOverlay,#resignListOverlay,#presencePopup,#floatingActionsBtn,.no-print'
      ).forEach(el=>el.remove());
    }catch(e){}
  }

  function makePrintableSnapshotHtml(){
    try{
      if(typeof generate === "function") generate();
      if(typeof presenceSave === "function") presenceSave();
      if(typeof presenceRender === "function") presenceRender();
    }catch(e){}

    const clone = document.documentElement.cloneNode(true);
    removeUiFromSnapshot(clone);

    // Aucun script dans la copie imprimée : aucune purge ne peut se lancer dans le PDF.
    clone.querySelectorAll("script").forEach(s=>s.remove());

    const style = document.createElement("style");
    style.textContent = `
      @media print{
        body{background:#fff!important;}
        .no-print,#startupPopup,#startupPopupV46,#actionsOverlay,#confirmOverlay,#resetOverlay,#resignListOverlay,#presencePopup,#floatingActionsBtn{display:none!important;visibility:hidden!important;}
        .presence-signature img{max-width:140px!important;max-height:60px!important;display:block!important;margin:auto!important;}
      }
    `;
    clone.querySelector("head")?.appendChild(style);

    return "<!DOCTYPE html>\n" + clone.outerHTML;
  }

  function printSnapshotWithSignatures(){
    hide("actionsOverlay");
    hide("confirmOverlay");
    hide("resetOverlay");

    printStarted = true;
    purgeDone = false;
    minPrintDelayReached = false;

    // Empêche une purge immédiate si le focus revient trop vite lors de l'ouverture du sélecteur PDF.
    setTimeout(()=>{ minPrintDelayReached = true; }, 1200);

    const html = makePrintableSnapshotHtml();

    let iframe = byId("pdfPrintSnapshotFrameV57");
    if(iframe) iframe.remove();

    iframe = document.createElement("iframe");
    iframe.id = "pdfPrintSnapshotFrameV57";
    iframe.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0;opacity:0";
    iframe.setAttribute("aria-hidden","true");

    document.body.appendChild(iframe);
    iframeRef = iframe;

    const doc = iframe.contentWindow.document;
    doc.open();
    doc.write(html);
    doc.close();

    iframe.onload = function(){
      setTimeout(()=>{
        try{
          iframe.contentWindow.focus();
          iframe.contentWindow.print();
        }catch(e){
          try{ window.print(); }catch(_){}
        }
      },600);
    };

    window.addEventListener("focus", schedulePurgeAfterReturn);

    document.addEventListener("visibilitychange", function visibilityHandler(){
      if(document.visibilityState === "visible"){
        schedulePurgeAfterReturn();
      }
    });

    // Filet de sécurité : si Android ne renvoie aucun événement de retour,
    // purge après un délai long uniquement.
    setTimeout(()=>{
      if(printStarted && !purgeDone){
        purgeSignaturesNow();
      }
    },60000);
  }

  window.safePrintWithSignatures = printSnapshotWithSignatures;
  window.presencePrint = printSnapshotWithSignatures;

  function patchPrintButtons(){
    document.querySelectorAll("button").forEach(btn=>{
      const txt = (btn.textContent || "").toLowerCase();
      if(txt.includes("imprimer") && txt.includes("pdf")){
        btn.onclick = printSnapshotWithSignatures;
      }
    });
  }

  document.addEventListener("click",function(e){
    const btn = e.target.closest("button");
    if(!btn) return;

    const txt = (btn.textContent || "").toLowerCase();
    if(txt.includes("imprimer") && txt.includes("pdf")){
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      printSnapshotWithSignatures();
    }
  },true);

  document.addEventListener("DOMContentLoaded",()=>{
    patchPrintButtons();
    setTimeout(patchPrintButtons,500);
    setTimeout(patchPrintButtons,1200);
  });

  setTimeout(patchPrintButtons,1000);

})();

;

(function(){

  function byId(id){ return document.getElementById(id); }

  function getCheckedLamIndexesV64(){
    return Array.from(document.querySelectorAll('[id^="lamVoie"]'))
      .filter(cb=>cb.checked)
      .map(cb=>parseInt(cb.id.replace("lamVoie",""),10))
      .filter(n=>!isNaN(n));
  }

  function voieNameV64(i){
    return byId("voieNom"+i)?.value || ("Voie "+(i+1));
  }

  function cfgMetaV64(i){
    const cfg = window.lamData && window.lamData[i];
    if(!cfg || !cfg.engins || !cfg.engins.length){
      return "Aucune configuration enregistrée";
    }
    const count = cfg.count || cfg.engins.length || 1;
    const configured = cfg.engins.filter(e=>(e.nom||e.type||e.pk||e.secteur)).length;
    return count + " LAM prévu(s) — " + configured + " renseigné(s)";
  }

  function renderLamVoieChoiceV64(){
    const list = byId("lamVoieChoiceListV64");
    if(!list) return;

    const indexes = getCheckedLamIndexesV64();

    if(!indexes.length){
      list.innerHTML = '<div class="lam-choice-card-v64"><b>Aucune voie avec LAM cochée.</b><br>Cochez d’abord “LAM dans la voie” sur la voie concernée.</div>';
      return;
    }

    list.innerHTML = indexes.map(i=>`
      <div class="lam-choice-card-v64">
        <div class="lam-choice-title-v64">${voieNameV64(i)}</div>
        <div class="lam-choice-meta-v64">${cfgMetaV64(i)}</div>
        <div class="lam-choice-actions-v64">
          <button type="button" class="lam-choice-open-v64" onclick="openLamForVoieV64(${i})">Configurer cette voie</button>
          <button type="button" class="lam-choice-uncheck-v64" onclick="uncheckLamVoieV64(${i})">Retirer LAM de cette voie</button>
        </div>
      </div>
    `).join("");
  }

  window.openLamVoieChoiceV64 = function(){
    renderLamVoieChoiceV64();
    const overlay = byId("lamVoieChoiceOverlayV64");
    if(overlay) overlay.style.display = "flex";
  };

  window.forceCloseLamVoieChoiceV64 = function(){
    const overlay = byId("lamVoieChoiceOverlayV64");
    if(overlay) overlay.style.display = "none";
  };

  window.closeLamVoieChoiceV64 = function(e){
    if(e && e.target && e.target.id === "lamVoieChoiceOverlayV64"){
      window.forceCloseLamVoieChoiceV64();
    }
  };

  window.openLamForVoieV64 = function(i){
    window.forceCloseLamVoieChoiceV64();
    if(typeof openLamPopup === "function"){
      openLamPopup(i);
      setTimeout(()=>injectLamPopupSwitchV64(i),80);
    }
  };

  window.uncheckLamVoieV64 = function(i){
    const cb = byId("lamVoie"+i);
    if(cb) cb.checked = false;

    if(typeof generate === "function") generate();

    renderLamVoieChoiceV64();
  };

  function injectLamPopupSwitchV64(currentIndex){
    const content = byId("lamPopupContent");
    if(!content || byId("lamPopupSwitchV64")) return;

    const indexes = getCheckedLamIndexesV64();
    if(indexes.length <= 1) return;

    const box = document.createElement("div");
    box.id = "lamPopupSwitchV64";
    box.className = "lam-popup-switch-v64";

    box.innerHTML = `
      <label>Voie à configurer</label>
      <select id="lamPopupSwitchSelectV64">
        ${indexes.map(i=>`<option value="${i}" ${i===currentIndex?'selected':''}>${voieNameV64(i)} — ${cfgMetaV64(i)}</option>`).join("")}
      </select>
    `;

    content.insertAdjacentElement("afterbegin", box);

    const select = byId("lamPopupSwitchSelectV64");
    if(select){
      select.onchange = function(){
        // Sauvegarde la voie actuelle avant changement pour ne pas perdre les saisies.
        try{
          if(typeof saveLamPopup === "function"){
            const overlay = byId("lamPopupOverlay");
            const oldDisplay = overlay ? overlay.style.display : "";
            saveLamPopup();
            if(overlay) overlay.style.display = oldDisplay || "flex";
          }
        }catch(e){}

        const next = parseInt(this.value,10);
        if(!isNaN(next) && typeof openLamPopup === "function"){
          openLamPopup(next);
          setTimeout(()=>injectLamPopupSwitchV64(next),80);
        }
      };
    }
  }

  /*
    Corrige le bouton global : il ne doit plus ouvrir au hasard / première voie.
    Il ouvre une fenêtre de choix de voie.
  */
  window.openGlobalLamConfig = function(){
    const indexes = getCheckedLamIndexesV64();

    if(!indexes.length){
      alert("Aucune voie avec LAM cochée.");
      return;
    }

    if(indexes.length === 1){
      openLamForVoieV64(indexes[0]);
    }else{
      openLamVoieChoiceV64();
    }
  };

  /*
    Corrige l'ouverture depuis la case LAM : quand on coche une voie,
    on ouvre bien la configuration de cette voie, pas la dernière / première.
  */
  window.openLamConfig = function(i){
    if(typeof openLamPopup === "function"){
      openLamPopup(i);
      setTimeout(()=>injectLamPopupSwitchV64(i),80);
    }
  };

  const oldOpenLamPopup = window.openLamPopup;
  if(typeof oldOpenLamPopup === "function" && !oldOpenLamPopup._v64Wrapped){
    window.openLamPopup = function(voieIndex){
      const result = oldOpenLamPopup.apply(this, arguments);
      setTimeout(()=>injectLamPopupSwitchV64(parseInt(voieIndex,10)),80);
      return result;
    };
    window.openLamPopup._v64Wrapped = true;
  }

  function patchButtonTextV64(){
    const btn = byId("singleLamConfigBtn");
    if(btn){
      btn.textContent = "Configurer les LAM par voie";
      btn.onclick = window.openGlobalLamConfig;
    }
  }

  document.addEventListener("DOMContentLoaded", ()=>{
    document.body.insertAdjacentHTML("beforeend", `
<div id="lamVoieChoiceOverlayV64" class="no-print" onclick="closeLamVoieChoiceV64(event)">
  <div id="lamVoieChoicePopupV64" onclick="event.stopPropagation()">
    <h2>Configurer les LAM par voie</h2>
    <div class="lam-choice-help-v64">
      Sélectionnez d’abord la voie concernée, puis configurez les LAM propres à cette voie.
      Chaque voie conserve sa propre configuration.
    </div>
    <div id="lamVoieChoiceListV64"></div>
    <button type="button" class="lam-choice-close-v64" onclick="forceCloseLamVoieChoiceV64()">Fermer</button>
  </div>
</div>
<!-- /V64 LAM VOIE CHOICE -->
`);
    patchButtonTextV64();
    setTimeout(patchButtonTextV64,500);
    setTimeout(patchButtonTextV64,1200);
  });

  setTimeout(patchButtonTextV64,1000);

})();

;

(function(){
const TYPES=["Pelle rail-route","Nacelle rail-route","Camion grue rail-route","Unimog rail-route","Plateforme caténaire rail-route","Véhicule caténaire rail-route","Dérouleuse caténaire rail-route","Véhicule déroulage câble rail-route","Grue rail-route","Porte-outils rail-route","Camion nacelle rail-route","Véhicule de maintenance rail-route","Draisine rail-route","Chargeuse rail-route","Dumper rail-route","Tombereau rail-route","Tracteur rail-route","Engin de levage rail-route","Engin de manutention rail-route","Véhicule léger rail-route","Pick-up rail-route","4x4 rail-route","Véhicule d’inspection rail-route","Véhicule secours rail-route","Camion atelier rail-route","Hydrocureur rail-route","Aspiratrice rail-route","Véhicule nettoyage rail-route","Véhicule tunnel rail-route","Locotracteur rail-route","Bourreuse légère rail-route","Soudeuse rail-route","Perceuse traverses rail-route","Tronçonneuse rail-route","Engin ballast rail-route","Engin terrassement rail-route","Engin mixte route/rail","Multi Wizard","Rescue Wizard","Hydro Wizard","Skyrailer","Colmar rail-route","Geismar rail-route","ZAGRO rail-route","Trackmobile rail-route"];
function qs(id){return document.getElementById(id)}
function vName(i){return qs("voieNom"+i)?.value||("Voie "+(parseInt(i)+1))}
function cfg(i){window.lamData=window.lamData||{};if(!window.lamData[i])window.lamData[i]={count:1,commonPoint:true,commonPk:"",commonSecteur:vName(i),commonMiseVoie:"plateforme",engins:[]};let c=window.lamData[i];if(typeof c.commonPoint==="undefined")c.commonPoint=true;if(!c.engins)c.engins=[];if(!c.commonSecteur)c.commonSecteur=vName(i);while(c.engins.length<(c.count||1))c.engins.push({nom:"",type:"",pk:"",secteur:vName(i),miseVoie:"plateforme"});return c}
function savePopup(i){let c=cfg(i);c.count=parseInt(qs("lamCount_"+i)?.value||c.count||1);c.commonPoint=!!qs("lamCommonPoint_"+i)?.checked;c.commonPk=qs("lamCommonPk_"+i)?.value||"";c.commonSecteur=qs("lamCommonSecteur_"+i)?.value||"";c.commonMiseVoie=qs("lamCommonMiseVoie_"+i)?.value||"plateforme";for(let n=0;n<c.count;n++){c.engins[n]={nom:qs("lamNom_"+i+"_"+n)?.value||"",type:qs("lamType_"+i+"_"+n)?.value||"",pk:c.commonPoint?c.commonPk:(qs("lamPk_"+i+"_"+n)?.value||""),secteur:c.commonPoint?c.commonSecteur:(qs("lamSecteur_"+i+"_"+n)?.value||""),miseVoie:c.commonPoint?c.commonMiseVoie:(qs("lamMiseVoie_"+i+"_"+n)?.value||"plateforme")}}c.engins=c.engins.slice(0,c.count)}
function danger(i,n){let d=qs("lamDanger_"+i+"_"+n);if(!d)return;let c=cfg(i), common=!!qs("lamCommonPoint_"+i)?.checked, voieCat=(qs("catenaire"+i)?.value||qs("voieS11"+i)?.value||"").toLowerCase(), voieProt=(qs("protection"+i)?.value||qs("voieS9"+i)?.value||"").toLowerCase();let mv=common?(qs("lamCommonMiseVoie_"+i)?.value||c.commonMiseVoie):(qs("lamMiseVoie_"+i+"_"+n)?.value||"plateforme");let h="";if(mv==="sansPlateforme"&&voieCat.includes("aliment"))h+='<div class="lam-danger">⚠ Mise en voie sans plateforme aménagée avec caténaire alimentée : interdit. Mise hors tension obligatoire.</div>';if(voieProt.includes("circul")||voieProt.includes("annon"))h+='<div class="lam-danger">⚠ Voie circulée / annoncée : protections circulation et limiteurs adaptés à confirmer.</div>';d.innerHTML=h}
window.openLamPopup=function(i){let overlay=qs("lamPopupOverlay"),content=qs("lamPopupContent");if(!overlay||!content)return;let c=cfg(i), vn=vName(i);let html=`<div class="lam-card v65-lam-card"><div class="v65-lam-head"><span class="v65-lam-badge">${parseInt(i)+1}</span><div><div class="v65-lam-title">${vn}</div><div style="font-size:13px;color:#555;font-weight:700;">Configuration des LAM propres à cette voie</div></div></div><div class="v65-lam-grid"><div><label><b>Nombre de LAM dans cette voie</b></label><select id="lamCount_${i}" onchange="renderLamPopup(${i})" style="width:100%;padding:12px;border-radius:10px;margin-top:6px;">${[1,2,3,4,5].map(n=>`<option value="${n}" ${c.count==n?'selected':''}>${n}</option>`).join("")}</select></div></div></div><div class="v65-common-box"><label><input type="checkbox" id="lamCommonPoint_${i}" ${c.commonPoint?'checked':''} onchange="toggleLamCommonPointV65(${i})">Même point de mise en voie / même plateforme pour tous les LAM de cette voie</label><div class="v65-info">Si les LAM sont mis en voie au même endroit, renseigner une seule fois le point ci-dessous. Décochez uniquement si un LAM a un point ou un type de mise en voie différent.</div><div id="lamCommonZone_${i}" class="v65-lam-grid" style="${c.commonPoint?'':'display:none;'}"><div><label><b>Point / lieu de mise en voie commun</b></label><input id="lamCommonPk_${i}" value="${c.commonPk||''}" placeholder="Ex : PK 58,400 / accès nord" style="width:100%;padding:12px;border-radius:10px;"></div><div><label><b>Voie / secteur commun</b></label><input id="lamCommonSecteur_${i}" value="${c.commonSecteur||vn}" style="width:100%;padding:12px;border-radius:10px;"></div><div class="v65-lam-grid-full"><label><b>Type de mise en voie commun</b></label><select id="lamCommonMiseVoie_${i}" onchange="checkAllLamDangerV65(${i})" style="width:100%;padding:12px;border-radius:10px;"><option value="plateforme" ${c.commonMiseVoie==='plateforme'?'selected':''}>Plateforme aménagée</option><option value="sansPlateforme" ${c.commonMiseVoie==='sansPlateforme'?'selected':''}>Sans plateforme aménagée</option></select></div></div></div>`;
for(let n=0;n<c.count;n++){if(!c.engins[n])c.engins[n]={nom:"",type:"",pk:"",secteur:vn,miseVoie:"plateforme"};let e=c.engins[n];html+=`<div class="lam-card v65-lam-card"><div class="v65-lam-head"><span class="v65-lam-badge">${n+1}</span><div class="v65-lam-title">LAM ${n+1}</div></div><div class="v65-lam-grid"><div><label><b>Nom / identification</b></label><input id="lamNom_${i}_${n}" value="${e.nom||''}" placeholder="Ex : LAM ETF 01" style="width:100%;padding:12px;border-radius:10px;"></div><div><label><b>Type d'engin rail-route</b></label><select id="lamType_${i}_${n}" style="width:100%;padding:12px;border-radius:10px;">${TYPES.map(t=>`<option ${e.type===t?'selected':''}>${t}</option>`).join("")}</select></div></div><div class="v65-specific-note" style="${c.commonPoint?'display:none;':''}">Point spécifique à renseigner uniquement pour ce LAM.</div><div class="v65-lam-grid" style="${c.commonPoint?'display:none;':''}"><div><label><b>Point / lieu spécifique</b></label><input id="lamPk_${i}_${n}" value="${e.pk||''}" placeholder="Ex : PK 58,400" style="width:100%;padding:12px;border-radius:10px;"></div><div><label><b>Voie / secteur spécifique</b></label><input id="lamSecteur_${i}_${n}" value="${e.secteur||vn}" style="width:100%;padding:12px;border-radius:10px;"></div><div class="v65-lam-grid-full"><label><b>Type de mise en voie spécifique</b></label><select id="lamMiseVoie_${i}_${n}" onchange="checkLamDanger(${i},${n})" style="width:100%;padding:12px;border-radius:10px;"><option value="plateforme" ${e.miseVoie==='plateforme'?'selected':''}>Plateforme aménagée</option><option value="sansPlateforme" ${e.miseVoie==='sansPlateforme'?'selected':''}>Sans plateforme aménagée</option></select></div></div><div id="lamDanger_${i}_${n}"></div></div>`}
content.innerHTML=html;overlay.style.display="flex";setTimeout(()=>window.checkAllLamDangerV65(i),80)}
window.renderLamPopup=function(i){savePopup(i);let c=cfg(i);c.count=parseInt(qs("lamCount_"+i)?.value||1);while(c.engins.length<c.count)c.engins.push({nom:"",type:"",pk:"",secteur:vName(i),miseVoie:"plateforme"});c.engins=c.engins.slice(0,c.count);openLamPopup(i)}
window.toggleLamCommonPointV65=function(i){savePopup(i);cfg(i).commonPoint=!!qs("lamCommonPoint_"+i)?.checked;openLamPopup(i)}
window.checkLamDanger=function(i,n){danger(i,n)}
window.checkAllLamDangerV65=function(i){let c=cfg(i);for(let n=0;n<c.count;n++)danger(i,n)}
window.saveLamPopup=function(){Object.keys(window.lamData||{}).forEach(i=>{if(qs("lamCount_"+i))savePopup(i)});if(typeof closeLamPopup==="function")closeLamPopup();if(typeof generate==="function")generate();if(typeof updateLamBriefing==="function")updateLamBriefing()}
window.updateLamBriefing=function(){let target=document.getElementById("oMiseVoieLamBriefing");if(!target)return;let out="";Object.keys(window.lamData||{}).forEach(i=>{let c=cfg(i),vn=vName(i);if(!c.engins.length)return;out+=`<div style="margin-bottom:14px;"><b>${vn}</b> : ${c.count} LAM / engin(s) rail-route<br>`;if(c.commonPoint){out+=`Point de mise en voie commun : <u>${c.commonPk||"à préciser"}</u><br>Voie / secteur commun : <u>${c.commonSecteur||"à préciser"}</u><br>Type de mise en voie commun : <u>${c.commonMiseVoie==="plateforme"?"Plateforme aménagée":"Sans plateforme aménagée"}</u><br>`}c.engins.forEach((e,n)=>{out+=`• LAM ${n+1} : <b>${e.nom||"Sans nom"}</b> — ${e.type||"Type à préciser"}<br>`;if(!c.commonPoint){out+=`Point / lieu : <u>${e.pk||"à préciser"}</u><br>Voie / secteur : <u>${e.secteur||"à préciser"}</u><br>Type mise en voie : <u>${e.miseVoie==="plateforme"?"Plateforme aménagée":"Sans plateforme aménagée"}</u><br>`}let mv=c.commonPoint?c.commonMiseVoie:e.miseVoie;if(mv!=="plateforme")out+=`<div class="lam-danger">⚠ Mise en voie sans plateforme aménagée : mise hors tension caténaire obligatoire avant engagement de l'engin.</div>`});out+=`</div>`});target.innerHTML=out||"Aucune LAM configurée."}
})();

;

(function(){

  const PRESENCE_KEY = "briefing_presence_clean_v9";
  let pdfFlowStarted = false;

  function byId(id){ return document.getElementById(id); }
  function hide(id){ const el = byId(id); if(el) el.style.display = "none"; }
  function show(id){ const el = byId(id); if(el) el.style.display = "flex"; }
  function toast(msg){ if(typeof showToast === "function") showToast(msg); else console.log(msg); }

  function cleanSignatureObject(p){
    if(!p || typeof p !== "object") return p;

    Object.keys(p).forEach(k=>{
      const kk = k.toLowerCase();
      if(kk.includes("signature") || kk.includes("signed") || kk === "sign" || kk === "img" || kk === "dataurl" || kk.includes("canvas")){
        p[k] = typeof p[k] === "boolean" ? false : "";
      }
    });

    return Object.assign(p,{
      signature:"",
      signatureData:"",
      signatureDataUrl:"",
      signatureUrl:"",
      signatureImage:"",
      signatureBase64:"",
      signatureSrc:"",
      signaturePNG:"",
      sign:"",
      img:"",
      dataUrl:"",
      signed:false,
      hasSigned:false,
      isSigned:false,
      signatureDate:"",
      dateSignature:""
    });
  }

  function purgeSignatureStorageOnly(){
    try{
      Object.keys(localStorage).forEach(k=>{
        const kk = k.toLowerCase();

        if(kk.includes("signature") || kk.includes("signed") || kk.includes("resign")){
          localStorage.removeItem(k);
          return;
        }

        const raw = localStorage.getItem(k);
        if(!raw || (raw[0] !== "{" && raw[0] !== "[")) return;

        try{
          const data = JSON.parse(raw);
          let touched = false;

          if(Array.isArray(data)){
            data.forEach(item=>{
              if(item && typeof item === "object"){
                const hasSig = Object.keys(item).some(key=>{
                  const lower = key.toLowerCase();
                  return lower.includes("signature") || lower.includes("signed") || lower === "sign" || lower === "img" || lower === "dataurl";
                });
                if(hasSig){
                  cleanSignatureObject(item);
                  touched = true;
                }
              }
            });
            if(touched) localStorage.setItem(k, JSON.stringify(data));
          }

          if(data && typeof data === "object"){
            ["participants","presenceParticipants","participantsTable"].forEach(prop=>{
              if(Array.isArray(data[prop])){
                data[prop] = data[prop].map(cleanSignatureObject);
                touched = true;
              }
            });
            if(touched) localStorage.setItem(k, JSON.stringify(data));
          }
        }catch(e){}
      });

      const raw = localStorage.getItem(PRESENCE_KEY);
      if(raw){
        const state = JSON.parse(raw);
        if(state && Array.isArray(state.participants)){
          state.participants = state.participants.map(cleanSignatureObject);
          localStorage.setItem(PRESENCE_KEY, JSON.stringify(state));
        }
      }
    }catch(e){}
  }

  function clearVisibleSignatureCells(){
    document.querySelectorAll(".presence-signature").forEach(cell=>{
      cell.innerHTML = "";
      cell.textContent = "";
    });

    document.querySelectorAll("#presenceRows tr").forEach(tr=>{
      const cells = tr.querySelectorAll("td");
      if(cells[4]){
        cells[4].innerHTML = '<div class="presence-signature"></div>';
      }
    });

    document.querySelectorAll("canvas").forEach(c=>{
      try{ c.getContext("2d").clearRect(0,0,c.width,c.height); }catch(e){}
    });
  }

  function purgeSignaturesNow(){
    try{
      if(typeof window.__nativeClearOnlySignaturesV52 === "function"){
        window.__nativeClearOnlySignaturesV52();
      }else if(typeof window.__nativeClearOnlySignaturesV49 === "function"){
        window.__nativeClearOnlySignaturesV49();
      }else if(typeof window.__nativeClearOnlySignaturesV48 === "function"){
        window.__nativeClearOnlySignaturesV48();
      }
    }catch(e){}

    purgeSignatureStorageOnly();
    clearVisibleSignatureCells();

    setTimeout(()=>{
      purgeSignatureStorageOnly();
      clearVisibleSignatureCells();
    },300);
  }

  window.confirmPdfSavedAndPurgeV67 = function(){
    hide("pdfFinalisationOverlayV67");
    pdfFlowStarted = false;
    purgeSignaturesNow();
    toast("PDF enregistré : signatures purgées dans l’application.");
  };

  window.cancelPdfExportKeepSignaturesV67 = function(){
    hide("pdfFinalisationOverlayV67");
    pdfFlowStarted = false;
    toast("PDF non enregistré : signatures conservées.");
  };

  function showFinalisationOnReturn(){
    if(!pdfFlowStarted) return;
    setTimeout(()=>show("pdfFinalisationOverlayV67"), 200);
  }

  function printWithPostFinalisation(){
    hide("actionsOverlay");
    hide("confirmOverlay");
    hide("resetOverlay");
    hide("pdfFinalisationOverlayV67");

    pdfFlowStarted = true;

    try{
      if(typeof generate === "function") generate();
      if(typeof presenceSave === "function") presenceSave();
      if(typeof presenceRender === "function") presenceRender();
    }catch(e){}

    setTimeout(()=>{
      try{ window.print(); }catch(e){ showFinalisationOnReturn(); }
    },250);

    window.addEventListener("focus", showFinalisationOnReturn, {once:true});

    document.addEventListener("visibilitychange", function vh(){
      if(document.visibilityState === "visible"){
        document.removeEventListener("visibilitychange", vh);
        showFinalisationOnReturn();
      }
    });
  }

  window.safePrintWithSignatures = printWithPostFinalisation;
  window.presencePrint = printWithPostFinalisation;

  function patchPrintButtons(){
    document.querySelectorAll("button").forEach(btn=>{
      const txt = (btn.textContent || "").toLowerCase();
      if(txt.includes("imprimer") && txt.includes("pdf")){
        btn.onclick = printWithPostFinalisation;
      }
    });
  }

  document.addEventListener("click", function(e){
    const btn = e.target.closest("button");
    if(!btn) return;

    const txt = (btn.textContent || "").toLowerCase();
    if(txt.includes("imprimer") && txt.includes("pdf")){
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      printWithPostFinalisation();
    }
  }, true);

  document.addEventListener("DOMContentLoaded", ()=>{
    patchPrintButtons();
    setTimeout(patchPrintButtons,500);
    setTimeout(patchPrintButtons,1200);
  });

  setTimeout(patchPrintButtons,1000);

})();

;

(function(){

  function updatePdfCheckboxMarkers(){

    document.querySelectorAll('input[type="checkbox"]').forEach(cb=>{

      if(!cb.dataset.pdfMarkerIdV67){
        const id = 'pdfcb_' + Math.random().toString(36).slice(2);
        cb.dataset.pdfMarkerIdV67 = id;

        const marker = document.createElement('span');
        marker.className = 'pdf-checkbox-marker-v67';
        marker.dataset.pdfMarkerForV67 = id;

        cb.insertAdjacentElement('afterend', marker);
      }

      const marker = document.querySelector('[data-pdf-marker-for-v67="' + cb.dataset.pdfMarkerIdV67 + '"]');

      if(marker){
        marker.textContent = cb.checked ? '☑' : '☐';
        marker.classList.toggle('checked', cb.checked);
        marker.classList.toggle('unchecked', !cb.checked);
      }
    });
  }

  document.addEventListener('change', function(e){
    if(e.target && e.target.matches('input[type="checkbox"]')){
      updatePdfCheckboxMarkers();
    }
  });

  window.addEventListener('beforeprint', updatePdfCheckboxMarkers);

  document.addEventListener('DOMContentLoaded', function(){
    updatePdfCheckboxMarkers();
    setTimeout(updatePdfCheckboxMarkers,500);
    setTimeout(updatePdfCheckboxMarkers,1200);
  });

  document.addEventListener('click', function(e){
    const btn = e.target.closest('button');
    if(!btn) return;

    const txt = (btn.textContent || '').toLowerCase();

    if(txt.includes('pdf') || txt.includes('imprimer')){
      updatePdfCheckboxMarkers();
      setTimeout(updatePdfCheckboxMarkers,250);
    }
  }, true);

})();

;

(function(){
  function byId(id){ return document.getElementById(id); }
  window.syncEchauffementMusculaire = function(){
    var src = byId('echauffementMusculaireInput');
    var out = byId('echauffementMusculaire');
    if(src && out) out.checked = !!src.checked;
  };
  window.syncEchauffementMusculaireFromPreview = function(){
    var src = byId('echauffementMusculaire');
    var inp = byId('echauffementMusculaireInput');
    if(src && inp) inp.checked = !!src.checked;
  };
  function init(){
    var inp = byId('echauffementMusculaireInput');
    var out = byId('echauffementMusculaire');
    if(inp && out){
      // si l’une des deux cases a été restaurée cochée, on synchronise dans les deux sens
      var checked = !!inp.checked || !!out.checked;
      inp.checked = checked;
      out.checked = checked;
    }
  }
  var oldGenerate = window.generate;
  window.generate = function(){
    if(typeof oldGenerate === 'function') oldGenerate.apply(this, arguments);
    setTimeout(function(){ if(typeof window.syncEchauffementMusculaire === 'function') window.syncEchauffementMusculaire(); }, 40);
  };
  document.addEventListener('DOMContentLoaded', function(){ setTimeout(init, 100); setTimeout(init, 700); });
  setTimeout(init, 1200);
})();

;

(function(){
  'use strict';

  const BRIDGE_NAMES = [
    'AutoMixAndroid','Android','NativeAndroid','AppBridge','NativeBridge',
    'WebViewAndroid','HTMLtoAPK','HtmlToApk','AndroidBridge'
  ];
  const CHUNK_SIZE = 384 * 1024;

  function byId(id){ return document.getElementById(id); }
  function toastCompat(message){
    try{
      if(typeof window.toast === 'function'){ window.toast(message); return; }
      const existing = byId('toastMsg');
      if(existing){ existing.textContent = message; existing.style.display='block'; setTimeout(()=>existing.style.display='none',3000); return; }
    }catch(e){}
    console.log('[HTMLtoAPK]', message);
  }
  function sanitizeFilePart(v){
    return (v || 'A_completer').toString().normalize('NFD')
      .replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9_-]+/g,'_')
      .replace(/^_+|_+$/g,'').slice(0,80) || 'A_completer';
  }
  function getMeta(){
    return {
      chantier: byId('chantier')?.value || 'A_completer',
      entreprise: byId('entrepriseChantier')?.value || 'A_completer',
      date: byId('date')?.value || new Date().toISOString().slice(0,10),
      horaire: byId('horaire')?.value || 'A_completer'
    };
  }
  function makeFilename(){
    const m = getMeta();
    return sanitizeFilePart(m.date)+'_'+sanitizeFilePart(m.chantier)+'_'+sanitizeFilePart(m.entreprise)+'_briefing.html';
  }
  function bridgeObjects(){
    const result=[];
    BRIDGE_NAMES.forEach(name=>{
      try{
        const obj=window[name];
        if(obj && !result.some(x=>x.obj===obj)) result.push({name,obj});
      }catch(e){}
    });
    return result;
  }
  function callMethod(obj, method, args){
    try{
      if(obj && typeof obj[method] === 'function'){
        return {ok:true, value:obj[method].apply(obj,args)};
      }
    }catch(error){ console.warn('[HTMLtoAPK] '+method+' failed', error); }
    return {ok:false};
  }
  function utf8ToBase64(text){
    const bytes = new TextEncoder().encode(text);
    let binary='';
    const step=0x8000;
    for(let i=0;i<bytes.length;i+=step){ binary += String.fromCharCode.apply(null, bytes.subarray(i,i+step)); }
    return btoa(binary);
  }
  function syncFormState(sourceRoot, cloneRoot){
    const sourceControls = sourceRoot.querySelectorAll('input,textarea,select,details');
    const cloneControls = cloneRoot.querySelectorAll('input,textarea,select,details');
    sourceControls.forEach((source,index)=>{
      const clone=cloneControls[index]; if(!clone) return;
      const tag=source.tagName;
      if(tag==='INPUT'){
        const type=(source.type||'').toLowerCase();
        if(type==='checkbox' || type==='radio'){
          if(source.checked) clone.setAttribute('checked','checked'); else clone.removeAttribute('checked');
        }else if(type!=='file'){
          clone.setAttribute('value',source.value||'');
        }else{
          clone.removeAttribute('value');
        }
      }else if(tag==='TEXTAREA'){
        clone.textContent=source.value||'';
      }else if(tag==='SELECT'){
        Array.from(clone.options).forEach((option,i)=>{
          if(source.options[i]?.selected) option.setAttribute('selected','selected');
          else option.removeAttribute('selected');
        });
      }else if(tag==='DETAILS'){
        if(source.open) clone.setAttribute('open','open'); else clone.removeAttribute('open');
      }
    });
  }
  function buildArchiveHtml(){
    try{ if(typeof window.generate==='function') window.generate(); }catch(e){}
    try{ if(typeof window.presenceSave==='function') window.presenceSave(); }catch(e){}
    try{ if(typeof window.presenceRender==='function') window.presenceRender(); }catch(e){}

    const clone=document.documentElement.cloneNode(true);
    syncFormState(document, clone);

    const startup=clone.querySelector('#startupPopup');
    if(startup) startup.setAttribute('style','display:none!important');
    ['actionsOverlay','confirmOverlay','resetOverlay','pdfFinalisationOverlayV67','presencePopup','lamPopupOverlay'].forEach(id=>{
      const el=clone.querySelector('#'+id); if(el) el.setAttribute('style','display:none!important');
    });
    clone.querySelectorAll('input[type="file"]').forEach(input=>input.removeAttribute('value'));

    return '<!DOCTYPE html>\n' + clone.outerHTML;
  }

  function nativeChunkSave(filename,mime,base64){
    for(const entry of bridgeObjects()){
      const b=entry.obj;
      if(typeof b.beginFile==='function' && typeof b.writeFileChunk==='function' && typeof b.finishFile==='function'){
        try{
          const totalChunks=Math.ceil(base64.length/CHUNK_SIZE);
          // This is the bridge protocol used by HTMLtoAPK builds. Extra metadata is intentionally simple strings/numbers.
          b.beginFile(filename,mime,totalChunks);
          for(let i=0;i<base64.length;i+=CHUNK_SIZE){ b.writeFileChunk(base64.slice(i,i+CHUNK_SIZE)); }
          b.finishFile();
          return true;
        }catch(error){ console.warn('[HTMLtoAPK] chunk bridge failed on '+entry.name,error); }
      }
    }
    return false;
  }
  function nativeDirectSave(filename,mime,base64,mode){
    const methods = mode==='share'
      ? ['shareBase64File','shareFileBase64','shareFile','shareContent']
      : ['saveBase64File','downloadBase64File','saveFileBase64','downloadBase64','saveFile','downloadFile'];
    for(const entry of bridgeObjects()){
      for(const method of methods){
        if(typeof entry.obj[method] !== 'function') continue;
        const r=callMethod(entry.obj,method,[filename,mime,base64]);
        if(r.ok) return true;
      }
    }
    return false;
  }
  async function browserShare(filename,mime,text,content){
    try{
      const file=new File([content],filename,{type:mime});
      if(navigator.share && (!navigator.canShare || navigator.canShare({files:[file]}))){
        await navigator.share({title:'Briefing chantier',text,files:[file]});
        return true;
      }
    }catch(error){ console.warn('[HTMLtoAPK] Web Share failed',error); }
    return false;
  }
  function classicDownload(filename,mime,content){
    try{
      const blob=new Blob([content],{type:mime});
      const url=URL.createObjectURL(blob);
      const a=document.createElement('a');
      a.href=url; a.download=filename; a.rel='noopener'; a.style.display='none';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(()=>URL.revokeObjectURL(url),5000);
      return true;
    }catch(error){ console.warn('[HTMLtoAPK] classic download failed',error); return false; }
  }
  async function saveHtml(mode){
    const filename=makeFilename();
    const mime='text/html;charset=utf-8';
    const html=buildArchiveHtml();
    const base64=utf8ToBase64(html);

    if(mode==='share'){
      if(nativeDirectSave(filename,mime,base64,'share')){ toastCompat('Ouverture du partage Android…'); return true; }
      if(await browserShare(filename,mime,'Briefing chantier',html)) return true;
      return false;
    }
    if(nativeChunkSave(filename,mime,base64)){
      toastCompat('Briefing transmis au système Android.');
      return true;
    }
    if(nativeDirectSave(filename,mime,base64,'save')){
      toastCompat('Briefing transmis au système Android.');
      return true;
    }
    if(classicDownload(filename,mime,html)){
      toastCompat('Enregistrement du briefing lancé.');
      return true;
    }
    return false;
  }

  // Replaces Blob-only export with Android bridge + browser fallback.
  window.presenceExport = async function(){
    const ok=await saveHtml('save');
    if(!ok) alert('Le conteneur Android ne fournit pas de fonction d’enregistrement. Mets à jour HTMLtoAPK avec le pont de fichiers natif.');
  };

  window.shareBriefingWhatsApp = async function(){
    const m=getMeta();
    const filename=makeFilename();
    const mime='text/html;charset=utf-8';
    const html=buildArchiveHtml();
    const base64=utf8ToBase64(html);
    const text='Briefing chantier - '+m.chantier+'\nEntreprise : '+m.entreprise+'\nDate : '+m.date+'\nHoraire : '+m.horaire;

    if(nativeDirectSave(filename,mime,base64,'share')){
      toastCompat('Ouverture du partage Android…'); return;
    }
    if(await browserShare(filename,mime,text,html)) return;

    // Last fallback: save the HTML first, then open WhatsApp with the message.
    if(!nativeChunkSave(filename,mime,base64) && !nativeDirectSave(filename,mime,base64,'save')){
      classicDownload(filename,mime,html);
    }
    try{
      window.location.href='whatsapp://send?text='+encodeURIComponent(text+'\n\nLe fichier HTML du briefing vient d’être enregistré sur le téléphone.');
    }catch(e){
      window.open('https://wa.me/?text='+encodeURIComponent(text),'_blank');
    }
  };

  // Use a native print/PDF method when HTMLtoAPK exposes one; otherwise preserve the existing print flow.
  const previousPrint=window.safePrintWithSignatures;
  window.safePrintWithSignatures=function(){
    for(const entry of bridgeObjects()){
      for(const method of ['printPage','printCurrentPage','createPdf','printPdf']){
        const r=callMethod(entry.obj,method,[]);
        if(r.ok){ toastCompat('Ouverture de l’impression Android…'); return; }
      }
    }
    if(typeof previousPrint==='function') return previousPrint.apply(this,arguments);
    return window.print();
  };
  window.presencePrint=window.safePrintWithSignatures;

  // Exposed for diagnostics in the generated APK.
  window.HTMLtoAPKCompat={
    version:'2026.07.17-apk',
    bridges:()=>bridgeObjects().map(x=>x.name),
    buildArchiveHtml,
    save:()=>saveHtml('save'),
    share:()=>saveHtml('share')
  };

  document.addEventListener('DOMContentLoaded',function(){
    document.documentElement.classList.add('htmltoapk-ready');
    console.log('[HTMLtoAPK] compatible runtime ready; bridges:',bridgeObjects().map(x=>x.name).join(',')||'browser fallback');
  });
})();

;

(function(){
  'use strict';

  const PAGE_W = 794;
  const PAGE_H = 1123;
  const RENDER_SCALE = 1.45;
  const BRIDGE_NAMES = ['AutoMixAndroid','Android','NativeAndroid','AppBridge','NativeBridge','WebViewAndroid','HTMLtoAPK','HtmlToApk','AndroidBridge'];
  let exportHost = null;
  let busy = false;
  let requestedMode = 'save';

  const id = x => document.getElementById(x);
  const sleep = ms => new Promise(r=>setTimeout(r,ms));

  function notify(msg){
    try{ if(typeof window.toast === 'function'){ window.toast(msg); return; } }catch(e){}
    alert(msg);
  }

  function sanitizePart(v){
    return (v || 'briefing').toString().normalize('NFD').replace(/[\u0300-\u036f]/g,'')
      .replace(/[^a-zA-Z0-9_-]+/g,'_').replace(/^_+|_+$/g,'').slice(0,80) || 'briefing';
  }

  function filenameV70(){
    const date = id('date')?.value || new Date().toISOString().slice(0,10);
    const chantier = id('chantier')?.value || 'chantier';
    const entreprise = id('entrepriseChantier')?.value || 'entreprise';
    return sanitizePart(date)+'_'+sanitizePart(chantier)+'_'+sanitizePart(entreprise)+'_briefing_signe.pdf';
  }

  function syncState(source, clone){
    const s = source.querySelectorAll('input,textarea,select,details');
    const c = clone.querySelectorAll('input,textarea,select,details');
    s.forEach((el,i)=>{
      const ce=c[i]; if(!ce) return;
      if(el.tagName==='INPUT'){
        const t=(el.type||'').toLowerCase();
        if(t==='checkbox'||t==='radio') ce.checked=el.checked;
        else if(t!=='file') ce.value=el.value||'';
      }else if(el.tagName==='TEXTAREA') ce.value=el.value||'';
      else if(el.tagName==='SELECT') ce.selectedIndex=el.selectedIndex;
      else if(el.tagName==='DETAILS') ce.open=el.open;
    });
  }

  function replaceCheckboxes(root){
    root.querySelectorAll('input[type="checkbox"],input[type="radio"]').forEach(input=>{
      const mark=document.createElement('span');
      mark.className='pdf-checkbox-v70';
      mark.textContent=input.checked ? '☑' : '☐';
      mark.setAttribute('aria-label', input.checked ? 'coché' : 'non coché');
      input.replaceWith(mark);
    });
  }

  function cleanClone(root){
    root.querySelectorAll('.no-print,button,input[type="file"],#presencePopup,#actionsOverlay,#confirmOverlay,#resetOverlay,#pdfFinalisationOverlayV67,#pdfPreviewOverlayV70,#floatingActionsBtn').forEach(el=>el.remove());
    root.querySelectorAll('[contenteditable="true"]').forEach(el=>el.removeAttribute('contenteditable'));
    replaceCheckboxes(root);
  }

  function buildExportHost(){
    try{ if(typeof window.generate==='function') window.generate(); }catch(e){}
    try{ if(typeof window.presenceSave==='function') window.presenceSave(); }catch(e){}
    try{ if(typeof window.presenceRender==='function') window.presenceRender(); }catch(e){}

    if(exportHost) exportHost.remove();
    const host=document.createElement('div');
    host.className='pdf-export-host-v70';
    host.id='pdfExportHostV70';

    const sourcePreview=document.querySelector('.preview');
    const sourceSign=id('signatureSheet');
    if(!sourcePreview || !sourceSign) throw new Error('Document de briefing introuvable.');

    const previewClone=sourcePreview.cloneNode(true);
    syncState(sourcePreview,previewClone);
    cleanClone(previewClone);
    host.appendChild(previewClone);

    const spacer=document.createElement('div');
    spacer.id='pdfSignatureSpacerV70';
    host.appendChild(spacer);

    const signClone=sourceSign.cloneNode(true);
    syncState(sourceSign,signClone);
    cleanClone(signClone);
    signClone.removeAttribute('id');
    signClone.id='signatureSheetPdfV70';
    host.appendChild(signClone);

    document.body.appendChild(host);
    exportHost=host;

    // La feuille de signatures commence proprement sur une nouvelle page.
    const currentTop=signClone.offsetTop;
    const targetTop=Math.ceil(currentTop/PAGE_H)*PAGE_H + 24;
    spacer.style.height=Math.max(20,targetTop-currentTop)+'px';
    return host;
  }

  async function waitImages(root){
    const imgs=[...root.querySelectorAll('img')];
    await Promise.all(imgs.map(img=>{
      if(img.complete) return Promise.resolve();
      return new Promise(resolve=>{ img.onload=resolve; img.onerror=resolve; setTimeout(resolve,3000); });
    }));
    await sleep(60);
  }

  function resizePreview(){
    const scroll=id('pdfPreviewScrollV70'), stage=id('pdfPreviewStageV70'), paper=id('pdfPreviewPaperV70');
    if(!scroll||!stage||!paper) return;
    const scale=Math.min(1,Math.max(.28,(scroll.clientWidth-18)/PAGE_W));
    paper.style.transform='scale('+scale+')';
    stage.style.width=(PAGE_W*scale)+'px';
    stage.style.height=(paper.scrollHeight*scale)+'px';
  }

  function showProgress(show,text){
    const p=id('pdfProgressV70');
    if(!p) return;
    p.textContent=text||'Préparation du PDF…';
    p.classList.toggle('is-visible',!!show);
  }

  window.openPdfPreviewV70 = async function(mode){
    if(busy) return;
    requestedMode=mode||'save';
    try{
      if(typeof window.hidePopup==='function') window.hidePopup('actionsOverlay');
      const host=buildExportHost();
      await waitImages(host);
      const paper=id('pdfPreviewPaperV70');
      paper.innerHTML='';
      const clone=host.cloneNode(true);
      clone.removeAttribute('id');
      clone.classList.remove('pdf-export-host-v70');
      clone.style.cssText='position:relative;width:794px;background:#fff;pointer-events:auto;';
      paper.appendChild(clone);
      const overlay=id('pdfPreviewOverlayV70');
      overlay.classList.add('is-open');
      overlay.setAttribute('aria-hidden','false');
      document.body.style.overflow='hidden';
      setTimeout(resizePreview,30);
      const shareBtn=document.querySelector('.pdf-preview-share-v70');
      const saveBtn=document.querySelector('.pdf-preview-save-v70');
      if(shareBtn&&saveBtn){
        shareBtn.style.outline=requestedMode==='share'?'4px solid rgba(18,140,74,.25)':'none';
        saveBtn.style.outline=requestedMode==='save'?'4px solid rgba(11,107,203,.22)':'none';
      }
    }catch(e){
      console.error(e); alert('Impossible de préparer l’aperçu : '+(e.message||e));
    }
  };

  window.closePdfPreviewV70 = function(force){
    if(busy && !force) return;
    const overlay=id('pdfPreviewOverlayV70');
    overlay?.classList.remove('is-open');
    overlay?.setAttribute('aria-hidden','true');
    document.body.style.overflow='';
    showProgress(false);
  };

  function collectCss(){
    return [...document.querySelectorAll('style')]
      .filter(s=>s.id!=='pdf-preview-v70-style')
      .map(s=>s.textContent||'').join('\n') + `
      html,body{margin:0!important;padding:0!important;background:#fff!important;width:${PAGE_W}px!important;overflow:hidden!important;}
      .pdf-export-host-v70{position:relative!important;left:0!important;top:0!important;width:${PAGE_W}px!important;background:#fff!important;z-index:auto!important;pointer-events:none!important;}
      .no-print,button,input[type=file]{display:none!important;visibility:hidden!important;}
      *{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important;box-sizing:border-box;}
    `;
  }

  function collectImageLayers(host){
    const hr=host.getBoundingClientRect();
    return [...host.querySelectorAll('img')].map((img,index)=>{
      const r=img.getBoundingClientRect();
      return {
        index, src:img.currentSrc||img.src||'',
        left:r.left-hr.left, top:r.top-hr.top,
        width:r.width, height:r.height
      };
    }).filter(x=>x.src&&x.width>0&&x.height>0);
  }

  function replaceImagesWithPlaceholders(root){
    root.querySelectorAll('img').forEach(img=>{
      const span=document.createElement('span');
      const w=parseFloat(img.getAttribute('width'))||img.getBoundingClientRect?.().width||120;
      const h=parseFloat(img.getAttribute('height'))||img.getBoundingClientRect?.().height||50;
      span.style.cssText=`display:inline-block;width:${w}px;height:${h}px;vertical-align:middle;background:transparent;`;
      img.replaceWith(span);
    });
  }

  function serializePage(host,offset){
    const wrapper=document.createElement('div');
    wrapper.setAttribute('xmlns','http://www.w3.org/1999/xhtml');
    wrapper.style.cssText=`width:${PAGE_W}px;height:${PAGE_H}px;overflow:hidden;background:#fff;position:relative;`;
    const style=document.createElement('style');
    style.textContent=collectCss();
    wrapper.appendChild(style);
    const content=host.cloneNode(true);
    replaceImagesWithPlaceholders(content);
    content.style.cssText=`position:absolute!important;left:0!important;top:${-offset}px!important;width:${PAGE_W}px!important;background:#fff!important;`;
    wrapper.appendChild(content);
    return new XMLSerializer().serializeToString(wrapper);
  }

  function loadOverlayImage(src){
    return new Promise(resolve=>{
      const image=new Image();
      let done=false;
      const finish=value=>{ if(done) return; done=true; resolve(value); };
      image.onload=()=>finish(image);
      image.onerror=()=>finish(null);
      if(!src.startsWith('data:')&&!src.startsWith('blob:')) image.crossOrigin='anonymous';
      image.src=src;
      setTimeout(()=>finish(null),4000);
    });
  }

  async function renderPage(host,offset,pageNo,total,imageLayers){
    showProgress(true,'Création du PDF — page '+pageNo+' / '+total+'…');
    const xhtml=serializePage(host,offset);
    const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${PAGE_W}" height="${PAGE_H}" viewBox="0 0 ${PAGE_W} ${PAGE_H}"><foreignObject x="0" y="0" width="${PAGE_W}" height="${PAGE_H}">${xhtml}</foreignObject></svg>`;
    const blob=new Blob([svg],{type:'image/svg+xml;charset=utf-8'});
    const url=URL.createObjectURL(blob);
    try{
      const img=await new Promise((resolve,reject)=>{
        const image=new Image(); let settled=false;
        const finish=(ok,value)=>{ if(settled) return; settled=true; ok?resolve(value):reject(value); };
        image.onload=()=>finish(true,image);
        image.onerror=()=>finish(false,new Error('Rendu de la page PDF impossible'));
        image.src=url;
        setTimeout(()=>finish(false,new Error('Délai de rendu PDF dépassé')),12000);
      });
      const canvas=document.createElement('canvas');
      canvas.width=Math.round(PAGE_W*RENDER_SCALE);
      canvas.height=Math.round(PAGE_H*RENDER_SCALE);
      const ctx=canvas.getContext('2d',{alpha:false});
      ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);
      ctx.drawImage(img,0,0,canvas.width,canvas.height);

      const layers=(imageLayers||[]).filter(x=>x.top+x.height>offset && x.top<offset+PAGE_H);
      for(const layer of layers){
        const overlay=await loadOverlayImage(layer.src);
        if(!overlay) continue;
        ctx.drawImage(
          overlay,
          layer.left*RENDER_SCALE,
          (layer.top-offset)*RENDER_SCALE,
          layer.width*RENDER_SCALE,
          layer.height*RENDER_SCALE
        );
      }
      return {dataUrl:canvas.toDataURL('image/jpeg',.9),width:canvas.width,height:canvas.height};
    }finally{ URL.revokeObjectURL(url); }
  }

  function dataUrlBytes(url){
    const b64=url.slice(url.indexOf(',')+1);
    const bin=atob(b64), out=new Uint8Array(bin.length);
    for(let i=0;i<bin.length;i++) out[i]=bin.charCodeAt(i);
    return out;
  }

  function ascii(str){ return new TextEncoder().encode(str); }
  function concat(chunks){
    const total=chunks.reduce((n,c)=>n+c.length,0), out=new Uint8Array(total);
    let o=0; chunks.forEach(c=>{out.set(c,o);o+=c.length;}); return out;
  }

  function buildPdf(pages){
    const objectCount=2+pages.length*3;
    const objects=new Array(objectCount+1);
    objects[1]=[ascii('<< /Type /Catalog /Pages 2 0 R >>')];
    const kids=[];
    pages.forEach((page,i)=>{
      const pageObj=3+i*3, imageObj=pageObj+1, contentObj=pageObj+2;
      kids.push(pageObj+' 0 R');
      const name='Im'+(i+1);
      const content=`q\n595.28 0 0 841.89 0 0 cm\n/${name} Do\nQ\n`;
      const contentBytes=ascii(content);
      objects[pageObj]=[ascii(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /XObject << /${name} ${imageObj} 0 R >> >> /Contents ${contentObj} 0 R >>`)];
      const jpg=dataUrlBytes(page.dataUrl);
      objects[imageObj]=[
        ascii(`<< /Type /XObject /Subtype /Image /Width ${page.width} /Height ${page.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpg.length} >>\nstream\n`),
        jpg,
        ascii('\nendstream')
      ];
      objects[contentObj]=[ascii(`<< /Length ${contentBytes.length} >>\nstream\n`),contentBytes,ascii('endstream')];
    });
    objects[2]=[ascii(`<< /Type /Pages /Kids [${kids.join(' ')}] /Count ${pages.length} >>`)];

    const chunks=[new Uint8Array([37,80,68,70,45,49,46,52,10,37,226,227,207,211,10])];
    const offsets=new Array(objectCount+1).fill(0);
    let position=chunks[0].length;
    for(let n=1;n<=objectCount;n++){
      offsets[n]=position;
      const start=ascii(n+' 0 obj\n'); const end=ascii('\nendobj\n');
      chunks.push(start); position+=start.length;
      for(const part of objects[n]){ chunks.push(part); position+=part.length; }
      chunks.push(end); position+=end.length;
    }
    const xrefPos=position;
    let xref=`xref\n0 ${objectCount+1}\n0000000000 65535 f \n`;
    for(let n=1;n<=objectCount;n++) xref+=String(offsets[n]).padStart(10,'0')+' 00000 n \n';
    xref+=`trailer\n<< /Size ${objectCount+1} /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF`;
    chunks.push(ascii(xref));
    return new Blob([concat(chunks)],{type:'application/pdf'});
  }

  const PDF_PT_W=595.28, PDF_PT_H=841.89, PDF_MARGIN=34;

  function cleanPdfText(text){
    return (text||'').toString()
      .replace(/☑/g,'[X]').replace(/☐/g,'[ ]')
      .replace(/\u00a0/g,' ').replace(/[\t ]+/g,' ')
      .replace(/ *\n */g,'\n').replace(/\n{3,}/g,'\n\n').trim();
  }

  function elementTextForPdf(element){
    if(!element) return '';
    const clone=element.cloneNode(true);
    clone.querySelectorAll('.no-print,button,script,style,img').forEach(el=>el.remove());
    clone.querySelectorAll('input[type="checkbox"],input[type="radio"]').forEach(input=>{
      input.replaceWith(document.createTextNode(input.checked?'[X] ':'[ ] '));
    });
    clone.querySelectorAll('br').forEach(br=>br.replaceWith(document.createTextNode('\n')));
    clone.querySelectorAll('tr').forEach(tr=>{
      const cells=[...tr.querySelectorAll(':scope > th,:scope > td')];
      if(cells.length){
        const line=cells.map(c=>cleanPdfText(c.textContent)).filter(Boolean).join(' | ');
        tr.replaceWith(document.createTextNode(line+'\n'));
      }
    });
    clone.querySelectorAll('div,p,li,label,h1,h2,h3,h4').forEach(el=>{
      el.appendChild(document.createTextNode('\n'));
    });
    return cleanPdfText(clone.textContent||'');
  }

  function winAnsiHex(text){
    const map={
      '€':0x80,'‚':0x82,'ƒ':0x83,'„':0x84,'…':0x85,'†':0x86,'‡':0x87,'ˆ':0x88,'‰':0x89,'Š':0x8A,'‹':0x8B,'Œ':0x8C,'Ž':0x8E,
      '‘':0x91,'’':0x92,'“':0x93,'”':0x94,'•':0x95,'–':0x96,'—':0x97,'˜':0x98,'™':0x99,'š':0x9A,'›':0x9B,'œ':0x9C,'ž':0x9E,'Ÿ':0x9F
    };
    let hex='';
    for(const ch of cleanPdfText(text)){
      let code=map[ch];
      if(code===undefined){
        const cp=ch.codePointAt(0);
        code=cp<=255?cp:63;
      }
      hex+=code.toString(16).padStart(2,'0').toUpperCase();
    }
    return hex;
  }

  function pdfColor(c){ return (c||[0,0,0]).map(v=>Number(v).toFixed(3)).join(' '); }

  function makePdfLayout(){
    const pages=[];
    let page=null, cursor=PDF_MARGIN;
    const measureCanvas=document.createElement('canvas');
    const measureCtx=measureCanvas.getContext('2d');

    function newPage(){
      page={commands:[],images:[]}; pages.push(page); cursor=PDF_MARGIN;
      if(pages.length>1){
        textLine('Briefing au pied de l’opération',PDF_MARGIN,cursor,8,true,[.35,.35,.35]);
        cursor+=16;
      }
    }
    newPage();

    function ensure(h){ if(cursor+h>PDF_PT_H-PDF_MARGIN-18) newPage(); }
    function cmd(v){ page.commands.push(v); }
    function rect(x,y,w,h,fill,stroke){
      const yb=PDF_PT_H-y-h;
      if(fill) cmd(`q ${pdfColor(fill)} rg ${x.toFixed(2)} ${yb.toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re f Q\n`);
      if(stroke) cmd(`q ${pdfColor(stroke)} RG 0.7 w ${x.toFixed(2)} ${yb.toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re S Q\n`);
    }
    function textLine(text,x,y,size,bold,color){
      const base=PDF_PT_H-y-size;
      cmd(`q ${pdfColor(color||[0,0,0])} rg BT /${bold?'F2':'F1'} ${size.toFixed(2)} Tf 1 0 0 1 ${x.toFixed(2)} ${base.toFixed(2)} Tm <${winAnsiHex(text)}> Tj ET Q\n`);
    }
    function textWidth(text,size,bold){
      measureCtx.font=(bold?'700 ':'400 ')+(size*1.333).toFixed(1)+'px Arial';
      return measureCtx.measureText(text).width*.75;
    }
    function wrap(text,maxWidth,size,bold){
      const lines=[];
      cleanPdfText(text).split('\n').forEach(raw=>{
        if(!raw){ lines.push(''); return; }
        let line='';
        raw.split(/\s+/).filter(Boolean).forEach(word=>{
          const trial=line?line+' '+word:word;
          if(line && textWidth(trial,size,bold)>maxWidth){ lines.push(line); line=word; }
          else line=trial;
        });
        if(line) lines.push(line);
      });
      return lines;
    }
    function paragraph(text,opts={}){
      const size=opts.size||9, bold=!!opts.bold, x=opts.x||PDF_MARGIN;
      const width=opts.width||PDF_PT_W-PDF_MARGIN*2, color=opts.color||[0,0,0];
      const leading=opts.leading||size*1.35;
      const lines=wrap(text,width,size,bold);
      lines.forEach(line=>{
        ensure(leading);
        if(line) textLine(line,x,cursor,size,bold,color);
        cursor+=leading;
      });
      cursor+=opts.after===undefined?4:opts.after;
    }
    function section(title,tone){
      const fill=tone==='blue'?[.83,.91,.98]:tone==='green'?[.88,.96,.84]:[.91,.92,.93];
      const lines=wrap(title,PDF_PT_W-PDF_MARGIN*2-14,11,true);
      const h=Math.max(26,lines.length*14+10);
      ensure(h+5); rect(PDF_MARGIN,cursor,PDF_PT_W-PDF_MARGIN*2,h,fill,[.25,.25,.25]);
      lines.forEach((line,i)=>textLine(line,PDF_MARGIN+7,cursor+6+i*14,11,true,[.05,.05,.05]));
      cursor+=h+7;
    }
    function title(text){
      const lines=wrap(text,PDF_PT_W-PDF_MARGIN*2,16,true);
      ensure(lines.length*22+12);
      lines.forEach((line,i)=>textLine(line,PDF_MARGIN,cursor+i*22,16,true,[.55,0,0]));
      cursor+=lines.length*22+10;
    }
    function infoBox(lines){
      const valid=lines.filter(Boolean); if(!valid.length) return;
      const wrapped=[];
      valid.forEach(line=>wrap(line,PDF_PT_W-PDF_MARGIN*2-14,9,false).forEach(x=>wrapped.push(x)));
      const h=wrapped.length*12+12; ensure(h+5);
      rect(PDF_MARGIN,cursor,PDF_PT_W-PDF_MARGIN*2,h,[.97,.97,.97],[.45,.45,.45]);
      wrapped.forEach((line,i)=>textLine(line,PDF_MARGIN+7,cursor+6+i*12,9,false,[.08,.08,.08]));
      cursor+=h+7;
    }
    async function image(src,opts={}){
      const data=await jpegForPdf(src,opts.maxPixel||1500);
      if(!data) return;
      const maxW=opts.maxW||PDF_PT_W-PDF_MARGIN*2;
      const maxH=opts.maxH||300;
      const ratio=Math.min(maxW/data.width,maxH/data.height,1);
      const w=data.width*ratio,h=data.height*ratio;
      ensure(h+12);
      const x=opts.x===undefined?PDF_MARGIN:opts.x;
      const y=cursor;
      page.images.push({bytes:data.bytes,pixelW:data.width,pixelH:data.height,x,y,w,h});
      if(opts.border!==false) rect(x,y,w,h,null,[.45,.45,.45]);
      cursor+=h+(opts.after===undefined?8:opts.after);
    }
    async function participantRow(fields,signatureSrc){
      const rowH=68; ensure(rowH+5);
      rect(PDF_MARGIN,cursor,PDF_PT_W-PDF_MARGIN*2,rowH,[1,1,1],[.25,.25,.25]);
      const leftW=PDF_PT_W-PDF_MARGIN*2-170;
      const text=[fields.nomPrenom,fields.entreprise,fields.fonction].filter(Boolean).join(' — ');
      const lines=wrap(text,leftW-12,9,false).slice(0,4);
      lines.forEach((line,i)=>textLine(line,PDF_MARGIN+6,cursor+8+i*13,9,i===0,[.05,.05,.05]));
      if(signatureSrc){
        const data=await jpegForPdf(signatureSrc,800);
        if(data){
          const maxW=152,maxH=52,ratio=Math.min(maxW/data.width,maxH/data.height,1);
          const w=data.width*ratio,h=data.height*ratio;
          const x=PDF_PT_W-PDF_MARGIN-160+(160-w)/2;
          const y=cursor+(rowH-h)/2;
          page.images.push({bytes:data.bytes,pixelW:data.width,pixelH:data.height,x,y,w,h});
        }
      }
      cursor+=rowH+5;
    }
    function finish(){
      pages.forEach((p,i)=>{
        const label=`Page ${i+1} / ${pages.length}`;
        const x=PDF_PT_W-PDF_MARGIN-55;
        p.commands.push(`q 0.350 0.350 0.350 rg BT /F1 8 Tf 1 0 0 1 ${x.toFixed(2)} 18 Tm <${winAnsiHex(label)}> Tj ET Q\n`);
      });
      return pages;
    }
    return {pages,paragraph,section,title,infoBox,image,participantRow,finish,ensure,get cursor(){return cursor;},set cursor(v){cursor=v;}};
  }

  function loadImageForPdf(src){
    return new Promise(resolve=>{
      const img=new Image(); let done=false;
      const finish=v=>{if(done)return;done=true;resolve(v)};
      img.onload=()=>finish(img); img.onerror=()=>finish(null);
      if(!src.startsWith('data:')&&!src.startsWith('blob:')) img.crossOrigin='anonymous';
      img.src=src; setTimeout(()=>finish(null),5000);
    });
  }

  async function jpegForPdf(src,maxPixel){
    if(!src) return null;
    const img=await loadImageForPdf(src); if(!img) return null;
    const naturalW=img.naturalWidth||img.width, naturalH=img.naturalHeight||img.height;
    if(!naturalW||!naturalH) return null;
    const scale=Math.min(1,(maxPixel||1500)/Math.max(naturalW,naturalH));
    const w=Math.max(1,Math.round(naturalW*scale)),h=Math.max(1,Math.round(naturalH*scale));
    const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
    const ctx=canvas.getContext('2d',{alpha:false});ctx.fillStyle='#fff';ctx.fillRect(0,0,w,h);ctx.drawImage(img,0,0,w,h);
    try{
      const url=canvas.toDataURL('image/jpeg',.84);
      return {bytes:dataUrlBytes(url),width:w,height:h};
    }catch(e){ return null; }
  }

  function assembleStructuredPdf(pages){
    let next=5;
    pages.forEach(page=>{
      page.pageObj=next++; page.contentObj=next++;
      page.images.forEach((img,i)=>{img.obj=next++;img.name='Im'+(i+1)});
      page.images.forEach(img=>{
        const yb=PDF_PT_H-img.y-img.h;
        page.commands.push(`q ${img.w.toFixed(2)} 0 0 ${img.h.toFixed(2)} ${img.x.toFixed(2)} ${yb.toFixed(2)} cm /${img.name} Do Q\n`);
      });
    });
    const count=next-1, objects=new Array(count+1);
    objects[1]=[ascii('<< /Type /Catalog /Pages 2 0 R >>')];
    objects[3]=[ascii('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>')];
    objects[4]=[ascii('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>')];
    objects[2]=[ascii(`<< /Type /Pages /Kids [${pages.map(p=>p.pageObj+' 0 R').join(' ')}] /Count ${pages.length} >>`)];

    pages.forEach(page=>{
      const xobjs=page.images.length?` /XObject << ${page.images.map(i=>'/'+i.name+' '+i.obj+' 0 R').join(' ')} >>`:'';
      objects[page.pageObj]=[ascii(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PDF_PT_W} ${PDF_PT_H}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >>${xobjs} >> /Contents ${page.contentObj} 0 R >>`)];
      const contentBytes=ascii(page.commands.join(''));
      objects[page.contentObj]=[ascii(`<< /Length ${contentBytes.length} >>\nstream\n`),contentBytes,ascii('endstream')];
      page.images.forEach(img=>{
        objects[img.obj]=[
          ascii(`<< /Type /XObject /Subtype /Image /Width ${img.pixelW} /Height ${img.pixelH} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${img.bytes.length} >>\nstream\n`),
          img.bytes,ascii('\nendstream')
        ];
      });
    });

    const chunks=[new Uint8Array([37,80,68,70,45,49,46,52,10,37,226,227,207,211,10])];
    const offsets=new Array(count+1).fill(0); let pos=chunks[0].length;
    for(let n=1;n<=count;n++){
      offsets[n]=pos; const a=ascii(n+' 0 obj\n'),z=ascii('\nendobj\n');
      chunks.push(a);pos+=a.length; for(const part of objects[n]){chunks.push(part);pos+=part.length} chunks.push(z);pos+=z.length;
    }
    const xref=pos;
    let tail=`xref\n0 ${count+1}\n0000000000 65535 f \n`;
    for(let n=1;n<=count;n++) tail+=String(offsets[n]).padStart(10,'0')+' 00000 n \n';
    tail+=`trailer\n<< /Size ${count+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
    chunks.push(ascii(tail));
    return new Blob([concat(chunks)],{type:'application/pdf'});
  }

  async function createPdfBlob(){
    const host=exportHost || buildExportHost();
    await waitImages(host);
    const layout=makePdfLayout();
    layout.title('Briefing au pied de l’opération — Nos vies, notre priorité');

    const info=[];
    host.querySelectorAll('.preview .footer-info').forEach(box=>{
      [...box.children].forEach(cell=>{const t=cleanPdfText(cell.textContent);if(t)info.push(t)});
    });
    layout.infoBox(info);

    const blocks=[...host.querySelectorAll('.preview .sheet .block')];
    blocks.forEach(block=>{
      const title=cleanPdfText(block.querySelector('.block-title')?.textContent||'');
      const tone=block.classList.contains('blue')?'blue':block.classList.contains('green')?'green':'grey';
      if(title) layout.section(title,tone);
      const clone=block.cloneNode(true); clone.querySelector('.block-title')?.remove();
      const text=elementTextForPdf(clone);
      if(text) layout.paragraph(text,{size:8.6,leading:11.5});
    });

    const photos=[...host.querySelectorAll('.preview img')].filter(img=>img.src && !img.closest('.presence-signature'));
    if(photos.length){
      layout.section('Photos du briefing','grey');
      for(const img of photos){
        const caption=cleanPdfText(img.closest('.photo-card,.photo-item,.briefing-photo-card')?.textContent||'');
        if(caption) layout.paragraph(caption,{size:8,bold:true});
        await layout.image(img.src,{maxH:300});
      }
    }

    layout.section('Feuille de traçabilité et signatures','grey');
    const sign=host.querySelector('#signatureSheetPdfV70');
    if(sign){
      const trace=[];
      ['traceChantier','traceHoraire','traceResponsable','traceEntreprise','traceLieu','tracePk','traceVoies'].forEach(k=>{
        const el=sign.querySelector('#'+k); if(el) trace.push(el.parentElement?.textContent||el.textContent);
      });
      layout.infoBox(trace.map(cleanPdfText));
      const rows=[...sign.querySelectorAll('#presenceRows tr')];
      if(!rows.length) layout.paragraph('Aucun participant enregistré.',{size:9,bold:true});
      for(const tr of rows){
        const cells=[...tr.querySelectorAll('td')];
        const nomPrenom=cleanPdfText([cells[1]?.textContent,cells[2]?.textContent].filter(Boolean).join(' '));
        const entreprise=cleanPdfText(cells[3]?.textContent||'');
        const fonction=cleanPdfText(cells[4]?.textContent||'');
        const sig=cells[5]?.querySelector('img')?.src || tr.querySelector('.presence-signature img')?.src || '';
        await layout.participantRow({nomPrenom,entreprise,fonction},sig);
      }
      layout.paragraph('Les intervenants signataires reconnaissent avoir participé au briefing et compris les risques et mesures de prévention présentés.',{size:7.8,color:[.25,.25,.25]});
    }

    const pages=layout.finish();
    return assembleStructuredPdf(pages);
  }

  function bridges(){
    const out=[];
    BRIDGE_NAMES.forEach(name=>{ try{ const obj=window[name]; if(obj&&!out.some(x=>x.obj===obj)) out.push({name,obj}); }catch(e){} });
    return out;
  }

  async function blobBase64(blob){
    return await new Promise((resolve,reject)=>{
      const r=new FileReader(); r.onload=()=>resolve(String(r.result).split(',')[1]||''); r.onerror=reject; r.readAsDataURL(blob);
    });
  }

  function callBridge(methods,filename,base64){
    for(const entry of bridges()){
      for(const method of methods){
        try{
          if(typeof entry.obj[method]==='function'){
            entry.obj[method](filename,'application/pdf',base64);
            return true;
          }
        }catch(e){ console.warn('[PDF V70]',entry.name,method,e); }
      }
    }
    return false;
  }

  function chunkSave(filename,base64){
    const size=384*1024;
    for(const entry of bridges()){
      const b=entry.obj;
      if(typeof b.beginFile==='function'&&typeof b.writeFileChunk==='function'&&typeof b.finishFile==='function'){
        try{
          b.beginFile(filename,'application/pdf',Math.ceil(base64.length/size));
          for(let i=0;i<base64.length;i+=size) b.writeFileChunk(base64.slice(i,i+size));
          b.finishFile(); return true;
        }catch(e){ console.warn('[PDF V70] chunk save',e); }
      }
    }
    return false;
  }

  async function savePdf(blob,filename){
    const b64=await blobBase64(blob);
    if(chunkSave(filename,b64) || callBridge(['saveBase64File','downloadBase64File','saveFileBase64','downloadBase64','savePdfBase64','savePdf'],filename,b64)) return true;
    try{
      const url=URL.createObjectURL(blob), a=document.createElement('a');
      a.href=url;a.download=filename;a.style.display='none';document.body.appendChild(a);a.click();a.remove();
      setTimeout(()=>URL.revokeObjectURL(url),8000); return true;
    }catch(e){ return false; }
  }

  async function sharePdf(blob,filename){
    try{
      const file=new File([blob],filename,{type:'application/pdf'});
      if(navigator.share && (!navigator.canShare || navigator.canShare({files:[file]}))){
        await navigator.share({title:'Briefing signé',text:'Briefing chantier signé au format PDF',files:[file]});
        return true;
      }
    }catch(e){
      if(e && e.name==='AbortError') return true;
      console.warn('[PDF V70] Web Share',e);
    }
    const b64=await blobBase64(blob);
    if(callBridge(['sharePdfToWhatsApp','shareBase64ToWhatsApp','shareToWhatsAppBase64','shareBase64File','shareFileBase64','sharePdfBase64','shareFile'],filename,b64)) return true;
    return false;
  }

  window.runPdfActionV70 = async function(mode){
    if(busy) return;
    busy=true;
    document.querySelectorAll('.pdf-preview-actions-v70 button').forEach(b=>b.disabled=true);
    try{
      const filename=filenameV70();
      const pdf=await createPdfBlob();
      if(mode==='share'){
        showProgress(true,'Ouverture du partage Android…');
        const ok=await sharePdf(pdf,filename);
        if(ok){ notify('Le PDF signé est prêt. Sélectionne WhatsApp dans la fenêtre de partage.'); }
        else{
          await savePdf(pdf,filename);
          alert('Le téléphone ne permet pas le partage direct du fichier depuis cette WebView. Le PDF a été enregistré : ouvre WhatsApp puis joins-le depuis les téléchargements.');
        }
      }else{
        showProgress(true,'Enregistrement du PDF sur le téléphone…');
        const ok=await savePdf(pdf,filename);
        if(ok) notify('PDF signé enregistré sur le téléphone.');
        else throw new Error('Aucune fonction Android d’enregistrement disponible.');
      }
      closePdfPreviewV70(true);
    }catch(e){
      console.error(e);
      alert('Impossible de créer le PDF : '+(e.message||e)+'. Vérifie que WebView Android autorise Canvas, Blob et les téléchargements.');
    }finally{
      busy=false;showProgress(false);
      document.querySelectorAll('.pdf-preview-actions-v70 button').forEach(b=>b.disabled=false);
    }
  };

  // Retire toute ancienne possibilité d'export HTML visible.
  window.presenceExport=function(){ alert('L’export HTML a été retiré. Utilise le PDF signé.'); };
  window.shareBriefingWhatsApp=function(){ return window.openPdfPreviewV70('share'); };
  window.safePrintWithSignatures=function(){ return window.openPdfPreviewV70('save'); };
  window.presencePrint=window.safePrintWithSignatures;

  function removeLegacyExportButtons(){
    document.querySelectorAll('button').forEach(btn=>{
      const t=(btn.textContent||'').trim().toLowerCase();
      if(t.includes('enregistrer le briefing html') || t.includes('exporter le briefing') || t==='exporter') btn.remove();
    });
    const old=id('pdfFinalisationOverlayV67'); if(old) old.style.display='none';
  }

  window.addEventListener('resize',()=>{ if(id('pdfPreviewOverlayV70')?.classList.contains('is-open')) resizePreview(); });
  document.addEventListener('keydown',e=>{ if(e.key==='Escape') closePdfPreviewV70(); });
  document.addEventListener('DOMContentLoaded',()=>{ removeLegacyExportButtons(); setTimeout(removeLegacyExportButtons,800); });
  setTimeout(removeLegacyExportButtons,1200);
})();

;

(function(){
  function byId(id){ return document.getElementById(id); }
  function safe(v){ return (v || 'A_completer').toString().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9_-]+/g,'_').replace(/^_+|_+$/g,'').slice(0,70) || 'A_completer'; }
  function meta(){ return {date:byId('date')?.value || new Date().toISOString().slice(0,10), chantier:byId('chantier')?.value || 'briefing', entreprise:byId('entrepriseChantier')?.value || 'entreprise'}; }
  function prepare(){
    try{ if(typeof generate==='function') generate(); }catch(e){}
    try{ if(typeof presenceSave==='function') presenceSave(); }catch(e){}
    try{ if(typeof presenceRender==='function') presenceRender(); }catch(e){}
  }
  function baseName(){ const m=meta(); return safe(m.date)+'_'+safe(m.chantier)+'_'+safe(m.entreprise)+'_briefing'; }
  function utf8ToBase64(text){
    const bytes=new TextEncoder().encode(text); let binary='';
    const step=0x8000;
    for(let i=0;i<bytes.length;i+=step) binary += String.fromCharCode.apply(null, bytes.subarray(i,i+step));
    return btoa(binary);
  }
  async function nativeSaveBlob(blob, filename, mime){
    if(!(window.AndroidApp && AndroidApp.beginFileDownload && AndroidApp.appendFileChunk && AndroidApp.finishFileDownload)) return false;
    const b64=utf8ToBase64(await blob.text());
    const session=AndroidApp.beginFileDownload(filename,mime);
    if(!session) return false;
    try{
      const chunkSize=240000;
      for(let i=0;i<b64.length;i+=chunkSize){ if(!AndroidApp.appendFileChunk(session,b64.slice(i,i+chunkSize))) throw new Error('chunk'); }
      return !!AndroidApp.finishFileDownload(session);
    }catch(e){ try{AndroidApp.cancelFileDownload(session);}catch(_){} return false; }
  }
  window.presenceExport = async function(){
    prepare();
    const filename=baseName()+'.html';
    const blob=new Blob([document.documentElement.outerHTML],{type:'text/html;charset=utf-8'});
    if(await nativeSaveBlob(blob,filename,'text/html;charset=utf-8')){ if(typeof showToast==='function') showToast('Briefing enregistré dans Téléchargements'); return; }
    try{
      const url=URL.createObjectURL(blob), a=document.createElement('a'); a.href=url; a.download=filename; a.style.display='none'; document.body.appendChild(a); a.click();
      setTimeout(()=>{a.remove();URL.revokeObjectURL(url);},2000);
      if(typeof showToast==='function') showToast('Téléchargement du briefing lancé');
    }catch(e){ if(typeof showToast==='function') showToast('Enregistrement impossible sur ce navigateur'); }
  };
  window.shareBriefingWhatsApp = async function(){
    prepare();
    const filename=baseName()+'.pdf';
    if(window.AndroidApp && typeof AndroidApp.sharePdf==='function'){
      if(typeof showToast==='function') showToast('Création du PDF…');
      AndroidApp.sharePdf(filename);
      return;
    }
    if(typeof showToast==='function') showToast('Choisis « Enregistrer au format PDF », puis partage-le avec WhatsApp.');
    if(typeof safePrintWithSignatures==='function') safePrintWithSignatures(); else window.print();
  };
  window.saveBriefingPdfToPhone = function(){
    prepare(); const filename=baseName()+'.pdf';
    if(window.AndroidApp && typeof AndroidApp.savePdf==='function'){ AndroidApp.savePdf(filename); return; }
    if(typeof safePrintWithSignatures==='function') safePrintWithSignatures(); else window.print();
  };
})();

;

(function(){
  function el(id){return document.getElementById(id)}
  function nativeAvailable(){return !!(window.AndroidApp && typeof window.AndroidApp.savePdf==='function' && typeof window.AndroidApp.sharePdf==='function')}
  function clean(v){return String(v||'A_completer').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9_-]+/g,'_').replace(/^_+|_+$/g,'').slice(0,80)||'A_completer'}
  function filename(){
    const date=el('date')?.value||new Date().toISOString().slice(0,10);
    const chantier=el('chantier')?.value||'Chantier';
    const entreprise=el('entrepriseChantier')?.value||'Entreprise';
    return clean(date)+'_'+clean(chantier)+'_'+clean(entreprise)+'_Briefing.pdf';
  }
  function overlay(){return el('pdfFinalisationOverlayV67')}
  function stateBox(){
    let b=el('nativePdfStateV104');
    if(b)return b;
    b=document.createElement('div');b.id='nativePdfStateV104';
    const popup=el('pdfFinalisationPopupV67');
    if(popup) popup.insertBefore(b,popup.querySelector('.pdf-finalisation-actions-v67'));
    return b;
  }
  function status(type,text){const b=stateBox();b.className=type;b.textContent=text}
  function showOverlay(){const o=overlay();if(o)o.style.display='flex'}
  function hideOverlay(){const o=overlay();if(o)o.style.display='none'}
  function prepare(mode){
    try{if(typeof generate==='function')generate()}catch(e){}
    try{if(typeof presenceSave==='function')presenceSave()}catch(e){}
    try{document.getElementById('actionsOverlay').style.display='none'}catch(e){}
    showOverlay();
    status('info',mode==='share'?'Création du PDF puis ouverture du partage Android…':'Choisis l’emplacement et appuie sur « Enregistrer ». En cas de retour arrière, les signatures seront conservées.');
  }
  function purge(){
    try{
      if(typeof window.__nativeClearOnlySignaturesV52==='function') window.__nativeClearOnlySignaturesV52();
      else if(typeof window.presenceResetSignaturesOnly==='function') window.presenceResetSignaturesOnly();
      else if(typeof window.confirmPdfSavedAndPurgeV67==='function') window.confirmPdfSavedAndPurgeV67();
    }catch(e){console.error(e)}
  }

  window.onNativePdfSaved=function(name,shared){
    purge();
    status('ok',shared?'PDF créé et prêt à être partagé. Les signatures ont été purgées.':'PDF enregistré avec succès. Les signatures ont été purgées.');
    setTimeout(hideOverlay,900);
  };
  window.onNativePdfSaveCancelled=function(){
    showOverlay();
    status('err','Enregistrement annulé ou retour arrière : aucune signature n’a été supprimée. Tu peux recommencer ou fermer cet écran.');
  };
  window.onNativePdfError=function(message){
    showOverlay();
    status('err','Échec : '+(message||'erreur inconnue')+'. Les signatures sont conservées.');
  };

  window.saveBriefingPdfToPhone=function(){
    if(nativeAvailable()){
      prepare('save');
      window.AndroidApp.savePdf(filename());
      return;
    }
    if(typeof window.safePrintWithSignatures==='function')window.safePrintWithSignatures();else window.print();
  };
  window.shareBriefingWhatsApp=function(){
    if(nativeAvailable()){
      prepare('share');
      window.AndroidApp.sharePdf(filename());
      return;
    }
    if(typeof window.shareBriefingPdfWhatsAppV101==='function')return window.shareBriefingPdfWhatsAppV101();
    if(typeof window.safePrintWithSignatures==='function')window.safePrintWithSignatures();else window.print();
  };

  function bind(){
    document.querySelectorAll('button').forEach(function(btn){
      const t=(btn.textContent||'').trim().toLowerCase();
      if(t.includes('enregistrer le pdf')||t.includes('enregistrer sur le téléphone')) btn.onclick=function(e){e.preventDefault();window.saveBriefingPdfToPhone()};
      if(t.includes('whatsapp')) btn.onclick=function(e){e.preventDefault();window.shareBriefingWhatsApp()};
      if(t.includes('exporter archive html')) btn.remove();
    });
  }
  document.addEventListener('DOMContentLoaded',function(){setTimeout(bind,100);setTimeout(bind,800)});
  setTimeout(bind,1200);
})();

;

(function(){
  function el(id){ return document.getElementById(id); }
  function bridge(){
    return (window.AndroidApp && typeof window.AndroidApp.savePdf === 'function' && typeof window.AndroidApp.sharePdf === 'function') ? window.AndroidApp : null;
  }
  function clean(v){
    return String(v || 'A_completer').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9_-]+/g,'_').replace(/^_+|_+$/g,'').slice(0,80) || 'A_completer';
  }
  function pdfFilename(){
    return clean(el('date')?.value || new Date().toISOString().slice(0,10)) + '_' +
      clean(el('chantier')?.value || 'Chantier') + '_' +
      clean(el('entrepriseChantier')?.value || 'Entreprise') + '_Briefing.pdf';
  }
  function prepare(){
    try { if(typeof window.generate === 'function') window.generate(); } catch(e){}
    try { if(typeof window.presenceSave === 'function') window.presenceSave(); } catch(e){}
    try { if(typeof window.presenceRender === 'function') window.presenceRender(); } catch(e){}
  }
  function setNativeState(type, text){
    try {
      const overlay = el('pdfFinalisationOverlayV67');
      if(overlay) overlay.style.display = 'flex';
      let box = el('nativePdfStateV104');
      if(!box){
        box=document.createElement('div'); box.id='nativePdfStateV104';
        const popup=el('pdfFinalisationPopupV67');
        if(popup) popup.insertBefore(box, popup.querySelector('.pdf-finalisation-actions-v67'));
      }
      if(box){ box.className=type; box.textContent=text; }
    } catch(e){}
  }
  function saveNative(){
    const b=bridge();
    if(!b){ setNativeState('err','Pont Android indisponible. Cette version doit être ouverte dans l’APK.'); return false; }
    prepare();
    setNativeState('info','Choisis l’emplacement puis valide « Enregistrer ». Un retour arrière conservera les signatures.');
    b.savePdf(pdfFilename());
    return true;
  }
  function shareNative(){
    const b=bridge();
    if(!b){ setNativeState('err','Pont Android indisponible. Cette version doit être ouverte dans l’APK.'); return false; }
    prepare();
    setNativeState('info','Création du PDF puis ouverture du partage Android…');
    b.sharePdf(pdfFilename());
    return true;
  }

  // Remplace définitivement l’ancien moteur Blob/WebView.
  window.runPdfActionV70 = function(mode){
    return mode === 'share' ? shareNative() : saveNative();
  };
  window.saveBriefingPdfToPhone = saveNative;
  window.shareBriefingWhatsApp = shareNative;
  window.safePrintWithSignatures = saveNative;
  window.presencePrint = saveNative;

  // Interception en phase capture : fonctionne aussi pour les boutons créés après le chargement.
  document.addEventListener('click', function(event){
    const button = event.target && event.target.closest ? event.target.closest('button') : null;
    if(!button) return;
    const text=(button.textContent || '').trim().toLowerCase();
    if(text.includes('exporter archive html')){
      event.preventDefault(); event.stopImmediatePropagation(); button.remove(); return;
    }
    if(text.includes('enregistrer sur le téléphone') || text.includes('enregistrer le pdf')){
      event.preventDefault(); event.stopImmediatePropagation(); saveNative(); return;
    }
    if(text.includes('whatsapp') || text.includes('partager le pdf')){
      event.preventDefault(); event.stopImmediatePropagation(); shareNative();
    }
  }, true);

  function cleanup(){
    document.querySelectorAll('button').forEach(function(button){
      const text=(button.textContent || '').trim().toLowerCase();
      if(text.includes('exporter archive html')) button.remove();
    });
  }
  document.addEventListener('DOMContentLoaded', cleanup);
  setTimeout(cleanup, 500);
  setTimeout(cleanup, 1500);
})();
